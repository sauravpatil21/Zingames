<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\GameController;
use App\Http\Controllers\Admin\MessageController;
use App\Http\Controllers\AuthController;
use App\Models\Game;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\Admin\ContactMessageController;
use App\Http\Controllers\Admin\SubAdminController;

Route::get('/', function () {
    $games = Game::with('category')->latest()->paginate(12); // 12 games per page
    $categories = Category::all();
    return view('welcome', compact('games', 'categories'));
});

// Public authentication routes
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Admin login route (public access)
Route::get('/admin/login', [AuthController::class, 'showLoginForm'])->name('admin.login');

// About Us page
Route::get('/about-us', function () {
    $categories = Category::all();
    return view('about-us', compact('categories'));
})->name('about.us');

// Information for Parents page
Route::get('/information-for-parents', function () {
    $categories = Category::all();
    return view('information-for-parents', compact('categories'));
})->name('information.for.parents');

// Game detail page with caching and SEO friendly URL
Route::get('/games/{game:slug}', function (Game $game) {
    // Clear cache if requested
    if (request()->has('clear_cache')) {
        Cache::forget('game_'.$game->id);
        Cache::forget('related_games_'.$game->id);
    }
    
    // Cache the game details for 30 minutes (reduced from 1 hour for faster updates)
    $game = Cache::remember('game_'.$game->id, 1800, function () use ($game) {
        return $game->load('category');
    });
    
    // Get related games (same category, excluding current game)
    $relatedGames = Cache::remember('related_games_'.$game->id, 1800, function () use ($game) {
        $related = Game::where('category_id', $game->category_id)
                      ->where('id', '!=', $game->id)
                      ->take(12)
                      ->get();
        
        // If we don't have enough related games, get some random ones
        if ($related->count() < 12) {
            $moreGames = Game::where('id', '!=', $game->id)
                            ->whereNotIn('id', $related->pluck('id')->toArray())
                            ->inRandomOrder()
                            ->take(12 - $related->count())
                            ->get();
            
            $related = $related->concat($moreGames);
        }
        
        return $related;
    });
    
    // Get all categories for the sidebar
    $categories = Category::all();
    
    return view('game-detail', compact('game', 'relatedGames', 'categories'));
})->name('games.show');

// Search feature
Route::get('/search', function (Request $request) {
    $query = $request->input('query');
    $games = Game::where('name', 'LIKE', "%{$query}%")
                ->orWhere('description', 'LIKE', "%{$query}%")
                ->orWhere('hashtags', 'LIKE', "%{$query}%")
                ->with('category')
                ->paginate(12);
    
    return view('search-results', compact('games', 'query'));
})->name('games.search');

// Category filter with SEO friendly URL
Route::get('/category/{id}/{slug?}', function ($id, $slug = null) {
    $category = Category::findOrFail($id);
    
    // Check if the provided slug matches the category name
    $correctSlug = Str::slug($category->name);
    
    // If slug is wrong or not provided, redirect to the correct URL
    if ($slug !== $correctSlug) {
        return redirect()->to("/category/{$id}/{$correctSlug}", 301);
    }
    
    $games = Game::where('category_id', $id)
                ->with('category')
                ->paginate(12);
    $allCategories = Category::all();
    
    return view('category-games', compact('games', 'category', 'allCategories'));
})->name('games.category');

// Contact routes
Route::get('/contact-us', [ContactController::class, 'index'])->name('contact.us');
Route::post('/contact-us', [ContactController::class, 'store'])->name('contact.store');

// Privacy Policy page
Route::get('/privacy-policy', function () {
    $categories = Category::all();
    return view('privacy-policy', compact('categories'));
})->name('privacy.policy');

// Terms of Use page
Route::get('/terms-of-use', function () {
    $categories = Category::all();
    return view('terms-of-use', compact('categories'));
})->name('terms.of.use');

// Cookies Policy page
Route::get('/cookies-policy', function () {
    $categories = Category::all();
    return view('cookies-policy', compact('categories'));
})->name('cookies.policy');

// FAQs page
Route::get('/faqs', function () {
    $categories = Category::all();
    return view('faqs', compact('categories'));
})->name('faqs');

// Admin routes with enhanced security (protected)
Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('dashboard');
    Route::get('/add-game', [GameController::class, 'create'])->name('add-game');
    Route::get('/view-games', [GameController::class, 'index'])->name('view-games');
    Route::resource('games', GameController::class);
    Route::get('/edit-games-list', [GameController::class, 'editGamesList'])->name('edit-games-list');
    Route::post('/clear-game-caches', [AdminController::class, 'clearGameCaches'])->name('clear-game-caches');
    Route::get('/add-category', [AdminController::class, 'addCategory'])->name('add-category');
    Route::resource('categories', CategoryController::class);
    Route::get('/messages', [MessageController::class, 'index'])->name('messages.index');
    Route::get('/messages/{id}', [MessageController::class, 'show'])->name('messages.show');
    Route::delete('/messages/{id}', [MessageController::class, 'destroy'])->name('messages.destroy');
    Route::patch('/messages/{id}/mark-as-read', [MessageController::class, 'markAsRead'])->name('messages.mark-as-read');
    Route::patch('/messages/{id}/mark-as-unread', [MessageController::class, 'markAsUnread'])->name('messages.mark-as-unread');
    Route::post('/messages/{id}/block-email', [MessageController::class, 'blockEmail'])->name('messages.block-email');
    Route::post('/messages/{id}/unblock-email', [MessageController::class, 'unblockEmail'])->name('messages.unblock-email');
    Route::get('/messages/blocked', [MessageController::class, 'blockedEmails'])->name('messages.blocked');
    Route::get('/users', [AdminController::class, 'users'])->name('users.index');
    Route::get('/users/{id}', [AdminController::class, 'showUser'])->name('users.show');
    Route::put('/users/{id}/lock', [AdminController::class, 'lockUser'])->name('users.lock');
    Route::put('/users/{id}/unlock', [AdminController::class, 'unlockUser'])->name('users.unlock');
    Route::get('/users/create', [AdminController::class, 'createSubAdminForm'])->name('users.create');
    Route::post('/users', [AdminController::class, 'storeSubAdmin'])->name('users.store');
});

// Admin Settings Page
Route::middleware(['auth', 'admin'])->prefix('admin')->group(function () {
    Route::get('/settings', [App\Http\Controllers\AdminController::class, 'settings'])->name('admin.settings');
    Route::post('/settings/password-change', [App\Http\Controllers\AdminController::class, 'changePassword'])->name('admin.settings.change-password');
    Route::post('/settings/change-email', [App\Http\Controllers\AdminController::class, 'changeEmail'])->name('admin.settings.change-email');
});
