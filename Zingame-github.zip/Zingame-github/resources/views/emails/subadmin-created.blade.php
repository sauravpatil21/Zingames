<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Welcome to ZinGames Admin</title>
    <style>
        body { font-family: 'Poppins', Arial, sans-serif; background: #f4f6fb; color: #222; }
        .container { max-width: 500px; margin: 40px auto; background: #fff; border-radius: 12px; box-shadow: 0 4px 24px rgba(0,0,0,0.08); padding: 32px; }
        .header { text-align: center; margin-bottom: 24px; }
        .header h2 { color: #3b82f6; margin-bottom: 8px; }
        .info { background: #f0f7ff; border-left: 4px solid #3b82f6; padding: 16px; border-radius: 8px; margin-bottom: 24px; }
        .info strong { color: #3b82f6; }
        .footer { text-align: center; color: #888; font-size: 13px; margin-top: 32px; }
        .btn { display: inline-block; background: #3b82f6; color: #fff; padding: 12px 28px; border-radius: 6px; text-decoration: none; font-weight: 600; margin-top: 18px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Welcome to ZinGames Admin Panel!</h2>
            <p style="font-size: 18px;">Your Sub Admin account is ready 🎉</p>
        </div>
        <div class="info">
            <p>Dear <strong>{{ $user->name }}</strong>,</p>
            <p>Your admin account has been created successfully. Here are your login details:</p>
            <p><strong>Email:</strong> {{ $user->email }}<br>
            <strong>Password:</strong> {{ $plainPassword }}</p>
            <p>You can login at:<br>
                <a href="{{ url('/admin/login') }}" class="btn">Admin Login</a>
            </p>
        </div>
        <div class="footer">
            If you did not expect this email, please ignore it.<br>
            &copy; {{ date('Y') }} ZinGames
        </div>
    </div>
</body>
</html> 
