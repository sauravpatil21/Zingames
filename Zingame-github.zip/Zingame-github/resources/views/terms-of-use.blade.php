<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms of Use - ZinGames</title>
    <meta name="description" content="ZinGames terms of use - guidelines for using our platform, embedding our games, user responsibilities, and privacy information. Read our terms before using our services.">
    <meta name="keywords" content="terms of use, user agreement, game embedding policy, ZinGames terms, online gaming terms, user guidelines">
    <meta name="author" content="ZinGames">
    <meta name="robots" content="index, follow">
    <meta property="og:title" content="Terms of Use - ZinGames">
    <meta property="og:description" content="ZinGames terms of use - guidelines for using our platform, embedding our games, user responsibilities, and privacy information.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url('/terms-of-use') }}">
    <meta property="og:image" content="{{ asset('img/favicon.ico') }}">
    <link rel="canonical" href="{{ url('/terms-of-use') }}">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome CDN for Social Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
        integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        /* Custom Static CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #0f172a, #1e293b);
            color: #e0e0e0;
            line-height: 1.6;
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }

        /* Main Layout */
        .main-container {
            display: flex;
            min-height: calc(100vh - 80px);
            position: relative;
            overflow: hidden;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 250px;
            background: linear-gradient(145deg, #1e293b, #2d3748);
            padding: 1.5rem 0;
            height: calc(100vh - 80px);
            position: fixed;
            top: 80px;
            left: -250px;
            z-index: 1500;
            transition: all 0.4s ease;
            box-shadow: 5px 0 20px rgba(0, 0, 0, 0.4);
            overflow-y: auto;
        }

        .sidebar.open {
            left: 0;
        }

        /* About Us Container */
        .about-container {
            flex: 1;
            padding: 2rem 3rem;
            transition: margin-left 0.4s ease;
            margin-left: 0;
        }

        .about-container.shifted {
            margin-left: 250px;
        }

        .about-section {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            padding: 2.5rem;
            margin-bottom: 3rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .about-section:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: 700;
            color: #ffffff;
            margin-bottom: 1.5rem;
            text-shadow: 0 0 15px rgba(66, 153, 225, 0.8);
            position: relative;
            display: inline-block;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 0;
            width: 60px;
            height: 4px;
            background: linear-gradient(90deg, #4299e1, #4c51bf);
            border-radius: 2px;
        }

        .about-text {
            font-size: 1.1rem;
            line-height: 1.8;
            color: #d0d0d0;
            margin-bottom: 1.5rem;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .sidebar {
                width: 220px;
                left: -220px;
            }

            .sidebar.open {
                left: 0;
            }

            .about-container.shifted {
                margin-left: 220px;
            }
            
            .about-section {
                padding: 2rem;
            }
            
            .section-title {
                font-size: 2.2rem;
            }
        }

        @media (max-width: 768px) {
            .main-container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                top: 0;
                left: -100%;
            }
            
            .sidebar.open {
                left: 0;
            }
            
            .about-container {
                padding: 1.5rem;
                margin-left: 0;
            }
            
            .about-container.shifted {
                margin-left: 0;
            }
            
            .about-section {
                padding: 1.5rem;
            }
            
            .flex-1 {
                padding: 1rem;
                padding-top: 70px;
            }
            
            h1 {
                font-size: 1.8rem;
                margin-bottom: 1rem;
            }
            
            h3 {
                font-size: 1.4rem;
                margin-bottom: 0.75rem;
            }
            
            .section-title {
                font-size: 1.8rem;
            }
            
            .about-text {
                font-size: 1rem;
            }
            
            ul.list-disc {
                padding-left: 1.5rem;
            }
            
            ol li {
                margin-bottom: 1rem;
            }
        }
        
        @media (max-width: 480px) {
            .about-container {
                padding: 1rem;
            }
            
            .about-section {
                padding: 1.25rem;
                margin-bottom: 2rem;
            }
            
            .flex-1 {
                padding: 0.75rem;
                padding-top: 60px;
            }
            
            h1 {
                font-size: 1.5rem;
            }
            
            h3 {
                font-size: 1.2rem;
            }
            
            .section-title {
                font-size: 1.5rem;
            }
            
            .about-text, p {
                font-size: 0.95rem;
            }
            
            ul.list-disc {
                padding-left: 1rem;
            }
            
            li {
                margin-bottom: 0.5rem;
            }
        }
    </style>
</head>

<body>
    <!-- Particles Background -->
    <div class="particles">
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
    </div>

    <!-- Include Header -->
    @include('partials.header')

    <!-- Main Content -->
    <main class="main-container">
        <!-- Include Sidebar -->
        @include('partials.sidebar')

        <!-- Terms of Use Container -->
        <section class="about-container" id="aboutContainer">
            <div class="about-section">
                <div class="flex flex-1">
                    <main class="flex-1 p-8 pt-[90px]">
                        <h1 class="text-4xl font-bold mb-6 text-gray-100">Terms of Use</h1>
                        
                        <p class="mb-6 text-gray-300">Welcome to ZinGames! By accessing or using our website, you agree to comply with and be bound by the following terms and conditions of use, which together with our privacy policy govern ZinGames' relationship with you in relation to this website.</p>
                        
                        <p class="mb-6 text-gray-300">We, ApplySet Media <b>ZinGames</b> a company established under the Indian law, welcome you to our online platform accessible at <a href="https://zingames.com" class="text-blue-500">https://zingames.com</a> or <a href="http://zingames.com" class="text-blue-500">http://zingames.com</a>. Here, we provide access to a variety of virtual environments, games, and other engaging content, along with downloadable software or applications suitable for personal computers, tablets, mobile devices, or phones. As a user of the ZinGames Website, referred to as <b>"Website Visitors,"</b> you are bound by the terms and conditions outlined in this document, known as the <b>"Terms of Use."</b></p>
                        
                        <p class="mb-6 text-gray-300">Before proceeding to explore or utilize any part of the ZinGames Website, we urge you to carefully review these Terms of Use. By accessing or using any portion of this ZinGames Website, you indicate that you have read, comprehended, and agreed to abide by these Terms of Use, subject to any future amendments made by ZinGames. Should you disagree with any aspect of these Terms of Use or find them unsatisfactory, your sole recourse is to refrain from accessing or using any part of this ZinGames Website.</p>
                        
                        <p class="mb-6 text-gray-300">ZinGames reserves the right to modify and update these Terms of Use at its discretion, with any revisions being communicated by posting the amended Terms of Use on the ZinGames Website. Your continued usage of the ZinGames Website following such changes indicates your acceptance and adherence to the revised Terms of Use. Failure to comply with these Terms of Use or dissatisfaction with the ZinGames Website warrants discontinuation of use as the exclusive remedy.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">1. Responsible Use of the ZinGames Platform</h3>
                        <ol class="list-decimal list-inside mb-6 text-gray-300 pl-5">
                            <li><b>Commercial Use Restrictions:</b> Users are prohibited from reproducing, distributing, or exploiting any part of the ZinGames Website for commercial purposes without explicit written permission from ZinGames.</li>
                            <li><b>User-Generated Content Responsibility:</b> Content submitted to public areas of the ZinGames Website is the responsibility of the submitter. ZinGames does not endorse or guarantee the accuracy of such content. Users warrant that any material uploaded is either their own, in the public domain, or free of proprietary restrictions. By submitting content, users grant ZinGames the right to use it in various capacities.</li>
                            <li><b>Moderation and Termination:</b> ZinGames reserves the right to remove any material deemed inconsistent with these terms, monitor communications, and terminate user access to the ZinGames Website. However, ZinGames is not liable for content provided by third parties.</li>
                            <li><b>Consequences of Non-Compliance:</b> Failure to adhere to these provisions may result in termination of access to the ZinGames Website and potential civil or criminal liabilities.</li>
                            <li><b>Compliance with Legal Standards:</b> Your use of the ZinGames Website must adhere to all applicable laws and regulations. Specifically, you agree not to:</li>
                            <ul class="list-disc list-inside mb-6 text-gray-300 pl-5">
                                <li><b>Advertising:</b> Post advertisements or solicitations of business.</li>
                                <li><b>Unauthorized Data Collection:</b> Collect information about others without their consent.</li>
                                <li><b>Unauthorized Access:</b> Intercept or attempt to intercept electronic mail not intended for you.</li>
                                <li><b>Misrepresentation:</b> Falsely represent an affiliation with any individual or organization.</li>
                                <li><b>Interference:</b> Restrict or inhibit others' use of the ZinGames Website.</li>
                                <li><b>Malicious Content:</b> Upload or transmit files containing viruses or corrupted data.</li>
                                <li><b>Privacy Violation:</b> Solicit, provide, or exchange personal information without consent.</li>
                                <li><b>Illegal Distribution:</b> Download or transmit software or files that cannot be legally distributed through the ZinGames Website.</li>
                                <li><b>Content Restrictions:</b> Upload or transmit any defamatory, indecent, obscene, harassing, violent, or otherwise objectionable material. This includes content that may be protected by copyright, without obtaining the necessary permissions.</li>
                                <li><b>Spam:</b> Post spam or engage in similar activities like transmitting chain letters.</li>
                                <li><b>Harassment:</b> Engage in stalking, phishing, or harassment of other users.</li>
                                <li><b>Violation of Rights:</b> Utilize the ZinGames Website to infringe upon the legal rights of others or to breach laws in any jurisdiction.</li>
                                <li><b>Conduct Limitation:</b> Conduct any activity that restricts or inhibits others' use or enjoyment of the ZinGames Website, or that may harm ZinGames or Website Visitors, as determined by ZinGames.</li>
                            </ul>
                        </ol>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">2. Safeguarding Personal Information</h3>
                        <p class="mb-6 text-gray-300">At ZinGames, we prioritize the protection of your privacy. We understand the importance of safeguarding your personal information. Our commitment to privacy is outlined in detail in our Website Privacy Policy.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">3. Age Requirement</h3>
                        <p class="mb-6 text-gray-300">To access and enjoy the offerings of the ZinGames Website, users must certify that they are at least 13 years old. Individuals under the age of 13 are encouraged to visit our ZinGames Kids website (the "kids.zingames.com Website"), designed specifically for younger audiences.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">4. Game Embedding Policy</h3>
                        <p class="mb-6 text-gray-300">At ZinGames, we offer the opportunity for other websites to embed portions of our gaming platform, ZinGames, through an iframe mechanism. However, this privilege comes with certain responsibilities and restrictions:</p>
                        <ul class="list-disc list-inside mb-6 text-gray-300 pl-5">
                            <li><b>Embedding Process:</b> ZinGames allows other websites to embed portions of our platform through an iframe, provided that the website includes an "embed" button to retrieve the iframe source code.</li>
                            <li><b>Advertising:</b> When games are embedded, they may contain in-game advertisements. These advertisements are an integral part of the gaming experience.</li>
                            <li><b>Qualification Withdrawal:</b> ApplySet Media reserves the right to withdraw qualification for embedding at any time. We may also block sites from embedding games at our discretion, without prior warning or the need to provide justification.</li>
                            <li><b>Prohibited Actions:</b> It is strictly forbidden to engage in certain actions such as reproducing, modifying, or interfering with the embedded content in ways that violate ZinGames' terms.</li>
                            <li><b>Discontinuation:</b> ApplySet Media reserves the right to discontinue an iframed portion of ZinGames at any time.</li>
                        </ul>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">5. User Profiles and Interactive Platforms</h3>
                        <p class="mb-6 text-gray-300">At ZinGames, we may introduce functionality allowing site visitors to share materials through the ZinGames platform. This includes profile pages and interactive services such as forums, message boards, chatting, commenting, and messaging features. However, it is important to adhere to our Rules of Conduct outlined in Section 1.</p>
                        
                        <p class="mb-6 text-gray-300"><b>Submission Responsibility:</b> Users are responsible for any materials they share on the ZinGames platform. ApplySet Media does not have control over, and cannot be held liable for, any use or misuse of these Submissions by third parties.</p>
                        
                        <p class="mb-6 text-gray-300"><b>Public Disclosure:</b> If you choose to make any personally identifiable or other information publicly available on ZinGames, you do so at your own risk. Please refer to Section 1 (V) of our Privacy Policy for details regarding the collection of personal information.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">6. Compatibility with Your Devices</h3>
                        <p class="mb-6 text-gray-300">It's essential to be aware that when utilizing downloadable applications from ApplySet Media, updates to your device's systems or firmware could potentially affect compatibility. We recommend checking your device specifications before downloading.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">7. Termination of Access</h3>
                        <p class="mb-6 text-gray-300">ZinGames reserves the right to terminate or suspend your access to the ZinGames Website, without prior notice or liability, if you violate these Terms of Use or if we believe that such action is necessary to protect the integrity and security of the website.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">8. Severability</h3>
                        <p class="mb-6 text-gray-300">If any provision of these Terms of Use is found to be invalid or unenforceable by a court of competent jurisdiction, the remaining provisions will remain in full force and effect. The invalid or unenforceable provision will be deemed modified to the minimum extent necessary to make it valid and enforceable.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">9. Entire Agreement</h3>
                        <p class="mb-6 text-gray-300">These Terms of Use constitute the entire agreement between you and ZinGames regarding the use of the ZinGames Website and supersede all prior agreements and understandings, whether written or oral, relating to the subject matter hereof.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">10. Amendments</h3>
                        <p class="mb-6 text-gray-300">ZinGames reserves the right to update or modify these Terms of Use at any time. Any changes will be effective immediately upon posting on the ZinGames Website. It is your responsibility to review these Terms of Use periodically to stay informed of any updates.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">11. User Feedback</h3>
                        <p class="mb-6 text-gray-300">We welcome feedback from our users to improve the ZinGames Website and its features. However, any feedback or suggestions you provide shall become the exclusive property of ZinGames, and we may use such feedback without any obligation to you.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">12. Third-Party Links</h3>
                        <p class="mb-6 text-gray-300">The ZinGames Website may contain links to third-party websites or services. These links are provided for your convenience and do not imply endorsement or responsibility for the content or practices of those third parties. You access such sites at your own risk.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">13. No Waiver</h3>
                        <p class="mb-6 text-gray-300">The failure of ZinGames to enforce any right or provision of these Terms of Use will not constitute a waiver of such right or provision. Any waiver of any provision of these Terms of Use will be effective only if in writing and signed by a duly authorized representative of ZinGames.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">14. Contact Information</h3>
                        <p class="mb-6 text-gray-300">If you have any questions, concerns, or complaints regarding these Terms of Use or the ZinGames Website, please reach out to us at:</p>
                        
                        <p class="mb-1 text-gray-300">Email: <a href="mailto:support@zingames.com" class="text-blue-500">support@zingames.com</a></p>
                        <p class="mb-6 text-gray-300">Address: 88, Gokul park, Utran, Chorasi, Surat- 394105, Gujarat, India</p>
                        
                        <p class="text-gray-300">Thank you for using ZinGames. We hope you enjoy our platform!</p>
                    </main>
                </div>
            </div>
        </section>
    </main>

    <!-- Include Footer -->
    @include('partials.footer')

    <!-- JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Sidebar Toggle
            const sidebar = document.getElementById('sidebar');
            const sidebarToggle = document.getElementById('sidebarToggle');
            const aboutContainer = document.getElementById('aboutContainer');

            sidebarToggle.addEventListener('click', () => {
                sidebar.classList.toggle('open');
                aboutContainer.classList.toggle('shifted');
                sidebarToggle.querySelector('i').classList.toggle('fa-bars');
                sidebarToggle.querySelector('i').classList.toggle('fa-times');
            });

            // Close sidebar on outside click
            document.addEventListener('click', (e) => {
                if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
                    sidebar.classList.remove('open');
                    aboutContainer.classList.remove('shifted');
                    sidebarToggle.querySelector('i').classList.remove('fa-times');
                    sidebarToggle.querySelector('i').classList.add('fa-bars');
                }
            });

            // Header scroll effect
            window.addEventListener('scroll', () => {
                const header = document.querySelector('.header');
                if (window.scrollY > 50) {
                    header.classList.add('scrolled');
                } else {
                    header.classList.remove('scrolled');
                }
            });
        });
    </script>
</body>

</html> 