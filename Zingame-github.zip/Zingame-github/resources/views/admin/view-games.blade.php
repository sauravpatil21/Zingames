@extends('layouts.admin')

@section('title', 'View Games')

@section('styles')
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Bootstrap Icons CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Font Awesome for additional icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'inter': ['Inter', 'sans-serif'],
                    },
                    colors: {
                        primary: {
                            50: '#eff6ff',
                            100: '#dbeafe',
                            500: '#3b82f6',
                            600: '#2563eb',
                            700: '#1d4ed8',
                            900: '#1e3a8a',
                        },
                        gray: {
                            50: '#f9fafb',
                            100: '#f3f4f6',
                            200: '#e5e7eb',
                            300: '#d1d5db',
                            400: '#9ca3af',
                            500: '#6b7280',
                            600: '#4b5563',
                            700: '#374151',
                            800: '#1f2937',
                            900: '#111827',
                        }
                    }
                }
            }
        }
    </script>
    
    <style>
        /* Custom scrollbar */
        .custom-scrollbar::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-track {
            background: #f1f5f9;
            border-radius: 3px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 3px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }
        
        /* Smooth transitions */
        .transition-all {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        /* Glass morphism effect */
        .glass-effect {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
        }
        
        /* Custom animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .animate-fade-in-up {
            animation: fadeInUp 0.6s ease-out;
        }
        
        /* Table hover effects */
        .table-row-hover:hover {
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        /* Button hover effects */
        .btn-modern {
            position: relative;
            overflow: hidden;
        }
        
        .btn-modern::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s;
        }
        
        .btn-modern:hover::before {
            left: 100%;
        }
        
        /* Search input focus effect */
        .search-input:focus {
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        /* Dropdown styling */
        .modern-dropdown {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        
        .modern-dropdown:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
    </style>
@endsection

@section('content')
<div class="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 p-4 sm:p-6 lg:p-8">
    <!-- Header Section -->
    <div class="max-w-7xl mx-auto animate-fade-in-up">
        <div class="mb-8">
            <h1 class="text-3xl sm:text-4xl font-bold text-gray-900 mb-2">
                Game Management
            </h1>
            <p class="text-gray-600 text-lg">
                Manage and organize your gaming platform's content
            </p>
        </div>

        <!-- Success Alert -->
        @if(session('success'))
            <div class="mb-6 p-4 bg-green-50 border border-green-200 rounded-xl shadow-sm">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <i class="bi bi-check-circle-fill text-green-500 text-xl"></i>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium text-green-800">
                            {{ session('success') }}
                        </p>
                    </div>
                    <div class="ml-auto pl-3">
                        <button type="button" class="text-green-500 hover:text-green-700" onclick="this.parentElement.parentElement.parentElement.remove()">
                            <i class="bi bi-x-lg"></i>
                        </button>
                    </div>
                </div>
            </div>
        @endif

        <!-- Main Content Card -->
        <div class="glass-effect rounded-2xl shadow-xl border border-white/20 overflow-hidden">
            <!-- Search and Filter Section -->
            <div class="p-4 sm:p-6 lg:p-8 border-b border-gray-200 bg-gradient-to-r from-white to-gray-50">
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 items-end">
                    <!-- Search Box -->
                    <div class="sm:col-span-2 lg:col-span-2">
                        <label for="searchInput" class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="bi bi-search mr-2"></i>Search Games
                        </label>
                        <div class="relative">
                            <input 
                                type="text" 
                                id="searchInput" 
                                placeholder="Search by game name, category, or hashtags..." 
                                class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm"
                            >
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="bi bi-search text-gray-400"></i>
                            </div>
                        </div>
                    </div>

                    <!-- Entries Per Page -->
                    <div>
                        <label for="perPageFilter" class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="bi bi-list-ul mr-2"></i>Show Entries
                        </label>
                        <select id="perPageFilter" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm modern-dropdown">
                            <option value="10">10 per page</option>
                            <option value="25">25 per page</option>
                            <option value="50">50 per page</option>
                            <option value="100">100 per page</option>
                        </select>
                    </div>

                    <!-- Category Filter -->
                    <div>
                        <label for="categoryFilter" class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="bi bi-funnel mr-2"></i>Category Filter
                        </label>
                        <select id="categoryFilter" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm modern-dropdown">
                            <option value="">All Categories</option>
                            @foreach($categories as $category)
                                <option value="{{ $category->id }}">{{ $category->name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
            </div>

            <!-- Table Section -->
            <div class="overflow-x-auto custom-scrollbar">
                <table class="w-full min-w-[800px]" id="gamesTable">
                    <thead class="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
                        <tr>
                            <th class="px-3 sm:px-6 py-3 sm:py-4 text-left text-xs sm:text-sm font-semibold tracking-wider">
                                <div class="flex items-center">
                                    <i class="bi bi-hash mr-1 sm:mr-2"></i>
                                    <span class="hidden sm:inline">#</span>
                                </div>
                            </th>
                            <th class="px-3 sm:px-6 py-3 sm:py-4 text-left text-xs sm:text-sm font-semibold tracking-wider">
                                <div class="flex items-center">
                                    <i class="bi bi-image mr-1 sm:mr-2"></i>
                                    <span class="hidden sm:inline">Image</span>
                                </div>
                            </th>
                            <th class="px-3 sm:px-6 py-3 sm:py-4 text-left text-xs sm:text-sm font-semibold tracking-wider">
                                <div class="flex items-center">
                                    <i class="bi bi-controller mr-1 sm:mr-2"></i>
                                    <span class="hidden sm:inline">Game Name</span>
                                </div>
                            </th>
                            <th class="px-3 sm:px-6 py-3 sm:py-4 text-left text-xs sm:text-sm font-semibold tracking-wider">
                                <div class="flex items-center">
                                    <i class="bi bi-tags mr-1 sm:mr-2"></i>
                                    <span class="hidden sm:inline">Category</span>
                                </div>
                            </th>
                            <th class="px-3 sm:px-6 py-3 sm:py-4 text-left text-xs sm:text-sm font-semibold tracking-wider">
                                <div class="flex items-center">
                                    <i class="bi bi-hash mr-1 sm:mr-2"></i>
                                    <span class="hidden sm:inline">Hashtags</span>
                                </div>
                            </th>
                            <th class="px-3 sm:px-6 py-3 sm:py-4 text-left text-xs sm:text-sm font-semibold tracking-wider">
                                <div class="flex items-center">
                                    <i class="bi bi-calendar-event mr-1 sm:mr-2"></i>
                                    <span class="hidden sm:inline">Release Date</span>
                                </div>
                            </th>
                            <th class="px-3 sm:px-6 py-3 sm:py-4 text-left text-xs sm:text-sm font-semibold tracking-wider">
                                <div class="flex items-center">
                                    <i class="bi bi-gear mr-1 sm:mr-2"></i>
                                    <span class="hidden sm:inline">Actions</span>
                                </div>
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        @forelse($games as $index => $game)
                        <tr class="game-row table-row-hover transition-all duration-200" data-name="{{ strtolower($game->name) }}" data-category="{{ $game->category_id }}">
                            <td class="px-3 sm:px-6 py-3 sm:py-4 whitespace-nowrap">
                                <span class="serial-number text-xs sm:text-sm font-medium text-gray-900 bg-gray-100 px-2 sm:px-3 py-1 rounded-full">
                                    {{ $index + 1 }}
                                </span>
                            </td>
                            <td class="px-3 sm:px-6 py-3 sm:py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    @if($game->image)
                                        <img 
                                            src="{{ asset('storage/' . $game->image) }}" 
                                            alt="{{ $game->name }}" 
                                            class="h-8 w-8 sm:h-12 sm:w-12 rounded-lg object-cover shadow-md border-2 border-gray-200 hover:border-blue-300 transition-all duration-200"
                                        >
                                    @else
                                        <div class="h-8 w-8 sm:h-12 sm:w-12 rounded-lg bg-gradient-to-br from-gray-200 to-gray-300 flex items-center justify-center shadow-md">
                                            <i class="bi bi-image text-gray-500 text-sm sm:text-lg"></i>
                                        </div>
                                    @endif
                                </div>
                            </td>
                            <td class="px-3 sm:px-6 py-3 sm:py-4">
                                <div class="flex items-center">
                                    <div>
                                        <div class="text-xs sm:text-sm font-semibold text-gray-900 group-hover:text-blue-600 transition-colors duration-200">
                                            {{ $game->name }}
                                        </div>
                                        <div class="text-xs sm:text-sm text-gray-500">
                                            ID: {{ $game->id }}
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-3 sm:px-6 py-3 sm:py-4 whitespace-nowrap">
                                @if($game->category)
                                    <span class="inline-flex items-center px-2 sm:px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                        <i class="bi bi-tag-fill mr-1"></i>
                                        <span class="hidden sm:inline">{{ $game->category->name }}</span>
                                        <span class="sm:hidden">{{ Str::limit($game->category->name, 8) }}</span>
                                    </span>
                                @else
                                    <span class="inline-flex items-center px-2 sm:px-3 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-600">
                                        <i class="bi bi-dash-circle mr-1"></i>
                                        <span class="hidden sm:inline">Uncategorized</span>
                                        <span class="sm:hidden">None</span>
                                    </span>
                                @endif
                            </td>
                            <td class="px-3 sm:px-6 py-3 sm:py-4">
                                <div class="text-xs sm:text-sm text-gray-900">
                                    @if($game->hashtags)
                                        <div class="flex flex-wrap gap-1">
                                            @foreach(explode(' ', $game->hashtags) as $hashtag)
                                                @if(trim($hashtag))
                                                    <span class="inline-flex items-center px-1 sm:px-2 py-1 rounded-md text-xs font-medium bg-purple-100 text-purple-800">
                                                        <span class="hidden sm:inline">{{ trim($hashtag) }}</span>
                                                        <span class="sm:hidden">{{ Str::limit(trim($hashtag), 6) }}</span>
                                                    </span>
                                                @endif
                                            @endforeach
                                        </div>
                                    @else
                                        <span class="text-gray-500 text-xs sm:text-sm">
                                            <i class="bi bi-dash-circle mr-1"></i>
                                            <span class="hidden sm:inline">No hashtags</span>
                                            <span class="sm:hidden">None</span>
                                        </span>
                                    @endif
                                </div>
                            </td>
                            <td class="px-3 sm:px-6 py-3 sm:py-4 whitespace-nowrap">
                                <div class="flex items-center text-xs sm:text-sm text-gray-900">
                                    <i class="bi bi-calendar3 mr-1 sm:mr-2 text-blue-500"></i>
                                    <span class="font-medium">
                                        <span class="hidden sm:inline">{{ \Carbon\Carbon::parse($game->release_date)->format('d M Y') }}</span>
                                        <span class="sm:hidden">{{ \Carbon\Carbon::parse($game->release_date)->format('d/m/Y') }}</span>
                                    </span>
                                </div>
                            </td>
                            <td class="px-3 sm:px-6 py-3 sm:py-4 whitespace-nowrap text-xs sm:text-sm font-medium">
                                <div class="flex flex-col sm:flex-row items-stretch sm:items-center space-y-2 sm:space-y-0 sm:space-x-2">
                                    <!-- Edit Button -->
                                    <a 
                                        href="{{ route('admin.games.edit', $game->id) }}" 
                                        class="btn-modern inline-flex items-center justify-center px-2 sm:px-3 py-2 border border-transparent text-xs sm:text-sm leading-4 font-medium rounded-lg text-white bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-200 shadow-sm"
                                        title="Edit this game"
                                    >
                                        <i class="bi bi-pencil-square mr-1"></i>
                                        <span class="hidden sm:inline">Edit</span>
                                        <span class="sm:hidden">Edit</span>
                                    </a>
                                    
                                    <!-- Delete Button -->
                                    <form action="{{ route('admin.games.destroy', $game->id) }}" method="POST" class="inline">
                                        @csrf
                                        @method('DELETE')
                                        <button 
                                            type="submit" 
                                            class="btn-modern inline-flex items-center justify-center px-2 sm:px-3 py-2 border border-transparent text-xs sm:text-sm leading-4 font-medium rounded-lg text-white bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-all duration-200 shadow-sm"
                                            onclick="return confirm('Are you sure you want to delete this game? This action cannot be undone.')"
                                            title="Delete this game permanently"
                                        >
                                            <i class="bi bi-trash3 mr-1"></i>
                                            <span class="hidden sm:inline">Delete</span>
                                            <span class="sm:hidden">Delete</span>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="7" class="px-6 py-12 text-center">
                                <div class="flex flex-col items-center">
                                    <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                                        <i class="bi bi-controller text-gray-400 text-2xl"></i>
                                    </div>
                                    <h3 class="text-lg font-medium text-gray-900 mb-2">No games found</h3>
                                    <p class="text-gray-500 mb-4">Get started by adding your first game to the platform.</p>
                                    <a href="{{ route('admin.add-game') }}" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-lg text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-200">
                                        <i class="bi bi-plus-circle mr-2"></i>
                                        Add New Game
                                    </a>
                                </div>
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <!-- Pagination Section -->
            <div class="px-4 sm:px-6 py-4 bg-gray-50 border-t border-gray-200">
                <div class="flex flex-col space-y-4 sm:space-y-0 sm:flex-row sm:items-center sm:justify-between">
                    <!-- Pagination Info -->
                    <div class="text-xs sm:text-sm text-gray-700 text-center sm:text-left">
                        <span class="font-medium">Showing</span>
                        <span id="startEntry" class="font-semibold text-blue-600">1</span>
                        <span class="font-medium">to</span>
                        <span id="endEntry" class="font-semibold text-blue-600">{{ min(count($games), 10) }}</span>
                        <span class="font-medium">of</span>
                        <span id="totalEntries" class="font-semibold text-blue-600">{{ count($games) }}</span>
                        <span class="font-medium">entries</span>
                    </div>

                    <!-- Pagination Controls -->
                    <nav class="flex flex-col sm:flex-row items-center space-y-2 sm:space-y-0 sm:space-x-2" id="pagination">
                        <button id="prevPage" class="relative inline-flex items-center justify-center px-3 py-2 text-xs sm:text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 w-full sm:w-auto">
                            <i class="bi bi-chevron-left mr-1"></i>
                            <span class="hidden sm:inline">Previous</span>
                            <span class="sm:hidden">Prev</span>
                        </button>
                        
                        <div class="flex items-center space-x-1" id="pageNumbers">
                            <!-- Page numbers will be added dynamically -->
                        </div>
                        
                        <button id="nextPage" class="relative inline-flex items-center justify-center px-3 py-2 text-xs sm:text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 w-full sm:w-auto">
                            <span class="hidden sm:inline">Next</span>
                            <span class="sm:hidden">Next</span>
                            <i class="bi bi-chevron-right ml-1"></i>
                        </button>
                    </nav>
                </div>
            </div>
        </div>

        <!-- Quick Actions Footer -->
        <div class="mt-6 sm:mt-8 flex flex-col space-y-4 sm:space-y-0 sm:flex-row sm:items-center sm:justify-between">
            <div class="text-xs sm:text-sm text-gray-600 text-center sm:text-left">
                <i class="bi bi-info-circle mr-1"></i>
                Manage your gaming platform's content efficiently
            </div>
            <div class="flex flex-col sm:flex-row items-stretch sm:items-center space-y-3 sm:space-y-0 sm:space-x-3">
                <a href="{{ route('admin.add-game') }}" class="inline-flex items-center justify-center px-4 py-2 border border-transparent text-xs sm:text-sm font-medium rounded-lg text-white bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-all duration-200 shadow-sm">
                    <i class="bi bi-plus-circle mr-2"></i>
                    <span class="hidden sm:inline">Add New Game</span>
                    <span class="sm:hidden">Add Game</span>
                </a>
                <a href="{{ route('admin.dashboard') }}" class="inline-flex items-center justify-center px-4 py-2 border border-gray-300 text-xs sm:text-sm font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-200 shadow-sm">
                    <i class="bi bi-arrow-left mr-2"></i>
                    <span class="hidden sm:inline">Back to Dashboard</span>
                    <span class="sm:hidden">Dashboard</span>
                </a>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
    <!-- Bootstrap 5 JS CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Initialize variables
            const searchInput = document.getElementById('searchInput');
            const perPageFilter = document.getElementById('perPageFilter');
            const categoryFilter = document.getElementById('categoryFilter');
            const gamesTable = document.getElementById('gamesTable');
            const gameRows = document.querySelectorAll('.game-row');
            const pagination = document.getElementById('pagination');
            const prevPageBtn = document.getElementById('prevPage');
            const nextPageBtn = document.getElementById('nextPage');
            const startEntry = document.getElementById('startEntry');
            const endEntry = document.getElementById('endEntry');
            const totalEntries = document.getElementById('totalEntries');
            const pageNumbers = document.getElementById('pageNumbers');

            let currentPage = 1;
            let itemsPerPage = 10;
            let filteredRows = [...gameRows];

            // Initialize pagination
            function initPagination() {
                // Clear existing page numbers
                pageNumbers.innerHTML = '';

                // Calculate total pages
                const totalPages = Math.ceil(filteredRows.length / itemsPerPage);
                
                // Update total entries
                totalEntries.textContent = filteredRows.length;
                
                // If no pages, show "No results"
                if (totalPages === 0) {
                    startEntry.textContent = '0';
                    endEntry.textContent = '0';
                    prevPageBtn.disabled = true;
                    nextPageBtn.disabled = true;
                    return;
                }

                // Reset current page if it's beyond the total pages
                if (currentPage > totalPages) {
                    currentPage = 1;
                }

                // Add page numbers
                for (let i = 1; i <= totalPages; i++) {
                    const pageBtn = document.createElement('button');
                    pageBtn.className = `relative inline-flex items-center justify-center px-2 sm:px-3 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all duration-200 ${
                        i === currentPage 
                            ? 'text-white bg-blue-600 border border-blue-600' 
                            : 'text-gray-500 bg-white border border-gray-300 hover:bg-gray-50'
                    }`;
                    pageBtn.textContent = i;
                    pageBtn.addEventListener('click', () => {
                        currentPage = i;
                        updateTable();
                    });
                    
                    pageNumbers.appendChild(pageBtn);
                }

                // Update prev/next buttons
                prevPageBtn.disabled = currentPage === 1;
                nextPageBtn.disabled = currentPage === totalPages;
            }

            // Update table based on filters and pagination
            function updateTable() {
                // Apply filters
                const searchTerm = searchInput.value.toLowerCase();
                const categoryId = categoryFilter.value;
                
                filteredRows = [...gameRows].filter(row => {
                    const gameName = row.getAttribute('data-name');
                    const gameCategory = row.getAttribute('data-category');
                    
                    const matchesSearch = gameName.includes(searchTerm);
                    const matchesCategory = categoryId === '' || gameCategory === categoryId;
                    
                    return matchesSearch && matchesCategory;
                });

                // Hide all rows
                gameRows.forEach(row => {
                    row.style.display = 'none';
                });

                // Show filtered rows for current page
                const startIndex = (currentPage - 1) * itemsPerPage;
                const endIndex = Math.min(startIndex + itemsPerPage, filteredRows.length);
                
                // Update pagination info
                startEntry.textContent = filteredRows.length > 0 ? startIndex + 1 : 0;
                endEntry.textContent = endIndex;
                
                // Update serial numbers and show rows
                filteredRows.slice(startIndex, endIndex).forEach((row, index) => {
                    row.style.display = '';
                    row.querySelector('.serial-number').textContent = startIndex + index + 1;
                });

                // Reinitialize pagination
                initPagination();
            }

            // Event listeners for search and filters
            searchInput.addEventListener('input', () => {
                currentPage = 1;
                updateTable();
            });

            perPageFilter.addEventListener('change', () => {
                itemsPerPage = parseInt(perPageFilter.value);
                currentPage = 1;
                updateTable();
            });

            categoryFilter.addEventListener('change', () => {
                currentPage = 1;
                updateTable();
            });

            // Pagination button event listeners
            prevPageBtn.addEventListener('click', () => {
                if (currentPage > 1) {
                    currentPage--;
                    updateTable();
                }
            });

            nextPageBtn.addEventListener('click', () => {
                const totalPages = Math.ceil(filteredRows.length / itemsPerPage);
                if (currentPage < totalPages) {
                    currentPage++;
                    updateTable();
                }
            });

            // Initialize table
            updateTable();

            // Auto-hide alerts after 5 seconds
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.style.opacity = '0';
                    setTimeout(() => alert.remove(), 300);
                }, 5000);
            });

            // Add loading states to buttons
            const actionButtons = document.querySelectorAll('.btn-modern');
            actionButtons.forEach(button => {
                button.addEventListener('click', function() {
                    if (this.type === 'submit') {
                        this.innerHTML = '<i class="bi bi-hourglass-split mr-1 animate-spin"></i>Processing...';
                        this.disabled = true;
                    }
                });
            });

            // Add tooltips for action buttons
            const tooltipButtons = document.querySelectorAll('[title]');
            tooltipButtons.forEach(button => {
                button.addEventListener('mouseenter', function(e) {
                    const tooltip = document.createElement('div');
                    tooltip.className = 'absolute z-50 px-2 py-1 text-xs text-white bg-gray-900 rounded shadow-lg';
                    tooltip.textContent = this.getAttribute('title');
                    tooltip.style.left = e.pageX + 10 + 'px';
                    tooltip.style.top = e.pageY - 30 + 'px';
                    document.body.appendChild(tooltip);
                    
                    this._tooltip = tooltip;
                });
                
                button.addEventListener('mouseleave', function() {
                    if (this._tooltip) {
                        this._tooltip.remove();
                        this._tooltip = null;
                    }
                });
            });
        });
    </script>
@endsection
