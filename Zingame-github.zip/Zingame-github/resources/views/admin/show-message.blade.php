@extends('layouts.admin')

@section('title', 'View Message')

@section('styles')
<style>
    .message-container {
        background: white;
        border-radius: var(--border-radius);
        box-shadow: var(--box-shadow);
        padding: 2rem;
        margin-bottom: 2rem;
        transition: all 0.3s ease;
    }
    
    .message-header {
        border-bottom: 1px solid #eee;
        padding-bottom: 1.5rem;
        margin-bottom: 1.5rem;
    }
    
    .message-content {
        padding: 1.5rem;
        background: #f9fafb;
        border-radius: var(--border-radius);
        margin-bottom: 2rem;
        border-left: 4px solid var(--primary-color);
    }
    
    .message-actions {
        margin-top: 1.5rem;
        display: flex;
        gap: 1rem;
        justify-content: flex-end;
    }
    
    .sender-info {
        display: flex;
        align-items: center;
        margin-bottom: 1rem;
    }
    
    .sender-avatar {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background: var(--primary-color);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        font-weight: 600;
        margin-right: 1rem;
    }
    
    .message-meta {
        display: flex;
        flex-wrap: wrap;
        gap: 1.5rem;
        margin-top: 0.5rem;
        color: #6b7280;
        font-size: 0.9rem;
    }
    
    .message-meta-item {
        display: flex;
        align-items: center;
    }
    
    .message-meta-item i {
        margin-right: 0.5rem;
        color: var(--primary-color);
    }
    
    .card-header-actions {
        display: flex;
        gap: 0.5rem;
    }
    
    .reply-section {
        margin-top: 2rem;
        border-top: 1px solid #eee;
        padding-top: 2rem;
    }
</style>
@endsection

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="message-container">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h3 class="mb-0">
                        <i class="bi bi-envelope-open me-2"></i>Message Details
                    </h3>
                    <div class="card-header-actions">
                        <a href="{{ route('admin.messages.index') }}" class="btn btn-outline-secondary">
                            <i class="bi bi-arrow-left"></i> Back
                        </a>
                        <form action="{{ route('admin.messages.destroy', $message->id) }}" method="POST" class="d-inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-outline-danger" 
                                onclick="return confirm('Are you sure you want to delete this message? This action cannot be undone.')">
                                <i class="bi bi-trash"></i> Delete
                            </button>
                        </form>
                    </div>
                </div>
                
                <div class="message-header">
                    <div class="sender-info">
                        <div class="sender-avatar">
                            {{ substr($message->name, 0, 1) }}
                        </div>
                        <div>
                            <h4 class="mb-0">{{ $message->name }}</h4>
                            <a href="mailto:{{ $message->email }}" class="text-decoration-none">{{ $message->email }}</a>
                            @php
                                $blocked = App\Models\BlockedEmail::where('email', $message->email)->where('is_blocked', true)->first();
                            @endphp
                            @if($blocked)
                                <span class="ms-2 badge bg-danger">Blocked</span>
                            @endif
                        </div>
                    </div>
                    
                    <h5 class="message-subject fw-bold">{{ $message->subject }}</h5>
                    
                    <div class="message-meta">
                        <div class="message-meta-item">
                            <i class="bi bi-clock"></i>
                            <span>{{ $message->created_at->format('M d, Y H:i') }}</span>
                        </div>
                        <div class="message-meta-item">
                            <i class="bi bi-check-circle"></i>
                            <span>{{ $message->is_read ? 'Read' : 'Unread' }}</span>
                        </div>
                        <div class="message-meta-item">
                            <i class="bi bi-hash"></i>
                            <span>ID: {{ $message->id }}</span>
                        </div>
                    </div>
                </div>
                
                <div class="message-content">
                    {{ $message->message }}
                </div>
                
                <div class="message-actions mt-4">
                    @if($blocked)
                        <form action="{{ route('admin.messages.unblock-email', $message->id) }}" method="POST" class="d-inline">
                            @csrf
                            <button type="submit" class="btn btn-success"><i class="bi bi-unlock"></i> Unblock Email</button>
                        </form>
                    @else
                        <form action="{{ route('admin.messages.block-email', $message->id) }}" method="POST" class="d-inline">
                            @csrf
                            <button type="submit" class="btn btn-warning"><i class="bi bi-lock"></i> Block Email</button>
                        </form>
                    @endif
                </div>
                
                <div class="reply-section">
                    <h5 class="mb-3"><i class="bi bi-reply me-2"></i>Reply to Message</h5>
                    <form id="replyForm">
                        <div class="mb-3">
                            <textarea class="form-control" id="replyMessage" rows="5" 
                                placeholder="Type your reply here..."></textarea>
                        </div>
                        <div class="d-flex justify-content-end">
                            <button type="button" class="btn btn-primary" id="sendReplyBtn">
                                <i class="bi bi-send me-2"></i>Send Reply
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Mark as read functionality if needed
        @if(!$message->is_read)
            fetch('{{ route("admin.messages.mark-read", $message->id) }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            });
        @endif
        
        // Reply email functionality (this is just a frontend demo)
        const sendReplyBtn = document.getElementById('sendReplyBtn');
        const replyMessage = document.getElementById('replyMessage');
        
        sendReplyBtn.addEventListener('click', function() {
            if (replyMessage.value.trim() === '') {
                alert('Please enter a reply message');
                return;
            }
            
            // Here you would normally send the reply via AJAX
            sendReplyBtn.innerHTML = '<div class="spinner-border spinner-border-sm me-2"></div> Sending...';
            sendReplyBtn.disabled = true;
            
            // Simulate sending
            setTimeout(() => {
                alert('Reply sent to {{ $message->email }}');
                replyMessage.value = '';
                sendReplyBtn.innerHTML = '<i class="bi bi-send me-2"></i>Send Reply';
                sendReplyBtn.disabled = false;
            }, 1500);
        });
    });
</script>
@endsection 
