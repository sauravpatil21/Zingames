@extends('layouts.admin')

@section('title', 'Manage Categories')

@section('styles')
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Bootstrap Icons CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Font Awesome for additional icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'inter': ['Inter', 'sans-serif'],
                        'poppins': ['Poppins', 'sans-serif'],
                    },
                    colors: {
                        primary: {
                            50: '#eff6ff',
                            100: '#dbeafe',
                            500: '#3b82f6',
                            600: '#2563eb',
                            700: '#1d4ed8',
                            900: '#1e3a8a',
                        },
                        success: {
                            50: '#f0fdf4',
                            500: '#22c55e',
                            600: '#16a34a',
                        },
                        warning: {
                            50: '#fffbeb',
                            500: '#f59e0b',
                            600: '#d97706',
                        },
                        danger: {
                            50: '#fef2f2',
                            500: '#ef4444',
                            600: '#dc2626',
                        }
                    },
                    animation: {
                        'fade-in-up': 'fadeInUp 0.6s ease-out',
                        'slide-in': 'slideIn 0.5s ease-out',
                        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
                        'shake': 'shake 0.5s ease-in-out',
                        'float': 'float 6s ease-in-out infinite',
                    }
                }
            }
        }
    </script>
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Poppins:wght@300;400;500;600;700;800&display=swap');
        
        /* Custom animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }
        
        /* Glass morphism effect */
        .glass-effect {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        /* Particles background */
        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: -1;
            overflow: hidden;
        }

        .particle {
            position: absolute;
            width: 4px;
            height: 4px;
            background: rgba(59, 130, 246, 0.3);
            border-radius: 50%;
            animation: float 6s ease-in-out infinite;
        }
        
        .particle:nth-child(1) { left: 10%; animation-delay: 0s; }
        .particle:nth-child(2) { left: 20%; animation-delay: 1s; }
        .particle:nth-child(3) { left: 30%; animation-delay: 2s; }
        .particle:nth-child(4) { left: 40%; animation-delay: 3s; }
        .particle:nth-child(5) { left: 50%; animation-delay: 4s; }
        .particle:nth-child(6) { left: 60%; animation-delay: 5s; }
        .particle:nth-child(7) { left: 70%; animation-delay: 1.5s; }
        .particle:nth-child(8) { left: 80%; animation-delay: 2.5s; }
        .particle:nth-child(9) { left: 90%; animation-delay: 3.5s; }
        
        /* Form input focus effects */
        .form-input:focus {
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
            border-color: #3b82f6;
        }
        
        .form-input.error {
            border-color: #ef4444;
            box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
            animation: shake 0.5s ease-in-out;
        }
        
        /* Button hover effects */
        .btn-gradient {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            transition: all 0.3s ease;
        }
        
        .btn-gradient:hover {
            background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
        }
        
        .btn-success-gradient {
            background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
            transition: all 0.3s ease;
        }
        
        .btn-success-gradient:hover {
            background: linear-gradient(135deg, #16a34a 0%, #22c55e 100%);
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(34, 197, 94, 0.3);
        }
        
        .btn-danger-gradient {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            transition: all 0.3s ease;
        }
        
        .btn-danger-gradient:hover {
            background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%);
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(239, 68, 68, 0.3);
        }
        
        /* Loading spinner */
        .spinner {
            border: 2px solid #f3f4f6;
            border-top: 2px solid #3b82f6;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* Custom scrollbar */
        .custom-scrollbar::-webkit-scrollbar {
            width: 6px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-track {
            background: #f1f5f9;
            border-radius: 3px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 3px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }
        
        /* Table hover effects */
        .table-row-hover:hover {
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        /* Modal styling */
        .modal-content {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 16px;
        }
        
        /* Tooltip */
        .tooltip {
            position: relative;
        }
        
        .tooltip .tooltip-text {
            visibility: hidden;
            width: 200px;
            background-color: #1f2937;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 8px 12px;
            position: absolute;
            z-index: 1;
            bottom: 125%;
            left: 50%;
            margin-left: -100px;
            opacity: 0;
            transition: opacity 0.3s;
            font-size: 0.875rem;
        }
        
        .tooltip:hover .tooltip-text {
            visibility: visible;
            opacity: 1;
        }
    </style>
@endsection

@section('content')
    <!-- Particles Background -->
    <div class="particles">
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
    </div>

<div class="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 p-4 sm:p-6 lg:p-8">
    <div class="max-w-6xl mx-auto animate-fade-in-up">
        <!-- Header Section -->
        <div class="mb-6 sm:mb-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4 space-y-4 sm:space-y-0">
                <div>
                    <h1 class="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-2">
                        Manage Categories
                    </h1>
                    <p class="text-gray-600 text-base sm:text-lg">
                        Create and organize game categories for better content management
                    </p>
                </div>
                <div class="flex items-center space-x-3">
                    <a href="{{ route('admin.dashboard') }}" class="inline-flex items-center justify-center px-3 sm:px-4 py-2 border border-gray-300 text-xs sm:text-sm font-medium rounded-xl text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-200 shadow-sm">
                        <i class="bi bi-arrow-left mr-1 sm:mr-2"></i>
                        <span class="hidden sm:inline">Back to Dashboard</span>
                        <span class="sm:hidden">Dashboard</span>
                    </a>
                </div>
            </div>
            
            <!-- Breadcrumb -->
            <nav class="flex overflow-x-auto" aria-label="Breadcrumb">
                <ol class="inline-flex items-center space-x-1 md:space-x-3 min-w-max">
                    <li class="inline-flex items-center">
                        <a href="{{ route('admin.dashboard') }}" class="inline-flex items-center text-xs sm:text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors duration-200">
                            <i class="bi bi-house-door mr-1 sm:mr-2"></i>
                            <span class="hidden sm:inline">Dashboard</span>
                            <span class="sm:hidden">Home</span>
                        </a>
                    </li>
                    <li>
                        <div class="flex items-center">
                            <i class="bi bi-chevron-right text-gray-400 mx-1 sm:mx-2"></i>
                            <span class="text-xs sm:text-sm font-medium text-gray-500">
                                <span class="hidden sm:inline">Manage Categories</span>
                                <span class="sm:hidden">Categories</span>
                            </span>
                        </div>
                    </li>
                </ol>
            </nav>
        </div>

        <!-- Success Alert -->
        @if(session('success'))
            <div class="mb-6 p-4 bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl shadow-sm">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <i class="bi bi-check-circle-fill text-green-500 text-xl"></i>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium text-green-800">
                            {{ session('success') }}
                        </p>
                    </div>
                    <div class="ml-auto pl-3">
                        <button type="button" class="text-green-500 hover:text-green-700" onclick="this.parentElement.parentElement.parentElement.remove()">
                            <i class="bi bi-x-lg"></i>
                        </button>
                    </div>
                </div>
            </div>
        @endif

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
            <!-- Add Category Form Card -->
            <div class="glass-effect rounded-2xl shadow-xl overflow-hidden">
                <div class="p-4 sm:p-6 lg:p-8">
                    <div class="flex items-center mb-4 sm:mb-6">
                        <div class="w-8 h-8 sm:w-10 sm:h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3 sm:mr-4">
                            <i class="bi bi-plus-circle text-blue-600 text-lg sm:text-xl"></i>
                        </div>
                        <div>
                            <h2 class="text-lg sm:text-xl font-semibold text-gray-900">Add New Category</h2>
                            <p class="text-gray-600 text-xs sm:text-sm">Create a new game category</p>
                        </div>
                    </div>
                    
                    <form method="POST" action="{{ route('admin.categories.store') }}" id="addCategoryForm">
                        @csrf
                        
                        <!-- Category Name -->
                        <div class="form-group mb-4 sm:mb-6">
                            <label for="category-name" class="block text-xs sm:text-sm font-semibold text-gray-700 mb-2">
                                <i class="bi bi-tag-fill mr-1 sm:mr-2 text-blue-500"></i>
                                Category Name <span class="text-red-500">*</span>
                            </label>
                            <div class="relative">
                                <input 
                                    type="text" 
                                    id="category-name" 
                                    name="category_name" 
                                    value="{{ old('category_name') }}" 
                                    required 
                                    placeholder="Enter category name (e.g., Action, Adventure, Puzzle)"
                                    class="w-full pl-8 sm:pl-10 pr-4 py-2 sm:py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm form-input @error('category_name') error @enderror"
                                >
                                <div class="absolute inset-y-0 left-0 pl-2 sm:pl-3 flex items-center pointer-events-none">
                                    <i class="bi bi-tags text-gray-400"></i>
                                </div>
                            </div>
                            @error('category_name')
                                <p class="mt-1 text-xs sm:text-sm text-red-600 flex items-center">
                                    <i class="bi bi-exclamation-circle mr-1"></i>
                                    {{ $message }}
                                </p>
                            @enderror
                            <p class="mt-1 text-xs sm:text-sm text-gray-500">
                                <i class="bi bi-info-circle mr-1"></i>
                                Choose a descriptive name that helps users find games
                            </p>
                        </div>

                        <!-- Submit Button -->
                        <button 
                            type="submit" 
                            class="btn-gradient w-full inline-flex items-center justify-center px-4 sm:px-6 py-2 sm:py-3 border border-transparent text-xs sm:text-sm font-semibold rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 shadow-lg"
                            id="submitBtn"
                        >
                            <i class="bi bi-plus-circle mr-1 sm:mr-2"></i>
                            <span id="submitText">
                                <span class="hidden sm:inline">Add Category</span>
                                <span class="sm:hidden">Add</span>
                            </span>
                            <div id="loadingSpinner" class="spinner ml-1 sm:ml-2 hidden"></div>
                        </button>
                    </form>
                </div>
            </div>

            <!-- Categories List Card -->
            <div class="glass-effect rounded-2xl shadow-xl overflow-hidden">
                <div class="p-4 sm:p-6 lg:p-8">
                    <div class="flex items-center mb-4 sm:mb-6">
                        <div class="w-8 h-8 sm:w-10 sm:h-10 bg-purple-100 rounded-lg flex items-center justify-center mr-3 sm:mr-4">
                            <i class="bi bi-collection text-purple-600 text-lg sm:text-xl"></i>
                        </div>
                        <div>
                            <h2 class="text-lg sm:text-xl font-semibold text-gray-900">Existing Categories</h2>
                            <p class="text-gray-600 text-xs sm:text-sm">Manage your game categories</p>
                        </div>
                    </div>
                    
                    <div class="overflow-x-auto custom-scrollbar">
                        <table class="w-full min-w-[400px]">
                            <thead class="bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
                                <tr>
                                    <th class="px-3 sm:px-6 py-3 sm:py-4 text-left text-xs sm:text-sm font-semibold tracking-wider">
                                        <div class="flex items-center">
                                            <i class="bi bi-hash mr-1 sm:mr-2"></i>
                                            <span class="hidden sm:inline">ID</span>
                                        </div>
                                    </th>
                                    <th class="px-3 sm:px-6 py-3 sm:py-4 text-left text-xs sm:text-sm font-semibold tracking-wider">
                                        <div class="flex items-center">
                                            <i class="bi bi-tag mr-1 sm:mr-2"></i>
                                            <span class="hidden sm:inline">Category Name</span>
                                            <span class="sm:hidden">Name</span>
                                        </div>
                                    </th>
                                    <th class="px-3 sm:px-6 py-3 sm:py-4 text-left text-xs sm:text-sm font-semibold tracking-wider">
                                        <div class="flex items-center">
                                            <i class="bi bi-gear mr-1 sm:mr-2"></i>
                                            <span class="hidden sm:inline">Actions</span>
                                            <span class="sm:hidden">Actions</span>
                                        </div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                @forelse($categories ?? [] as $category)
                                <tr class="table-row-hover transition-all duration-200" data-id="{{ $category->id }}">
                                    <td class="px-3 sm:px-6 py-3 sm:py-4 whitespace-nowrap">
                                        <span class="text-xs sm:text-sm font-medium text-gray-900 bg-gray-100 px-2 sm:px-3 py-1 rounded-full">
                                            {{ $category->id }}
                                        </span>
                                    </td>
                                    <td class="px-3 sm:px-6 py-3 sm:py-4">
                                        <div class="flex items-center">
                                            <div>
                                                <div class="text-xs sm:text-sm font-semibold text-gray-900">
                                                    {{ $category->name }}
                                                </div>
                                                <div class="text-xs sm:text-sm text-gray-500">
                                                    Category ID: {{ $category->id }}
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-3 sm:px-6 py-3 sm:py-4 whitespace-nowrap text-xs sm:text-sm font-medium">
                                        <div class="flex flex-col sm:flex-row items-stretch sm:items-center space-y-2 sm:space-y-0 sm:space-x-2">
                                            <button 
                                                type="button"
                                                class="btn-success-gradient inline-flex items-center justify-center px-2 sm:px-3 py-2 border border-transparent text-xs sm:text-sm leading-4 font-medium rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-all duration-200 shadow-sm"
                                                data-bs-toggle="modal" 
                                                data-bs-target="#editModal"
                                                data-id="{{ $category->id }}" 
                                                data-name="{{ $category->name }}"
                                                title="Edit this category"
                                            >
                                                <i class="bi bi-pencil-square mr-1"></i>
                                                <span class="hidden sm:inline">Edit</span>
                                                <span class="sm:hidden">Edit</span>
                                            </button>
                                            
                                            <form action="{{ route('admin.categories.destroy', $category->id) }}" method="POST" class="inline">
                                                @csrf
                                                @method('DELETE')
                                                <button 
                                                    type="submit" 
                                                    class="btn-danger-gradient inline-flex items-center justify-center px-2 sm:px-3 py-2 border border-transparent text-xs sm:text-sm leading-4 font-medium rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-all duration-200 shadow-sm"
                                                    onclick="return confirm('Are you sure you want to delete this category? This action cannot be undone.')"
                                                    title="Delete this category permanently"
                                                >
                                                    <i class="bi bi-trash3 mr-1"></i>
                                                    <span class="hidden sm:inline">Delete</span>
                                                    <span class="sm:hidden">Delete</span>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="3" class="px-3 sm:px-6 py-8 sm:py-12 text-center">
                                        <div class="flex flex-col items-center">
                                            <div class="w-12 h-12 sm:w-16 sm:h-16 bg-gray-100 rounded-full flex items-center justify-center mb-3 sm:mb-4">
                                                <i class="bi bi-collection text-gray-400 text-lg sm:text-2xl"></i>
                                            </div>
                                            <h3 class="text-sm sm:text-lg font-medium text-gray-900 mb-1 sm:mb-2">No categories found</h3>
                                            <p class="text-xs sm:text-sm text-gray-500 mb-3 sm:mb-4">Get started by adding your first category.</p>
                                        </div>
                                    </td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header border-b border-gray-200 pb-4">
                <h5 class="modal-title text-lg sm:text-xl font-semibold text-gray-900" id="editModalLabel">
                    Edit Category
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="editCategoryForm" method="POST" action="">
                @csrf
                @method('PUT')
                <div class="modal-body py-4">
                    <input type="hidden" id="edit-category-id" name="category_id">
                    <div class="form-group">
                        <label for="edit-category-name" class="block text-xs sm:text-sm font-semibold text-gray-700 mb-2">
                            <i class="bi bi-tag-fill mr-1 sm:mr-2 text-blue-500"></i>
                            Category Name <span class="text-red-500">*</span>
                        </label>
                        <div class="relative">
                            <input 
                                type="text" 
                                id="edit-category-name" 
                                name="category_name" 
                                required
                                placeholder="Enter category name"
                                class="w-full pl-8 sm:pl-10 pr-4 py-2 sm:py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm form-input"
                            >
                            <div class="absolute inset-y-0 left-0 pl-2 sm:pl-3 flex items-center pointer-events-none">
                                <i class="bi bi-tags text-gray-400"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-t border-gray-200 pt-4">
                    <button type="button" class="inline-flex items-center justify-center px-4 py-2 border border-gray-300 text-xs sm:text-sm font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-200 shadow-sm" data-bs-dismiss="modal">
                        <i class="bi bi-x mr-1 sm:mr-2"></i>
                        <span class="hidden sm:inline">Cancel</span>
                        <span class="sm:hidden">Cancel</span>
                    </button>
                    <button type="submit" class="btn-gradient inline-flex items-center justify-center px-4 py-2 border border-transparent text-xs sm:text-sm font-semibold rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-200 shadow-sm" id="saveBtn">
                        <i class="bi bi-save mr-1 sm:mr-2"></i>
                        <span class="hidden sm:inline">Save Changes</span>
                        <span class="sm:hidden">Save</span>
                        <div id="saveSpinner" class="spinner ml-1 sm:ml-2 hidden"></div>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@section('scripts')
    <!-- Bootstrap 5 JS CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Form Validation and Submission
            const form = document.getElementById('addCategoryForm');
            const submitBtn = document.getElementById('submitBtn');
            const submitText = document.getElementById('submitText');
            const loadingSpinner = document.getElementById('loadingSpinner');
            const categoryInput = document.getElementById('category-name');

            form.addEventListener('submit', (e) => {
                // Validate input
                if (!categoryInput.value.trim()) {
                    e.preventDefault();
                    categoryInput.classList.add('error');
                    return;
                }
                
                // Show loading state
                submitText.style.display = 'none';
                loadingSpinner.classList.remove('hidden');
                submitBtn.disabled = true;
            });

            // Remove error class on input
            categoryInput.addEventListener('input', function() {
                if (this.value.trim()) {
                    this.classList.remove('error');
                }
            });

            // Edit Modal Functionality
            const editModal = document.getElementById('editModal');
            if (editModal) {
                editModal.addEventListener('show.bs.modal', (event) => {
                    const button = event.relatedTarget;
                    const categoryId = button.getAttribute('data-id');
                    const categoryName = button.getAttribute('data-name');

                    const modalTitle = editModal.querySelector('.modal-title');
                    const categoryIdInput = editModal.querySelector('#edit-category-id');
                    const categoryNameInput = editModal.querySelector('#edit-category-name');
                    const form = editModal.querySelector('#editCategoryForm');

                    modalTitle.textContent = `Edit Category: ${categoryName}`;
                    categoryIdInput.value = categoryId;
                    categoryNameInput.value = categoryName;
                    form.action = `{{ url('/admin/categories') }}/${categoryId}`;
                });
            }

            // Edit form submission
            const editForm = document.getElementById('editCategoryForm');
            const saveBtn = document.getElementById('saveBtn');
            const saveSpinner = document.getElementById('saveSpinner');

            if (editForm) {
                editForm.addEventListener('submit', (e) => {
                    const categoryNameInput = editForm.querySelector('#edit-category-name');
                    
                    if (!categoryNameInput.value.trim()) {
                        e.preventDefault();
                        categoryNameInput.classList.add('error');
                        return;
                    }
                    
                    // Show loading state
                    saveBtn.innerHTML = '<i class="bi bi-hourglass-split mr-1 sm:mr-2 animate-spin"></i><span class="hidden sm:inline">Saving...</span><span class="sm:hidden">Saving...</span>';
                    saveBtn.disabled = true;
                });
            }

            // Auto-hide alerts after 5 seconds
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.style.opacity = '0';
                    setTimeout(() => alert.remove(), 300);
                }, 5000);
            });

            // Real-time validation feedback
            const inputs = document.querySelectorAll('input[required]');
            inputs.forEach(input => {
                input.addEventListener('blur', function() {
                    if (!this.value.trim()) {
                        this.classList.add('error');
                    } else {
                        this.classList.remove('error');
                    }
                });

                input.addEventListener('input', function() {
                    if (this.value.trim()) {
                        this.classList.remove('error');
                    }
                });
            });
        });
    </script>
@endsection

