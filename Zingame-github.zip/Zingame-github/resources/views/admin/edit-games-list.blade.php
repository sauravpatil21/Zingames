@extends('layouts.admin')

@section('title', 'Edit Games')

@section('styles')
    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #1a252f, #16213e);
            color: #e0e0e0;
            min-height: 100vh;
        }
        .games-list-container {
            background: linear-gradient(145deg, rgba(255,255,255,0.05), rgba(0,0,0,0.1));
            border-radius: 18px;
            padding: 32px 24px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.2);
            margin: 40px auto;
            max-width: 1200px;
            border: 1px solid rgba(255,255,255,0.08);
        }
        .games-list-title {
            font-size: 2.3rem;
            font-weight: 700;
            color: #fff;
            margin-bottom: 30px;
            text-align: center;
            text-shadow: 0 0 10px rgba(0,212,255,0.2);
        }
        .games-table {
            background: rgba(255,255,255,0.03);
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 4px 18px rgba(0,0,0,0.13);
        }
        .games-table th, .games-table td {
            vertical-align: middle;
            color: #e0e0e0;
        }
        .games-table th {
            background: linear-gradient(90deg, #4682b4, #5a9bd4);
            color: #fff;
            font-size: 1.1rem;
            font-weight: 600;
            border: none;
        }
        .games-table tr {
            border-bottom: 1px solid rgba(255,255,255,0.07);
        }
        .games-table tr:last-child {
            border-bottom: none;
        }
        .game-img-thumb {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.18);
        }
        .edit-btn {
            background: linear-gradient(90deg, #00d4ff, #4682b4);
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 8px 18px;
            font-weight: 600;
            transition: all 0.3s;
        }
        .edit-btn:hover {
            background: linear-gradient(90deg, #4682b4, #00d4ff);
            color: #fff;
            transform: scale(1.07);
            box-shadow: 0 4px 16px rgba(0,212,255,0.18);
        }
        @media (max-width: 900px) {
            .games-list-container { padding: 18px 4px; }
            .games-table th, .games-table td { font-size: 0.98rem; }
        }
        @media (max-width: 600px) {
            .games-list-title { font-size: 1.3rem; }
            .games-table th, .games-table td { font-size: 0.85rem; }
            .game-img-thumb { width: 40px; height: 40px; }
        }
    </style>
@endsection

@section('content')
<div class="games-list-container">
    <div class="games-list-title">Edit Games</div>
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif
    <div class="table-responsive">
        <table class="table games-table align-middle">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Release Date</th>
                    <th>Views</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @forelse($games as $index => $game)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>
                            @if($game->image)
                                <img src="{{ asset('storage/' . $game->image) }}" alt="{{ $game->name }}" class="game-img-thumb">
                            @else
                                <span class="text-muted">No Image</span>
                            @endif
                        </td>
                        <td>{{ $game->name }}</td>
                        <td>{{ $game->category->name ?? '-' }}</td>
                        <td>{{ $game->release_date ? $game->release_date->format('d M Y') : '-' }}</td>
                        <td>{{ $game->views ?? 0 }}</td>
                        <td>
                            <a href="{{ route('admin.games.edit', $game->id) }}" class="edit-btn">
                                <i class="bi bi-pencil-square"></i> Edit
                            </a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" class="text-center text-muted">No games found.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection

@section('scripts')
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-hide alerts after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                }, 5000);
            });
        });
    </script>
@endsection 
