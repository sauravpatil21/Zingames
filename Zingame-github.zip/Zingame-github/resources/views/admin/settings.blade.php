@extends('layouts.admin')

@section('title', 'Settings')

@section('styles')
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
<style>[x-cloak]{display:none!important;}</style>
@endsection

@section('content')
<div 
    x-data="{ show: '{{ session('settings_tab') ?? '' }}', openForm(form) { this.show = this.show === form ? '' : form } }"
    x-init="$watch('show', value => { window.history.replaceState({}, document.title, window.location.pathname); })"
    class="max-w-xl mx-auto mt-10 bg-white dark:bg-gray-900 rounded-2xl shadow-lg p-8 border border-gray-200 dark:border-gray-700"
>
    <h2 class="text-2xl font-bold mb-6 text-gray-900 dark:text-white flex items-center gap-2">
        <i class="bi bi-gear"></i> Admin Settings
    </h2>
    <!-- Email Card -->
    <div class="mb-8">
        <div class="flex items-center justify-between bg-gradient-to-r from-indigo-500 to-purple-600 dark:from-indigo-700 dark:to-purple-800 rounded-xl px-6 py-5 shadow-md">
            <div class="flex items-center gap-3">
                <i class="bi bi-envelope text-white text-2xl"></i>
                <div>
                    <div class="text-white text-sm font-semibold">Current Email</div>
                    <div class="text-lg font-bold text-white tracking-wide">{{ $user->email }}</div>
                </div>
            </div>
        </div>
    </div>
    <!-- Action Buttons -->
    <div class="flex gap-4 mb-8 justify-center">
        <button @click="openForm('password')"
            :class="show==='password' 
                ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg border-2 border-indigo-700 ring-2 ring-indigo-300 dark:ring-indigo-800' 
                : 'bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 border border-gray-300 dark:border-gray-700'"
            class="px-5 py-2 rounded-lg font-semibold transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary-400 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-gray-900 hover:shadow-md hover:-translate-y-0.5"
        >
            <i class="bi bi-key mr-2"></i> Change Password
        </button>
        <button @click="openForm('email')"
            :class="show==='email' 
                ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg border-2 border-indigo-700 ring-2 ring-indigo-300 dark:ring-indigo-800' 
                : 'bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 border border-gray-300 dark:border-gray-700'"
            class="px-5 py-2 rounded-lg font-semibold transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary-400 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-gray-900 hover:shadow-md hover:-translate-y-0.5"
        >
            <i class="bi bi-at mr-2"></i> Change Email
        </button>
    </div>
    <!-- Change Password Form -->
    <div x-show="show==='password'" x-transition class="mb-8" x-cloak>
        <h3 class="text-lg font-semibold mb-4 text-gray-900 dark:text-white">Change Password</h3>
        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif
        @if(session('error'))
            <div class="alert alert-danger">{{ session('error') }}</div>
        @endif
        <form method="POST" action="{{ route('admin.settings.change-password') }}" class="space-y-6">
            @csrf
            <div>
                <label for="current_password" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Current Password</label>
                <input type="password" name="current_password" id="current_password" required class="form-control mt-1 bg-gray-50 dark:bg-gray-800 border-gray-300 dark:border-gray-700 text-gray-900 dark:text-white" autocomplete="current-password">
                @error('current_password')
                    <span class="text-danger text-xs">{{ $message }}</span>
                @enderror
            </div>
            <div>
                <label for="password" class="block text-sm font-medium text-gray-700 dark:text-gray-300">New Password</label>
                <input type="password" name="password" id="password" required minlength="8" class="form-control mt-1 bg-gray-50 dark:bg-gray-800 border-gray-300 dark:border-gray-700 text-gray-900 dark:text-white" autocomplete="new-password">
                @error('password')
                    <span class="text-danger text-xs">{{ $message }}</span>
                @enderror
            </div>
            <div>
                <label for="password_confirmation" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Confirm New Password</label>
                <input type="password" name="password_confirmation" id="password_confirmation" required class="form-control mt-1 bg-gray-50 dark:bg-gray-800 border-gray-300 dark:border-gray-700 text-gray-900 dark:text-white" autocomplete="new-password">
            </div>
            <div class="flex justify-end">
                <button type="submit" class="btn btn-primary px-6 py-2 font-semibold">Change Password</button>
            </div>
        </form>
    </div>
    <!-- Change Email Form -->
    <div x-show="show==='email'" x-transition class="mb-8" x-cloak>
        <h3 class="text-lg font-semibold mb-4 text-gray-900 dark:text-white">Change Email</h3>
        @if(session('email_success'))
            <div class="alert alert-success">{{ session('email_success') }}</div>
        @endif
        @if(session('email_error'))
            <div class="alert alert-danger">{{ session('email_error') }}</div>
        @endif
        <form method="POST" action="{{ route('admin.settings.change-email') }}" class="space-y-6">
            @csrf
            <div>
                <label for="new_email" class="block text-sm font-medium text-gray-700 dark:text-gray-300">New Email Address</label>
                <input type="email" name="new_email" id="new_email" required class="form-control mt-1 bg-gray-50 dark:bg-gray-800 border-gray-300 dark:border-gray-700 text-gray-900 dark:text-white" autocomplete="email">
                @error('new_email')
                    <span class="text-danger text-xs">{{ $message }}</span>
                @enderror
            </div>
            <div>
                <label for="email_password" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Current Password</label>
                <input type="password" name="email_password" id="email_password" required class="form-control mt-1 bg-gray-50 dark:bg-gray-800 border-gray-300 dark:border-gray-700 text-gray-900 dark:text-white" autocomplete="current-password">
                @error('email_password')
                    <span class="text-danger text-xs">{{ $message }}</span>
                @enderror
            </div>
            <div class="flex justify-end">
                <button type="submit" class="btn btn-primary px-6 py-2 font-semibold">Change Email</button>
            </div>
        </form>
    </div>
</div>
@endsection 
