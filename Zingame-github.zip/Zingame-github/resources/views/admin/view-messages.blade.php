@extends('layouts.admin')

@section('title', 'Contact Messages')

@section('styles')
<script src="https://cdn.tailwindcss.com"></script>
<script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
<script src="https://unpkg.com/@heroicons/vue@2.0.16/24/outline/index.js"></script>
<style>
[x-cloak] { display: none !important; }
</style>
@endsection

@section('content')
<div x-data="messagesPage()" x-init="init()" class="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300 p-6">
    <div class="max-w-7xl mx-auto">
        <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-6 gap-4">
                <div>
                    <h2 class="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                        <svg class="w-7 h-7 text-primary-600 dark:text-primary-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                        Contact Messages
                    </h2>
                </div>
                <div class="flex flex-col sm:flex-row gap-2 sm:gap-4 items-stretch">
                    <select x-model="statusFilter" class="rounded-lg border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-700 text-gray-700 dark:text-gray-200 px-3 py-2 focus:ring-primary-500 focus:border-primary-500">
                        <option value="all">All Messages</option>
                        <option value="unread">Unread</option>
                        <option value="read">Read</option>
                    </select>
                    <button @click="confirmBulkDelete" :disabled="selected.length === 0" class="flex items-center gap-2 px-4 py-2 rounded-lg bg-red-600 text-white font-medium hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                        <span>Delete Selected</span>
                        <span x-show="selected.length > 0" x-text="`(${selected.length})`"></span>
                    </button>
                </div>
            </div>
            <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-4 gap-4">
                <div class="w-full md:w-1/2">
                    <div class="relative">
                        <input x-model="search" type="text" placeholder="Search messages..." class="w-full rounded-lg border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-700 text-gray-700 dark:text-gray-200 pl-10 pr-4 py-2 focus:ring-primary-500 focus:border-primary-500"/>
                        <svg class="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-4.35-4.35M17 11A6 6 0 105 11a6 6 0 0012 0z"/></svg>
                    </div>
                </div>
                <div class="w-full md:w-auto">
                    @if(session('success'))
                        <div class="bg-green-100 border border-green-200 text-green-800 px-4 py-2 rounded-lg flex items-center gap-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                            <span>{{ session('success') }}</span>
                        </div>
                    @endif
                </div>
            </div>
            <div class="overflow-x-auto rounded-xl border border-gray-100 dark:border-gray-700">
                <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 text-sm">
                    <thead class="bg-gray-50 dark:bg-gray-700">
                        <tr>
                            <th class="px-4 py-3 text-left">
                                <input type="checkbox" @click="toggleAll" :checked="allSelected" class="rounded border-gray-300 dark:border-gray-600 text-primary-600 focus:ring-primary-500"/>
                            </th>
                            <th class="px-4 py-3 text-left">Name</th>
                            <th class="px-4 py-3 text-left">Email</th>
                            <th class="px-4 py-3 text-left">Subject</th>
                            <th class="px-4 py-3 text-left">Date</th>
                            <th class="px-4 py-3 text-left">Status</th>
                            <th class="px-4 py-3 text-left">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-100 dark:divide-gray-700">
                        @forelse($messages as $message)
                        <tr :class="{ 'bg-yellow-50 dark:bg-yellow-900/20 font-semibold': !{{ $message->is_read ? 'true' : 'false' }} }" class="transition hover:bg-primary-50 dark:hover:bg-primary-900/10" x-show="filterRow({{ $message->id }}, '{{ $message->is_read ? 'read' : 'unread' }}', '{{ strtolower($message->name) }} {{ strtolower($message->email) }} {{ strtolower($message->subject) }}')">
                            <td class="px-4 py-3">
                                <input type="checkbox" value="{{ $message->id }}" @change="toggleSelect({{ $message->id }})" :checked="selected.includes({{ $message->id }})" class="rounded border-gray-300 dark:border-gray-600 text-primary-600 focus:ring-primary-500"/>
                            </td>
                            <td class="px-4 py-3">{{ $message->name }}</td>
                            <td class="px-4 py-3">
                                <a href="mailto:{{ $message->email }}" class="text-primary-600 dark:text-primary-400 hover:underline">{{ $message->email }}</a>
                                @if(in_array($message->email, $blockedEmails))
                                    <span class="ml-2 inline-block px-2 py-0.5 text-xs rounded bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300 font-semibold align-middle">Blocked</span>
                                @endif
                            </td>
                            <td class="px-4 py-3 max-w-xs truncate" title="{{ $message->subject }}">{{ $message->subject }}</td>
                            <td class="px-4 py-3">{{ $message->created_at ? $message->created_at->format('M d, Y H:i') : 'N/A' }}</td>
                            <td class="px-4 py-3">
                                <span class="inline-flex items-center gap-2">
                                    <span class="w-2 h-2 rounded-full {{ $message->is_read ? 'bg-green-500' : 'bg-yellow-400 animate-pulse' }}"></span>
                                    <span class="text-xs font-medium {{ $message->is_read ? 'text-green-600 dark:text-green-400' : 'text-yellow-700 dark:text-yellow-300' }}">{{ $message->is_read ? 'Read' : 'Unread' }}</span>
                                </span>
                            </td>
                            <td class="px-4 py-3">
                                <div class="flex gap-2">
                                    <a href="{{ route('admin.messages.show', $message->id) }}" class="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-primary-100 dark:bg-primary-900 text-primary-700 dark:text-primary-300 hover:bg-primary-200 dark:hover:bg-primary-800 transition" title="View Message">
                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                                    </a>
                                    <form action="{{ route('admin.messages.destroy', $message->id) }}" method="POST" class="inline delete-form">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300 hover:bg-red-200 dark:hover:bg-red-800 transition" title="Delete Message">
                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                                        </button>
                                    </form>
                                    @if(in_array($message->email, $blockedEmails))
                                        <form action="{{ route('admin.messages.unblock-email', $message->id) }}" method="POST" class="inline">
                                            @csrf
                                            <button type="submit" class="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 hover:bg-green-200 dark:hover:bg-green-800 transition" title="Unblock Email">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                                            </button>
                                        </form>
                                    @else
                                        <form action="{{ route('admin.messages.block-email', $message->id) }}" method="POST" class="inline">
                                            @csrf
                                            <button type="submit" class="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-yellow-100 dark:bg-yellow-900 text-yellow-700 dark:text-yellow-300 hover:bg-yellow-200 dark:hover:bg-yellow-800 transition" title="Block Email">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 5.636l-1.414 1.414M6.343 17.657l-1.414 1.414M12 3v1m0 16v1m9-9h-1M4 12H3"/></svg>
                                            </button>
                                        </form>
                                    @endif
                                </div>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="7" class="text-center py-8 text-gray-500 dark:text-gray-400">No messages found.</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            <div class="flex flex-col md:flex-row md:items-center md:justify-between mt-6 gap-4">
                <div class="text-gray-500 dark:text-gray-400 text-sm">
                    Showing {{ $messages->firstItem() ?? 0 }} to {{ $messages->lastItem() ?? 0 }} of {{ $messages->total() }} messages
                </div>
                <div>
                    {{ $messages->links('vendor.pagination.tailwind') }}
                </div>
            </div>
        </div>
    </div>

    <!-- Bulk Delete Modal -->
    <div x-show="showBulkDeleteModal" x-cloak class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-40">
        <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 max-w-md w-full">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Delete Selected Messages</h3>
            <p class="text-gray-600 dark:text-gray-300 mb-6">Are you sure you want to delete <span x-text="selected.length"></span> selected message(s)? This action cannot be undone.</p>
            <div class="flex justify-end gap-3">
                <button @click="showBulkDeleteModal = false" class="px-4 py-2 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-600 transition">Cancel</button>
                <form :action="bulkDeleteUrl" method="POST">
                    @csrf
                    @method('DELETE')
                    <input type="hidden" name="ids" :value="selected.join(',')">
                    <button type="submit" class="px-4 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700 transition">Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
function messagesPage() {
    return {
        search: '',
        statusFilter: 'all',
        selected: [],
        showBulkDeleteModal: false,
        bulkDeleteUrl: '{{ route('admin.messages.destroy', 0) }}'.replace('/0', '/bulk-delete'),
        get allSelected() {
            // All visible checkboxes selected
            const visibleIds = Array.from(document.querySelectorAll('tbody tr[x-show]')).filter(row => row.style.display !== 'none').map(row => parseInt(row.querySelector('input[type=checkbox]').value));
            return visibleIds.length > 0 && visibleIds.every(id => this.selected.includes(id));
        },
        init() {
            // Confirm single delete
            document.querySelectorAll('.delete-form').forEach(form => {
                form.addEventListener('submit', e => {
                    if (!confirm('Are you sure you want to delete this message? This action cannot be undone.')) {
                        e.preventDefault();
                    }
                });
            });
        },
        toggleSelect(id) {
            if (this.selected.includes(id)) {
                this.selected = this.selected.filter(i => i !== id);
            } else {
                this.selected.push(id);
            }
        },
        toggleAll(e) {
            const visibleIds = Array.from(document.querySelectorAll('tbody tr[x-show]')).filter(row => row.style.display !== 'none').map(row => parseInt(row.querySelector('input[type=checkbox]').value));
            if (this.allSelected) {
                this.selected = this.selected.filter(id => !visibleIds.includes(id));
            } else {
                this.selected = Array.from(new Set([...this.selected, ...visibleIds]));
            }
        },
        filterRow(id, status, text) {
            // Search
            if (this.search && !text.includes(this.search.toLowerCase())) return false;
            // Status
            if (this.statusFilter === 'all') return true;
            return this.statusFilter === status;
        },
        confirmBulkDelete() {
            if (this.selected.length > 0) {
                this.showBulkDeleteModal = true;
            }
        }
    }
}
</script>
@endsection 
