@extends('layouts.admin')

@section('title', 'View Message')

@section('styles')
<script src="https://cdn.tailwindcss.com"></script>
<style>[x-cloak]{display:none!important;}</style>
@endsection

@section('content')
<div class="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300 p-6">
    <div class="max-w-2xl mx-auto">
        <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-200 dark:border-gray-700 p-8">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                    <svg class="w-7 h-7 text-primary-600 dark:text-primary-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                    View Message
                </h2>
                <a href="{{ route('admin.messages.index') }}" class="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary-600 text-white font-medium hover:bg-primary-700 transition">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
                    Back
                </a>
            </div>
            <div class="mb-6">
                <div class="flex items-center gap-3 mb-2">
                    <span class="inline-flex items-center gap-2">
                        <span class="w-2 h-2 rounded-full {{ $message->is_read ? 'bg-green-500' : 'bg-yellow-400 animate-pulse' }}"></span>
                        <span class="text-xs font-medium {{ $message->is_read ? 'text-green-600 dark:text-green-400' : 'text-yellow-700 dark:text-yellow-300' }}">{{ $message->is_read ? 'Read' : 'Unread' }}</span>
                    </span>
                    <span class="text-xs text-gray-400">{{ $message->created_at ? $message->created_at->format('M d, Y H:i') : 'N/A' }}</span>
                </div>
                <h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-1">{{ $message->subject }}</h3>
                <div class="flex items-center gap-2 text-gray-500 dark:text-gray-400 text-sm mb-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5.121 17.804A13.937 13.937 0 0112 15c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                    <span>{{ $message->name }}</span>
                    <svg class="w-4 h-4 ml-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 12H8m8 0a4 4 0 11-8 0 4 4 0 018 0z"/></svg>
                    <a href="mailto:{{ $message->email }}" class="hover:underline text-primary-600 dark:text-primary-400">{{ $message->email }}</a>
                </div>
                @php
                    $blocked = App\Models\BlockedEmail::where('email', $message->email)->where('is_blocked', true)->first();
                @endphp
                @if($blocked)
                    <span class="ml-2 inline-block px-2 py-0.5 text-xs rounded bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300 font-semibold align-middle">Blocked</span>
                @endif
            </div>
            <div class="prose dark:prose-invert max-w-none text-gray-800 dark:text-gray-200 mb-8">
                {!! nl2br(e($message->message)) !!}
            </div>
            <div class="flex gap-3 mt-4">
                <form action="{{ route('admin.messages.destroy', $message->id) }}" method="POST" class="inline delete-form">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="px-4 py-2 rounded-lg bg-red-600 text-white font-medium hover:bg-red-700 transition flex items-center gap-2" onclick="return confirm('Are you sure you want to delete this message? This action cannot be undone.')">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                        Delete
                    </button>
                </form>
                @if($blocked)
                    <form action="{{ route('admin.messages.unblock-email', $message->id) }}" method="POST" class="inline">
                        @csrf
                        <button type="submit" class="px-4 py-2 rounded-lg bg-green-600 text-white font-medium hover:bg-green-700 transition flex items-center gap-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                            Unblock Email
                        </button>
                    </form>
                @else
                    <form action="{{ route('admin.messages.block-email', $message->id) }}" method="POST" class="inline">
                        @csrf
                        <button type="submit" class="px-4 py-2 rounded-lg bg-yellow-400 text-gray-900 font-medium hover:bg-yellow-500 transition flex items-center gap-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 5.636l-1.414 1.414M6.343 17.657l-1.414 1.414M12 3v1m0 16v1m9-9h-1M4 12H3"/></svg>
                            Block Email
                        </button>
                    </form>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection 
