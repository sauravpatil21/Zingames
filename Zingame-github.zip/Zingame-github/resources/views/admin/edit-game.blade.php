@extends('layouts.admin')

@section('title', 'Edit Game')

@section('styles')
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Bootstrap Icons CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Font Awesome for Editor Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'inter': ['Inter', 'sans-serif'],
                        'poppins': ['Poppins', 'sans-serif'],
                    },
                    colors: {
                        primary: {
                            50: '#eff6ff',
                            100: '#dbeafe',
                            500: '#3b82f6',
                            600: '#2563eb',
                            700: '#1d4ed8',
                            900: '#1e3a8a',
                        },
                        success: {
                            50: '#f0fdf4',
                            500: '#22c55e',
                            600: '#16a34a',
                        },
                        warning: {
                            50: '#fffbeb',
                            500: '#f59e0b',
                            600: '#d97706',
                        },
                        danger: {
                            50: '#fef2f2',
                            500: '#ef4444',
                            600: '#dc2626',
                        }
                    },
                    animation: {
                        'fade-in-up': 'fadeInUp 0.6s ease-out',
                        'slide-in': 'slideIn 0.5s ease-out',
                        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
                        'shake': 'shake 0.5s ease-in-out',
                        'float': 'float 6s ease-in-out infinite',
                    }
                }
            }
        }
    </script>
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Poppins:wght@300;400;500;600;700;800&display=swap');
        
        /* Custom animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }
        
        /* Glass morphism effect */
        .glass-effect {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        /* Particles background */
        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: -1;
            overflow: hidden;
        }
        
        .particle {
            position: absolute;
            width: 4px;
            height: 4px;
            background: rgba(59, 130, 246, 0.3);
            border-radius: 50%;
            animation: float 6s ease-in-out infinite;
        }
        
        .particle:nth-child(1) { left: 10%; animation-delay: 0s; }
        .particle:nth-child(2) { left: 20%; animation-delay: 1s; }
        .particle:nth-child(3) { left: 30%; animation-delay: 2s; }
        .particle:nth-child(4) { left: 40%; animation-delay: 3s; }
        .particle:nth-child(5) { left: 50%; animation-delay: 4s; }
        .particle:nth-child(6) { left: 60%; animation-delay: 5s; }
        .particle:nth-child(7) { left: 70%; animation-delay: 1.5s; }
        .particle:nth-child(8) { left: 80%; animation-delay: 2.5s; }
        .particle:nth-child(9) { left: 90%; animation-delay: 3.5s; }
        
        /* Form input focus effects */
        .form-input:focus {
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
            border-color: #3b82f6;
        }
        
        .form-input.error {
            border-color: #ef4444;
            box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
            animation: shake 0.5s ease-in-out;
        }
        
        /* Dropzone styling */
        .dropzone {
            border: 2px dashed #cbd5e1;
            transition: all 0.3s ease;
        }
        
        .dropzone:hover,
        .dropzone.dragover {
            border-color: #3b82f6;
            background-color: rgba(59, 130, 246, 0.05);
            transform: scale(1.02);
        }
        
        /* Rich Text Editor */
        .rich-text-editor {
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            overflow: hidden;
            background: white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }
        
        .editor-toolbar {
            background: #f8fafc;
            padding: 8px 12px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            flex-wrap: wrap;
            gap: 2px 4px;
        }
        
        .editor-toolbar button {
            background: white;
            color: #64748b;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s ease;
            font-size: 12px;
        }
        
        .editor-toolbar button:hover {
            background: #3b82f6;
            color: white;
            border-color: #3b82f6;
            transform: translateY(-1px);
        }
        
        .editor-toolbar button.active {
            background: #3b82f6;
            color: white;
            border-color: #3b82f6;
        }
        
        .editor-content {
            min-height: 150px;
            padding: 12px 16px;
            color: #374151;
            outline: none;
            overflow-y: auto;
            font-family: 'Inter', sans-serif;
        }
        
        .editor-content:focus {
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1) inset;
        }
        
        /* Responsive editor toolbar */
        @media (max-width: 640px) {
            .editor-toolbar {
                padding: 6px 8px;
                gap: 1px 2px;
            }
            
            .editor-toolbar button {
                width: 28px;
                height: 28px;
                font-size: 10px;
            }
            
            .editor-content {
                min-height: 120px;
                padding: 8px 12px;
            }
        }
        
        /* Button hover effects */
        .btn-gradient {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            transition: all 0.3s ease;
        }
        
        .btn-gradient:hover {
            background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
        }
        
        .btn-success-gradient {
            background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
            transition: all 0.3s ease;
        }
        
        .btn-success-gradient:hover {
            background: linear-gradient(135deg, #16a34a 0%, #22c55e 100%);
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(34, 197, 94, 0.3);
        }
        
        /* Section divider */
        .section-divider {
            background: linear-gradient(90deg, transparent, #e2e8f0, transparent);
            height: 1px;
            margin: 2rem 0;
        }
        
        /* Loading spinner */
        .spinner {
            border: 2px solid #f3f4f6;
            border-top: 2px solid #3b82f6;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* File preview */
        .file-preview {
            position: relative;
            display: inline-block;
        }
        
        .file-preview .remove-btn {
            position: absolute;
            top: -8px;
            right: -8px;
            background: #ef4444;
            color: white;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 12px;
            transition: all 0.2s ease;
        }
        
        .file-preview .remove-btn:hover {
            background: #dc2626;
            transform: scale(1.1);
        }
        
        /* Custom scrollbar */
        .custom-scrollbar::-webkit-scrollbar {
            width: 6px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-track {
            background: #f1f5f9;
            border-radius: 3px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 3px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }
    </style>
@endsection

@section('content')
<!-- Particles Background -->
<div class="particles">
    <div class="particle"></div>
    <div class="particle"></div>
    <div class="particle"></div>
    <div class="particle"></div>
    <div class="particle"></div>
    <div class="particle"></div>
    <div class="particle"></div>
    <div class="particle"></div>
    <div class="particle"></div>
</div>

<div class="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 p-4 sm:p-6 lg:p-8">
    <div class="max-w-5xl mx-auto animate-fade-in-up">
        <!-- Header Section -->
        <div class="mb-6 sm:mb-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4 space-y-4 sm:space-y-0">
                <div>
                    <h1 class="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-2">
                        Edit Game
                    </h1>
                    <p class="text-gray-600 text-base sm:text-lg">
                        Update game information and settings
                    </p>
                </div>
                <div class="flex items-center space-x-3">
                    <a href="{{ route('admin.games.index') }}" class="inline-flex items-center justify-center px-3 sm:px-4 py-2 border border-gray-300 text-xs sm:text-sm font-medium rounded-xl text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-200 shadow-sm">
                        <i class="bi bi-arrow-left mr-1 sm:mr-2"></i>
                        <span class="hidden sm:inline">Back to Games</span>
                        <span class="sm:hidden">Back</span>
                    </a>
                </div>
            </div>
            
            <!-- Breadcrumb -->
            <nav class="flex overflow-x-auto" aria-label="Breadcrumb">
                <ol class="inline-flex items-center space-x-1 md:space-x-3 min-w-max">
                    <li class="inline-flex items-center">
                        <a href="{{ route('admin.dashboard') }}" class="inline-flex items-center text-xs sm:text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors duration-200">
                            <i class="bi bi-house-door mr-1 sm:mr-2"></i>
                            <span class="hidden sm:inline">Dashboard</span>
                            <span class="sm:hidden">Home</span>
                        </a>
                    </li>
                    <li>
                        <div class="flex items-center">
                            <i class="bi bi-chevron-right text-gray-400 mx-1 sm:mx-2"></i>
                            <a href="{{ route('admin.games.index') }}" class="text-xs sm:text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors duration-200">
                                <span class="hidden sm:inline">Games</span>
                                <span class="sm:hidden">Games</span>
                            </a>
                        </div>
                    </li>
                    <li>
                        <div class="flex items-center">
                            <i class="bi bi-chevron-right text-gray-400 mx-1 sm:mx-2"></i>
                            <span class="text-xs sm:text-sm font-medium text-gray-500">
                                <span class="hidden sm:inline">Edit Game</span>
                                <span class="sm:hidden">Edit</span>
                            </span>
                        </div>
                    </li>
                </ol>
            </nav>
        </div>

        <!-- Success Alert -->
        @if(session('success'))
            <div class="mb-6 p-4 bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl shadow-sm">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <i class="bi bi-check-circle-fill text-green-500 text-xl"></i>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium text-green-800">
                            {{ session('success') }}
                        </p>
                    </div>
                    <div class="ml-auto pl-3">
                        <button type="button" class="text-green-500 hover:text-green-700" onclick="this.parentElement.parentElement.parentElement.remove()">
                            <i class="bi bi-x-lg"></i>
                        </button>
                    </div>
                </div>
            </div>
        @endif

        <!-- Main Form Card -->
        <div class="glass-effect rounded-2xl shadow-xl overflow-hidden">
            <form method="POST" action="{{ route('admin.games.update', $game->id) }}" enctype="multipart/form-data" id="editGameForm">
                @csrf
                @method('PUT')
                
                <!-- Game Information Section -->
                <div class="p-4 sm:p-6 lg:p-8 border-b border-gray-200">
                    <div class="flex items-center mb-4 sm:mb-6">
                        <div class="w-8 h-8 sm:w-10 sm:h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3 sm:mr-4">
                            <i class="bi bi-controller text-blue-600 text-lg sm:text-xl"></i>
                        </div>
                        <div>
                            <h2 class="text-lg sm:text-xl font-semibold text-gray-900">Game Information</h2>
                            <p class="text-gray-600 text-xs sm:text-sm">Basic details about your game</p>
                        </div>
                    </div>
                    
                    <!-- Game Name -->
                    <div class="form-group mb-4 sm:mb-6">
                        <label for="game-name" class="block text-xs sm:text-sm font-semibold text-gray-700 mb-2">
                            <i class="bi bi-tag-fill mr-1 sm:mr-2 text-blue-500"></i>
                            Game Name <span class="text-red-500">*</span>
                        </label>
                        <div class="relative">
                            <input 
                                type="text" 
                                id="game-name" 
                                name="name" 
                                value="{{ old('name', $game->name) }}" 
                                required 
                                placeholder="Enter game name (e.g., Cyber Assault)"
                                class="w-full pl-8 sm:pl-10 pr-4 py-2 sm:py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm form-input @error('name') error @enderror"
                            >
                            <div class="absolute inset-y-0 left-0 pl-2 sm:pl-3 flex items-center pointer-events-none">
                                <i class="bi bi-controller text-gray-400"></i>
                            </div>
                        </div>
                        @error('name')
                            <p class="mt-1 text-xs sm:text-sm text-red-600 flex items-center">
                                <i class="bi bi-exclamation-circle mr-1"></i>
                                {{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Game Slug -->
                    <div class="form-group mb-4 sm:mb-6">
                        <label for="game-slug" class="block text-xs sm:text-sm font-semibold text-gray-700 mb-2">
                            <i class="bi bi-link-45deg mr-1 sm:mr-2 text-blue-500"></i>
                            Game Slug
                            <span class="tooltip ml-1">
                                <i class="bi bi-info-circle text-gray-400 cursor-help"></i>
                                <span class="tooltip-text">SEO-friendly URL slug (auto-generated from name)</span>
                            </span>
                        </label>
                        <div class="relative">
                            <input 
                                type="text" 
                                id="game-slug" 
                                name="slug" 
                                value="{{ old('slug', $game->slug) }}" 
                                placeholder="Auto-generated from game name"
                                class="w-full pl-8 sm:pl-10 pr-4 py-2 sm:py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm form-input @error('slug') error @enderror"
                            >
                            <div class="absolute inset-y-0 left-0 pl-2 sm:pl-3 flex items-center pointer-events-none">
                                <i class="bi bi-link text-gray-400"></i>
                            </div>
                        </div>
                        <p class="mt-1 text-xs text-gray-500">Leave empty to auto-generate from game name</p>
                        @error('slug')
                            <p class="mt-1 text-xs sm:text-sm text-red-600 flex items-center">
                                <i class="bi bi-exclamation-circle mr-1"></i>
                                {{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Description -->
                    <div class="form-group mb-4 sm:mb-6">
                        <label for="description" class="block text-xs sm:text-sm font-semibold text-gray-700 mb-2">
                            <i class="bi bi-file-text-fill mr-1 sm:mr-2 text-blue-500"></i>
                            Description <span class="text-red-500">*</span>
                        </label>
                        <div class="rich-text-editor">
                            <div class="editor-toolbar">
                                <div class="flex flex-wrap items-center gap-1 sm:gap-2">
                                    <div class="flex items-center space-x-1">
                                        <button type="button" data-command="h1" title="Heading 1" class="editor-btn">
                                            <i class="fa fa-heading"></i>1
                                        </button>
                                        <button type="button" data-command="h2" title="Heading 2" class="editor-btn">
                                            <i class="fa fa-heading"></i>2
                                        </button>
                                        <button type="button" data-command="h3" title="Heading 3" class="editor-btn">
                                            <i class="fa fa-heading"></i>3
                                        </button>
                                    </div>
                                    <div class="flex items-center space-x-1">
                                        <button type="button" data-command="bold" title="Bold" class="editor-btn">
                                            <i class="fa fa-bold"></i>
                                        </button>
                                        <button type="button" data-command="italic" title="Italic" class="editor-btn">
                                            <i class="fa fa-italic"></i>
                                        </button>
                                        <button type="button" data-command="underline" title="Underline" class="editor-btn">
                                            <i class="fa fa-underline"></i>
                                        </button>
                                        <button type="button" data-command="strikeThrough" title="Strike through" class="editor-btn">
                                            <i class="fa fa-strikethrough"></i>
                                        </button>
                                    </div>
                                    <div class="flex items-center space-x-1">
                                        <button type="button" data-command="justifyLeft" title="Align left" class="editor-btn">
                                            <i class="fa fa-align-left"></i>
                                        </button>
                                        <button type="button" data-command="justifyCenter" title="Align center" class="editor-btn">
                                            <i class="fa fa-align-center"></i>
                                        </button>
                                        <button type="button" data-command="justifyRight" title="Align right" class="editor-btn">
                                            <i class="fa fa-align-right"></i>
                                        </button>
                                    </div>
                                    <div class="flex items-center space-x-1">
                                        <button type="button" data-command="insertUnorderedList" title="Bullet list" class="editor-btn">
                                            <i class="fa fa-list-ul"></i>
                                        </button>
                                        <button type="button" data-command="insertOrderedList" title="Number list" class="editor-btn">
                                            <i class="fa fa-list-ol"></i>
                                        </button>
                                    </div>
                                    <div class="flex items-center space-x-1">
                                        <button type="button" data-command="createLink" title="Insert link" class="editor-btn">
                                            <i class="fa fa-link"></i>
                                        </button>
                                        <button type="button" data-command="unlink" title="Remove link" class="editor-btn">
                                            <i class="fa fa-unlink"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="editor-content" id="description-editor" contenteditable="true">{!! old('description', $game->description) !!}</div>
                        </div>
                        <textarea id="description" name="description" class="hidden" required>{{ old('description', $game->description) }}</textarea>
                        @error('description')
                            <p class="mt-1 text-xs sm:text-sm text-red-600 flex items-center">
                                <i class="bi bi-exclamation-circle mr-1"></i>
                                {{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>

                <!-- Game Details Section -->
                <div class="p-4 sm:p-6 lg:p-8 border-b border-gray-200">
                    <div class="flex items-center mb-4 sm:mb-6">
                        <div class="w-8 h-8 sm:w-10 sm:h-10 bg-purple-100 rounded-lg flex items-center justify-center mr-3 sm:mr-4">
                            <i class="bi bi-gear-fill text-purple-600 text-lg sm:text-xl"></i>
                        </div>
                        <div>
                            <h2 class="text-lg sm:text-xl font-semibold text-gray-900">Game Details</h2>
                            <p class="text-gray-600 text-xs sm:text-sm">Technical specifications and metadata</p>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                        <!-- Game Link -->
                        <div class="form-group">
                            <label for="game-link" class="block text-xs sm:text-sm font-semibold text-gray-700 mb-2">
                                <i class="bi bi-globe mr-1 sm:mr-2 text-purple-500"></i>
                                Game Link <span class="text-red-500">*</span>
                            </label>
                            <div class="relative">
                                <input 
                                    type="url" 
                                    id="game-link" 
                                    name="game_link" 
                                    value="{{ old('game_link', $game->game_link) }}" 
                                    required 
                                    placeholder="Enter game URL (e.g., https://zingames.com/cyber)"
                                    class="w-full pl-8 sm:pl-10 pr-4 py-2 sm:py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm form-input @error('game_link') error @enderror"
                                >
                                <div class="absolute inset-y-0 left-0 pl-2 sm:pl-3 flex items-center pointer-events-none">
                                    <i class="bi bi-link-45deg text-gray-400"></i>
                                </div>
                            </div>
                            @error('game_link')
                                <p class="mt-1 text-xs sm:text-sm text-red-600 flex items-center">
                                    <i class="bi bi-exclamation-circle mr-1"></i>
                                    {{ $message }}
                                </p>
                            @enderror
                        </div>

                        <!-- Category -->
                        <div class="form-group">
                            <label for="category" class="block text-xs sm:text-sm font-semibold text-gray-700 mb-2">
                                <i class="bi bi-collection-fill mr-1 sm:mr-2 text-purple-500"></i>
                                Category <span class="text-red-500">*</span>
                            </label>
                            <div class="relative">
                                <select 
                                    id="category" 
                                    name="category_id" 
                                    required
                                    class="w-full pl-8 sm:pl-10 pr-4 py-2 sm:py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm form-input @error('category_id') error @enderror"
                                >
                                    <option value="">Select a category</option>
                                    @foreach($categories as $category)
                                        <option value="{{ $category->id }}" {{ old('category_id', $game->category_id) == $category->id ? 'selected' : '' }}>
                                            {{ $category->name }}
                                        </option>
                                    @endforeach
                                </select>
                                <div class="absolute inset-y-0 left-0 pl-2 sm:pl-3 flex items-center pointer-events-none">
                                    <i class="bi bi-tags text-gray-400"></i>
                                </div>
                            </div>
                            @error('category_id')
                                <p class="mt-1 text-xs sm:text-sm text-red-600 flex items-center">
                                    <i class="bi bi-exclamation-circle mr-1"></i>
                                    {{ $message }}
                                </p>
                            @enderror
                        </div>
                    </div>

                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6 mt-4 sm:mt-6">
                        <!-- Release Date -->
                        <div class="form-group">
                            <label for="release-date" class="block text-xs sm:text-sm font-semibold text-gray-700 mb-2">
                                <i class="bi bi-calendar-event-fill mr-1 sm:mr-2 text-purple-500"></i>
                                Release Date <span class="text-red-500">*</span>
                            </label>
                            <div class="relative">
                                <input 
                                    type="date" 
                                    id="release-date" 
                                    name="release_date" 
                                    value="{{ old('release_date', $game->release_date_for_input) }}" 
                                    required
                                    class="w-full pl-8 sm:pl-10 pr-4 py-2 sm:py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm form-input @error('release_date') error @enderror"
                                >
                                <div class="absolute inset-y-0 left-0 pl-2 sm:pl-3 flex items-center pointer-events-none">
                                    <i class="bi bi-calendar3 text-gray-400"></i>
                                </div>
                            </div>
                            @error('release_date')
                                <p class="mt-1 text-xs sm:text-sm text-red-600 flex items-center">
                                    <i class="bi bi-exclamation-circle mr-1"></i>
                                    {{ $message }}
                                </p>
                            @enderror
                        </div>

                        <!-- Hashtags -->
                        <div class="form-group">
                            <label for="hashtags" class="block text-xs sm:text-sm font-semibold text-gray-700 mb-2">
                                <i class="bi bi-hash mr-1 sm:mr-2 text-purple-500"></i>
                                Hashtags
                            </label>
                            <input 
                                type="text" 
                                id="hashtags" 
                                name="hashtags" 
                                value="{{ old('hashtags', $game->hashtags) }}" 
                                placeholder="Enter hashtags (e.g., #action #adventure #multiplayer)"
                                class="w-full px-4 py-2 sm:py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm form-input @error('hashtags') error @enderror"
                            >
                            @error('hashtags')
                                <p class="mt-1 text-xs sm:text-sm text-red-600 flex items-center">
                                    <i class="bi bi-exclamation-circle mr-1"></i>
                                    {{ $message }}
                                </p>
                            @enderror
                            <p class="mt-1 text-xs sm:text-sm text-gray-500">Separate hashtags with spaces (e.g., #action #adventure)</p>
                        </div>
                    </div>
                </div>

                <!-- SEO Information Section -->
                <div class="p-4 sm:p-6 lg:p-8 border-b border-gray-200">
                    <div class="flex items-center mb-4 sm:mb-6">
                        <div class="w-8 h-8 sm:w-10 sm:h-10 bg-green-100 rounded-lg flex items-center justify-center mr-3 sm:mr-4">
                            <i class="bi bi-search-heart-fill text-green-600 text-lg sm:text-xl"></i>
                        </div>
                        <div>
                            <h2 class="text-lg sm:text-xl font-semibold text-gray-900">SEO Information</h2>
                            <p class="text-gray-600 text-xs sm:text-sm">Optimize your game for search engines</p>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                        <!-- Meta Keywords -->
                        <div class="form-group">
                            <label for="meta-keywords" class="block text-xs sm:text-sm font-semibold text-gray-700 mb-2">
                                <i class="bi bi-key-fill mr-1 sm:mr-2 text-green-500"></i>
                                Meta Keywords
                            </label>
                            <input 
                                type="text" 
                                id="meta-keywords" 
                                name="meta_keywords" 
                                value="{{ old('meta_keywords', $game->meta_keywords) }}" 
                                placeholder="Enter meta keywords (e.g., action, adventure)"
                                class="w-full px-4 py-2 sm:py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm form-input @error('meta_keywords') error @enderror"
                            >
                            @error('meta_keywords')
                                <p class="mt-1 text-xs sm:text-sm text-red-600 flex items-center">
                                    <i class="bi bi-exclamation-circle mr-1"></i>
                                    {{ $message }}
                                </p>
                            @enderror
                        </div>

                        <!-- Meta Description -->
                        <div class="form-group">
                            <label for="meta-description" class="block text-xs sm:text-sm font-semibold text-gray-700 mb-2">
                                <i class="bi bi-file-earmark-text-fill mr-1 sm:mr-2 text-green-500"></i>
                                Meta Description
                            </label>
                            <textarea 
                                id="meta-description" 
                                name="meta_description" 
                                rows="3" 
                                placeholder="Enter meta description"
                                class="w-full px-4 py-2 sm:py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm form-input @error('meta_description') error @enderror"
                            >{{ old('meta_description', $game->meta_description) }}</textarea>
                            @error('meta_description')
                                <p class="mt-1 text-xs sm:text-sm text-red-600 flex items-center">
                                    <i class="bi bi-exclamation-circle mr-1"></i>
                                    {{ $message }}
                                </p>
                            @enderror
                        </div>
                    </div>
                </div>

                <!-- Game Image Section -->
                <div class="p-4 sm:p-6 lg:p-8">
                    <div class="flex items-center mb-4 sm:mb-6">
                        <div class="w-8 h-8 sm:w-10 sm:h-10 bg-orange-100 rounded-lg flex items-center justify-center mr-3 sm:mr-4">
                            <i class="bi bi-image-fill text-orange-600 text-lg sm:text-xl"></i>
                        </div>
                        <div>
                            <h2 class="text-lg sm:text-xl font-semibold text-gray-900">Game Thumbnail</h2>
                            <p class="text-gray-600 text-xs sm:text-sm">Update the game's visual representation</p>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="dropzone rounded-xl p-4 sm:p-6 lg:p-8 text-center cursor-pointer" id="image-drop-area">
                            <input 
                                type="file" 
                                id="game-image" 
                                name="image" 
                                accept="image/*" 
                                class="hidden @error('image') error @enderror"
                            >
                            
                            <!-- Upload Content -->
                            <div id="upload-content" class="space-y-3 sm:space-y-4">
                                <div class="w-12 h-12 sm:w-16 sm:h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                                    <i class="bi bi-cloud-upload text-blue-600 text-xl sm:text-2xl"></i>
                                </div>
                                <div>
                                    <p class="text-base sm:text-lg font-semibold text-gray-900 mb-1 sm:mb-2">
                                        Drop your image here or click to browse
                                    </p>
                                    <p class="text-xs sm:text-sm text-gray-600">
                                        PNG, JPG, GIF up to 2MB • Recommended: 800×600px
                                    </p>
                                </div>
                            </div>
                            
                            <!-- Preview Content -->
                            <div id="preview-content" class="hidden space-y-3 sm:space-y-4">
                                <div class="file-preview">
                                    <img id="image-preview" class="max-w-full max-h-32 sm:max-h-48 rounded-lg shadow-lg mx-auto" alt="Preview">
                                    <div class="remove-btn" onclick="removeImage()">
                                        <i class="bi bi-x"></i>
                                    </div>
                                </div>
                                <div>
                                    <p id="file-info" class="text-xs sm:text-sm text-gray-600"></p>
                                </div>
                            </div>
                        </div>
                        
                        @error('image')
                            <p class="mt-2 text-xs sm:text-sm text-red-600 flex items-center">
                                <i class="bi bi-exclamation-circle mr-1"></i>
                                {{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Current Image Display -->
                    @if($game->image)
                        <div class="mt-4 sm:mt-6 p-3 sm:p-4 bg-gray-50 rounded-xl">
                            <h3 class="text-xs sm:text-sm font-semibold text-gray-700 mb-2 sm:mb-3">Current Image</h3>
                            <div class="flex flex-col sm:flex-row sm:items-center space-y-2 sm:space-y-0 sm:space-x-4">
                                <img src="{{ asset('storage/' . $game->image) }}" alt="{{ $game->name }}" class="w-16 h-16 sm:w-20 sm:h-20 object-cover rounded-lg shadow-sm mx-auto sm:mx-0">
                                <div class="text-center sm:text-left">
                                    <p class="text-xs sm:text-sm text-gray-600">Current game thumbnail</p>
                                    <p class="text-xs text-gray-500">Upload a new image to replace this one</p>
                                </div>
                            </div>
                        </div>
                    @endif
                </div>

                <!-- Submit Button Section -->
                <div class="px-4 sm:px-6 lg:px-8 py-4 sm:py-6 bg-gray-50 border-t border-gray-200">
                    <div class="flex flex-col space-y-4 sm:space-y-0 sm:flex-row sm:items-center sm:justify-between">
                        <div class="text-xs sm:text-sm text-gray-600 text-center sm:text-left">
                            <i class="bi bi-info-circle mr-1"></i>
                            All fields marked with * are required
                        </div>
                        <div class="flex flex-col sm:flex-row items-stretch sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
                            <button 
                                type="button" 
                                onclick="previewImage()" 
                                class="btn-success-gradient inline-flex items-center justify-center px-4 sm:px-6 py-2 sm:py-3 border border-transparent text-xs sm:text-sm font-semibold rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 shadow-lg"
                            >
                                <i class="bi bi-eye mr-1 sm:mr-2"></i>
                                <span class="hidden sm:inline">Preview Image</span>
                                <span class="sm:hidden">Preview</span>
                            </button>
                            <button 
                                type="submit" 
                                class="btn-gradient inline-flex items-center justify-center px-4 sm:px-8 py-2 sm:py-3 border border-transparent text-xs sm:text-sm font-semibold rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 shadow-lg"
                                id="submitBtn"
                            >
                                <i class="bi bi-save mr-1 sm:mr-2"></i>
                                <span id="submitText">
                                    <span class="hidden sm:inline">Update Game</span>
                                    <span class="sm:hidden">Update</span>
                                </span>
                                <div id="loadingSpinner" class="spinner ml-1 sm:ml-2 hidden"></div>
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@section('scripts')
    <!-- Bootstrap 5 JS CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- SweetAlert2 CDN for beautiful dialogs -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Debug: Check if date field is populated
            const dateField = document.getElementById('release-date');
            if (dateField) {
                console.log('Release date field value:', dateField.value);
                console.log('Release date field type:', typeof dateField.value);
            }

            // Rich Text Editor Functionality
            const buttons = document.querySelectorAll('.editor-toolbar button');
            const editor = document.getElementById('description-editor');
            const textarea = document.getElementById('description');
            
            // Update hidden textarea with editor content
            function updateTextarea() {
                textarea.value = editor.innerHTML;
            }
            
            // Initialize editor buttons
            buttons.forEach(button => {
                button.addEventListener('click', () => {
                    const command = button.dataset.command;
                    
                    if (command === 'h1' || command === 'h2' || command === 'h3') {
                        document.execCommand('formatBlock', false, command);
                    } else if (command === 'createLink') {
                        let url = prompt('Enter the link URL (e.g., https://example.com):', 'https://');
                        if (url) {
                            if (!/^https?:\/\//i.test(url)) {
                                url = 'https://' + url;
                            }
                            document.execCommand(command, false, url);
                            
                            // Find the newly created link and add target="_blank" attribute
                            const selection = window.getSelection();
                            if (selection.rangeCount > 0) {
                                const range = selection.getRangeAt(0);
                                const links = editor.querySelectorAll('a');
                                links.forEach(link => {
                                    if (range.intersectsNode(link)) {
                                        link.setAttribute('target', '_blank');
                                        link.setAttribute('rel', 'noopener noreferrer');
                                    }
                                });
                            }
                        }
                    } else {
                        document.execCommand(command, false, null);
                    }
                    
                    editor.focus();
                    updateTextarea();
                });
            });
            
            // Update textarea when editor content changes
            editor.addEventListener('input', updateTextarea);
            editor.addEventListener('blur', updateTextarea);

            // Image upload handling
            const imageInput = document.getElementById('game-image');
            const imagePreview = document.getElementById('image-preview');
            const uploadContent = document.getElementById('upload-content');
            const previewContent = document.getElementById('preview-content');
            const fileInfo = document.getElementById('file-info');
            const dropArea = document.getElementById('image-drop-area');

            function handleFileSelect(file) {
                if (file) {
                    // Validate file type
                    if (!file.type.startsWith('image/')) {
                        alert('Please select an image file.');
                        return;
                    }

                    // Validate file size (2MB)
                    if (file.size > 2 * 1024 * 1024) {
                        alert('File size must be less than 2MB.');
                        return;
                    }

                    const reader = new FileReader();
                    reader.onload = function(e) {
                        imagePreview.src = e.target.result;
                        uploadContent.classList.add('hidden');
                        previewContent.classList.remove('hidden');
                        
                        // Update file info
                        const sizeInMB = (file.size / (1024 * 1024)).toFixed(2);
                        fileInfo.textContent = `${file.name} (${sizeInMB} MB)`;
                    };
                    reader.readAsDataURL(file);
                }
            }

            // File input change
            imageInput.addEventListener('change', function() {
                if (this.files && this.files[0]) {
                    handleFileSelect(this.files[0]);
                }
            });

            // Drag and drop functionality
            dropArea.addEventListener('click', () => imageInput.click());

            dropArea.addEventListener('dragover', (e) => {
                e.preventDefault();
                dropArea.classList.add('dragover');
            });

            dropArea.addEventListener('dragleave', () => {
                dropArea.classList.remove('dragover');
            });

            dropArea.addEventListener('drop', (e) => {
                e.preventDefault();
                dropArea.classList.remove('dragover');
                
                if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                    imageInput.files = e.dataTransfer.files;
                    handleFileSelect(e.dataTransfer.files[0]);
                }
            });

            // Remove image function
            window.removeImage = function() {
                imageInput.value = '';
                uploadContent.classList.remove('hidden');
                previewContent.classList.add('hidden');
                imagePreview.src = '';
                fileInfo.textContent = '';
            };

            // Preview image function
            window.previewImage = function() {
                const file = imageInput.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        const img = new Image();
                        img.src = e.target.result;
                        img.style.maxWidth = '200px';
                        img.style.borderRadius = '10px';
                        img.style.boxShadow = '0 4px 15px rgba(0, 0, 0, 0.3)';
                        img.style.transition = 'all 0.3s ease';
                        img.style.display = 'block';
                        img.style.margin = '10px auto';
                        
                        // Show preview in a modal or alert
                        Swal.fire({
                            title: 'Image Preview',
                            imageUrl: e.target.result,
                            imageWidth: 200,
                            imageHeight: 150,
                            imageAlt: 'Game Image Preview',
                            confirmButtonText: 'Close',
                            confirmButtonColor: '#3b82f6'
                        });
                    };
                    reader.readAsDataURL(file);
                } else {
                    Swal.fire({
                        title: 'No Image Selected',
                        text: 'Please select an image first!',
                        icon: 'warning',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3b82f6'
                    });
                }
            };

            // Form submission
            const form = document.getElementById('editGameForm');
            const submitBtn = document.getElementById('submitBtn');
            const submitText = document.getElementById('submitText');
            const loadingSpinner = document.getElementById('loadingSpinner');

            form.addEventListener('submit', (e) => {
                // Update textarea before submission
                updateTextarea();
                
                // Show loading state
                submitText.textContent = 'Updating Game...';
                loadingSpinner.classList.remove('hidden');
                submitBtn.disabled = true;
                
                // Debug: Log form data before submission
                console.log('Form is valid, submitting...');
                console.log('Release date being submitted:', document.getElementById('release-date').value);
            });

            // Auto-hide alerts after 5 seconds
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.style.opacity = '0';
                    setTimeout(() => alert.remove(), 300);
                }, 5000);
            });

            // Auto-generate slug from game name
            const nameInput = document.getElementById('game-name');
            const slugInput = document.getElementById('game-slug');
            
            nameInput.addEventListener('input', function() {
                if (!slugInput.value.trim()) {
                    const slug = this.value
                        .toLowerCase()
                        .replace(/[^a-z0-9\s-]/g, '')
                        .replace(/\s+/g, '-')
                        .replace(/-+/g, '-')
                        .trim('-');
                    slugInput.value = slug;
                }
            });

            // Real-time validation feedback
            const inputs = form.querySelectorAll('input, select, textarea');
            inputs.forEach(input => {
                input.addEventListener('blur', function() {
                    if (this.hasAttribute('required') && !this.value.trim()) {
                        this.classList.add('error');
                    } else {
                        this.classList.remove('error');
                    }
                });

                input.addEventListener('input', function() {
                    if (this.value.trim()) {
                        this.classList.remove('error');
                    }
                });
            });
        });
    </script>
@endsection 
