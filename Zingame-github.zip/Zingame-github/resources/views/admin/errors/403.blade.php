<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Access Denied - ZinGames Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center">
    <div class="max-w-md w-full bg-white rounded-lg shadow-lg p-8 text-center">
        <div class="mb-6">
            <i class="fas fa-shield-alt text-6xl text-red-500 mb-4"></i>
            <h1 class="text-3xl font-bold text-gray-800 mb-2">Access Denied</h1>
            <p class="text-gray-600 mb-6">You don't have permission to access this resource.</p>
        </div>
        
        <div class="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <div class="flex items-center">
                <i class="fas fa-exclamation-triangle text-red-500 mr-3"></i>
                <div class="text-left">
                    <h3 class="font-semibold text-red-800">Security Notice</h3>
                    <p class="text-sm text-red-600 mt-1">This action has been logged for security purposes.</p>
                </div>
            </div>
        </div>
        
        <div class="space-y-3">
            <a href="{{ route('admin.dashboard') }}" 
               class="block w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors">
                <i class="fas fa-home mr-2"></i>Go to Dashboard
            </a>
            
            <a href="{{ url()->previous() }}" 
               class="block w-full bg-gray-600 text-white py-3 px-4 rounded-lg hover:bg-gray-700 transition-colors">
                <i class="fas fa-arrow-left mr-2"></i>Go Back
            </a>
        </div>
        
        <div class="mt-6 text-xs text-gray-500">
            <p>If you believe this is an error, please contact your administrator.</p>
            <p class="mt-1">Request ID: {{ uniqid() }}</p>
        </div>
    </div>
</body>
</html> 
