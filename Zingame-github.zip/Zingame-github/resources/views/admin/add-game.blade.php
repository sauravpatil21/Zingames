@extends('layouts.admin')

@section('title', 'Add New Game')

@section('styles')
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Bootstrap Icons CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Font Awesome for additional icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'inter': ['Inter', 'sans-serif'],
                        'poppins': ['Poppins', 'sans-serif'],
                    },
                    colors: {
                        primary: {
                            50: '#eff6ff',
                            100: '#dbeafe',
                            500: '#3b82f6',
                            600: '#2563eb',
                            700: '#1d4ed8',
                            900: '#1e3a8a',
                        },
                        success: {
                            50: '#f0fdf4',
                            500: '#22c55e',
                            600: '#16a34a',
                        },
                        warning: {
                            50: '#fffbeb',
                            500: '#f59e0b',
                            600: '#d97706',
                        },
                        danger: {
                            50: '#fef2f2',
                            500: '#ef4444',
                            600: '#dc2626',
                        }
                    },
                    animation: {
                        'fade-in-up': 'fadeInUp 0.6s ease-out',
                        'slide-in': 'slideIn 0.5s ease-out',
                        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
                        'shake': 'shake 0.5s ease-in-out',
                    }
                }
            }
        }
    </script>
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Poppins:wght@300;400;500;600;700;800&display=swap');
        
        /* Custom animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }
        
        /* Glass morphism effect */
        .glass-effect {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        /* Custom scrollbar */
        .custom-scrollbar::-webkit-scrollbar {
            width: 6px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-track {
            background: #f1f5f9;
            border-radius: 3px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 3px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }
        
        /* Form input focus effects */
        .form-input:focus {
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
            border-color: #3b82f6;
        }
        
        .form-input.error {
            border-color: #ef4444;
            box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
            animation: shake 0.5s ease-in-out;
        }
        
        /* Dropzone styling */
        .dropzone {
            border: 2px dashed #cbd5e1;
            transition: all 0.3s ease;
        }
        
        .dropzone:hover,
        .dropzone.dragover {
            border-color: #3b82f6;
            background-color: rgba(59, 130, 246, 0.05);
        }
        
        .dropzone.dragover {
            transform: scale(1.02);
        }
        
        /* Button hover effects */
        .btn-gradient {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            transition: all 0.3s ease;
        }
        
        .btn-gradient:hover {
            background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
        }
        
        /* Section divider */
        .section-divider {
            background: linear-gradient(90deg, transparent, #e2e8f0, transparent);
            height: 1px;
            margin: 2rem 0;
        }
        
        /* Tooltip */
        .tooltip {
            position: relative;
        }
        
        .tooltip .tooltip-text {
            visibility: hidden;
            width: 200px;
            background-color: #1f2937;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 8px 12px;
            position: absolute;
            z-index: 1;
            bottom: 125%;
            left: 50%;
            margin-left: -100px;
            opacity: 0;
            transition: opacity 0.3s;
            font-size: 0.875rem;
        }
        
        .tooltip:hover .tooltip-text {
            visibility: visible;
            opacity: 1;
        }
        
        /* Loading spinner */
        .spinner {
            border: 2px solid #f3f4f6;
            border-top: 2px solid #3b82f6;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* File preview */
        .file-preview {
            position: relative;
            display: inline-block;
        }
        
        .file-preview .remove-btn {
            position: absolute;
            top: -8px;
            right: -8px;
            background: #ef4444;
            color: white;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 12px;
            transition: all 0.2s ease;
        }
        
        .file-preview .remove-btn:hover {
            background: #dc2626;
            transform: scale(1.1);
        }
        
        /* Rich Text Editor Styling */
        .rich-text-editor {
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            overflow: hidden;
            background: white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
        }
        
        .rich-text-editor:focus-within {
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        .rich-text-editor.error {
            border-color: #ef4444;
            box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
            animation: shake 0.5s ease-in-out;
        }
        
        .editor-toolbar {
            background: #f8fafc;
            padding: 12px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            flex-wrap: wrap;
            gap: 4px;
            align-items: center;
        }
        
        .editor-toolbar button {
            background: white;
            color: #64748b;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s ease;
            font-size: 14px;
            position: relative;
        }
        
        .editor-toolbar button:hover {
            background: #3b82f6;
            color: white;
            border-color: #3b82f6;
            transform: translateY(-1px);
            box-shadow: 0 2px 4px rgba(59, 130, 246, 0.2);
        }
        
        .editor-toolbar button:active {
            transform: scale(0.95);
        }
        
        .editor-toolbar button.active {
            background: #3b82f6;
            color: white;
            border-color: #3b82f6;
        }
        
        .editor-toolbar .btn-group {
            display: flex;
            gap: 2px;
            margin-right: 8px;
            padding-right: 8px;
            border-right: 1px solid #e2e8f0;
        }
        
        .editor-toolbar .btn-group:last-child {
            border-right: none;
            margin-right: 0;
            padding-right: 0;
        }
        
        .editor-content {
            min-height: 150px;
            padding: 16px;
            color: #374151;
            outline: none;
            overflow-y: auto;
            font-family: 'Inter', sans-serif;
            line-height: 1.6;
        }
        
        .editor-content:focus {
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1) inset;
        }
        
        /* Editor content styling */
        .editor-content h1, .editor-content h2, .editor-content h3, 
        .editor-content h4, .editor-content h5, .editor-content h6 {
            margin-top: 0.5em;
            margin-bottom: 0.5em;
            color: #1f2937;
            font-weight: 600;
        }
        
        .editor-content h1 { font-size: 1.5em; }
        .editor-content h2 { font-size: 1.3em; }
        .editor-content h3 { font-size: 1.1em; }
        
        .editor-content p {
            margin-bottom: 0.5em;
        }
        
        .editor-content ul, .editor-content ol {
            margin-left: 20px;
            margin-bottom: 0.5em;
        }
        
        .editor-content li {
            margin-bottom: 0.25em;
        }
        
        .editor-content a {
            color: #3b82f6;
            text-decoration: underline;
        }
        
        .editor-content a:hover {
            color: #2563eb;
        }
        
        .editor-content blockquote {
            border-left: 4px solid #3b82f6;
            padding-left: 16px;
            margin: 16px 0;
            font-style: italic;
            color: #6b7280;
        }
        
        /* Responsive toolbar */
        @media (max-width: 768px) {
            .editor-toolbar {
                padding: 8px;
                gap: 2px;
            }
            
            .editor-toolbar button {
                width: 32px;
                height: 32px;
                font-size: 12px;
            }
            
            .editor-toolbar .btn-group {
                margin-right: 4px;
                padding-right: 4px;
            }
            
            .editor-content {
                padding: 12px;
                min-height: 120px;
            }
        }
        
        @media (max-width: 480px) {
            .editor-toolbar {
                flex-direction: column;
                align-items: stretch;
            }
            
            .editor-toolbar .btn-group {
                justify-content: center;
                border-right: none;
                border-bottom: 1px solid #e2e8f0;
                margin-right: 0;
                margin-bottom: 8px;
                padding-right: 0;
                padding-bottom: 8px;
            }
            
            .editor-toolbar .btn-group:last-child {
                border-bottom: none;
                margin-bottom: 0;
                padding-bottom: 0;
            }
        }
    </style>
@endsection

@section('content')
<div class="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 p-4 sm:p-6 lg:p-8">
    <div class="max-w-4xl mx-auto animate-fade-in-up">
        <!-- Header Section -->
        <div class="mb-8 text-center">
            <h1 class="text-3xl sm:text-4xl font-bold text-gray-900 mb-2">
                Add New Game
            </h1>
            <p class="text-gray-600 text-lg">
                Create and publish a new game to your platform
            </p>
        </div>

        <!-- Success Alert -->
        @if(session('success'))
            <div class="mb-6 p-4 bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl shadow-sm">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <i class="bi bi-check-circle-fill text-green-500 text-xl"></i>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium text-green-800">
                            {{ session('success') }}
                        </p>
                    </div>
                    <div class="ml-auto pl-3">
                        <button type="button" class="text-green-500 hover:text-green-700" onclick="this.parentElement.parentElement.parentElement.remove()">
                            <i class="bi bi-x-lg"></i>
                        </button>
                    </div>
                </div>
            </div>
        @endif

        <!-- Main Form Card -->
        <div class="glass-effect rounded-2xl shadow-xl overflow-hidden">
            <form method="POST" action="{{ route('admin.games.store') }}" enctype="multipart/form-data" id="addGameForm">
                @csrf
                
                <!-- Game Information Section -->
                <div class="p-6 sm:p-8 border-b border-gray-200">
                    <div class="flex items-center mb-6">
                        <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                            <i class="bi bi-controller text-blue-600 text-xl"></i>
                        </div>
                        <div>
                            <h2 class="text-xl font-semibold text-gray-900">Game Information</h2>
                            <p class="text-gray-600 text-sm">Basic details about your game</p>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <!-- Game Name -->
                        <div class="form-group">
                            <label for="name" class="block text-sm font-semibold text-gray-700 mb-2">
                                <i class="bi bi-tag-fill mr-2 text-blue-500"></i>
                                Game Name
                            </label>
                            <div class="relative">
                                <input 
                                    type="text" 
                                    id="name" 
                                    name="name" 
                                    value="{{ old('name') }}" 
                                    required 
                                    placeholder="Enter game name"
                                    class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm form-input @error('name') error @enderror"
                                >
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="bi bi-controller text-gray-400"></i>
                                </div>
                            </div>
                            @error('name')
                                <p class="mt-1 text-sm text-red-600 flex items-center">
                                    <i class="bi bi-exclamation-circle mr-1"></i>
                                    {{ $message }}
                                </p>
                            @enderror
                        </div>

                        <!-- Game Slug -->
                        <div class="form-group">
                            <label for="slug" class="block text-sm font-semibold text-gray-700 mb-2">
                                <i class="bi bi-link-45deg mr-2 text-blue-500"></i>
                                Game Slug
                                <span class="tooltip ml-1">
                                    <i class="bi bi-info-circle text-gray-400 cursor-help"></i>
                                    <span class="tooltip-text">SEO-friendly URL slug (auto-generated from name)</span>
                                </span>
                            </label>
                            <div class="relative">
                                <input 
                                    type="text" 
                                    id="slug" 
                                    name="slug" 
                                    value="{{ old('slug') }}" 
                                    placeholder="Auto-generated from game name"
                                    class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm form-input @error('slug') error @enderror"
                                >
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="bi bi-link text-gray-400"></i>
                                </div>
                            </div>
                            <p class="mt-1 text-xs text-gray-500">Leave empty to auto-generate from game name</p>
                            @error('slug')
                                <p class="mt-1 text-sm text-red-600 flex items-center">
                                    <i class="bi bi-exclamation-circle mr-1"></i>
                                    {{ $message }}
                                </p>
                            @enderror
                        </div>

                        <!-- Category -->
                        <div class="form-group">
                            <label for="category_id" class="block text-sm font-semibold text-gray-700 mb-2">
                                <i class="bi bi-collection-fill mr-2 text-blue-500"></i>
                                Category
                            </label>
                            <div class="relative">
                                <select 
                                    id="category_id" 
                                    name="category_id" 
                                    required
                                    class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm form-input @error('category_id') error @enderror"
                                >
                                    <option value="">Select a category</option>
                                    @foreach($categories as $category)
                                        <option value="{{ $category->id }}" {{ old('category_id') == $category->id ? 'selected' : '' }}>
                                            {{ $category->name }}
                                        </option>
                                    @endforeach
                                </select>
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="bi bi-tags text-gray-400"></i>
                                </div>
                            </div>
                            @error('category_id')
                                <p class="mt-1 text-sm text-red-600 flex items-center">
                                    <i class="bi bi-exclamation-circle mr-1"></i>
                                    {{ $message }}
                                </p>
                            @enderror
                        </div>
                    </div>

                    <!-- Description with Rich Text Editor -->
                    <div class="form-group mt-6">
                        <label for="description" class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="bi bi-file-text-fill mr-2 text-blue-500"></i>
                            Description
                        </label>
                        <div class="rich-text-editor @error('description') error @enderror">
                            <div class="editor-toolbar">
                                <div class="btn-group">
                                    <button type="button" data-command="h1" title="Heading 1" aria-label="Heading 1">
                                        <i class="fa fa-heading"></i>1
                                    </button>
                                    <button type="button" data-command="h2" title="Heading 2" aria-label="Heading 2">
                                        <i class="fa fa-heading"></i>2
                                    </button>
                                    <button type="button" data-command="h3" title="Heading 3" aria-label="Heading 3">
                                        <i class="fa fa-heading"></i>3
                                    </button>
                                </div>
                                <div class="btn-group">
                                    <button type="button" data-command="bold" title="Bold" aria-label="Bold">
                                        <i class="fa fa-bold"></i>
                                    </button>
                                    <button type="button" data-command="italic" title="Italic" aria-label="Italic">
                                        <i class="fa fa-italic"></i>
                                    </button>
                                    <button type="button" data-command="underline" title="Underline" aria-label="Underline">
                                        <i class="fa fa-underline"></i>
                                    </button>
                                    <button type="button" data-command="strikeThrough" title="Strike through" aria-label="Strike through">
                                        <i class="fa fa-strikethrough"></i>
                                    </button>
                                </div>
                                <div class="btn-group">
                                    <button type="button" data-command="justifyLeft" title="Align left" aria-label="Align left">
                                        <i class="fa fa-align-left"></i>
                                    </button>
                                    <button type="button" data-command="justifyCenter" title="Align center" aria-label="Align center">
                                        <i class="fa fa-align-center"></i>
                                    </button>
                                    <button type="button" data-command="justifyRight" title="Align right" aria-label="Align right">
                                        <i class="fa fa-align-right"></i>
                                    </button>
                                </div>
                                <div class="btn-group">
                                    <button type="button" data-command="insertUnorderedList" title="Bullet list" aria-label="Bullet list">
                                        <i class="fa fa-list-ul"></i>
                                    </button>
                                    <button type="button" data-command="insertOrderedList" title="Number list" aria-label="Number list">
                                        <i class="fa fa-list-ol"></i>
                                    </button>
                                </div>
                                <div class="btn-group">
                                    <button type="button" data-command="createLink" title="Insert link" aria-label="Insert link">
                                        <i class="fa fa-link"></i>
                                    </button>
                                    <button type="button" data-command="unlink" title="Remove link" aria-label="Remove link">
                                        <i class="fa fa-unlink"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="editor-content custom-scrollbar" id="description-editor" contenteditable="true" aria-label="Description editor" aria-describedby="description-error">{{ old('description') }}</div>
                        </div>
                        <textarea id="description" name="description" class="hidden" required>{{ old('description') }}</textarea>
                        @error('description')
                            <p id="description-error" class="mt-1 text-sm text-red-600 flex items-center">
                                <i class="bi bi-exclamation-circle mr-1"></i>
                                {{ $message }}
                            </p>
                        @enderror
                        <p class="char-counter mt-1 text-sm text-gray-500">0/1000 characters</p>
                    </div>
                </div>

                <!-- Game Details Section -->
                <div class="p-6 sm:p-8 border-b border-gray-200">
                    <div class="flex items-center mb-6">
                        <div class="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center mr-4">
                            <i class="bi bi-gear-fill text-purple-600 text-xl"></i>
                        </div>
                        <div>
                            <h2 class="text-xl font-semibold text-gray-900">Game Details</h2>
                            <p class="text-gray-600 text-sm">Technical specifications and metadata</p>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <!-- Game Link -->
                        <div class="form-group">
                            <label for="game_link" class="block text-sm font-semibold text-gray-700 mb-2">
                                <i class="bi bi-globe mr-2 text-purple-500"></i>
                                Game Link
                            </label>
                            <div class="relative">
                                <input 
                                    type="url" 
                                    id="game_link" 
                                    name="game_link" 
                                    value="{{ old('game_link') }}" 
                                    required 
                                    placeholder="https://example.com/game"
                                    class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm form-input @error('game_link') error @enderror"
                                >
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="bi bi-link-45deg text-gray-400"></i>
                                </div>
                            </div>
                            @error('game_link')
                                <p class="mt-1 text-sm text-red-600 flex items-center">
                                    <i class="bi bi-exclamation-circle mr-1"></i>
                                    {{ $message }}
                                </p>
                            @enderror
                        </div>

                        <!-- Release Date -->
                        <div class="form-group">
                            <label for="release_date" class="block text-sm font-semibold text-gray-700 mb-2">
                                <i class="bi bi-calendar-event-fill mr-2 text-purple-500"></i>
                                Release Date
                            </label>
                            <div class="relative">
                                <input 
                                    type="date" 
                                    id="release_date" 
                                    name="release_date" 
                                    value="{{ old('release_date') }}" 
                                    required
                                    class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm form-input @error('release_date') error @enderror"
                                >
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="bi bi-calendar3 text-gray-400"></i>
                                </div>
                            </div>
                            @error('release_date')
                                <p class="mt-1 text-sm text-red-600 flex items-center">
                                    <i class="bi bi-exclamation-circle mr-1"></i>
                                    {{ $message }}
                                </p>
                            @enderror
                        </div>
                    </div>

                    <!-- Hashtags -->
                    <div class="form-group mt-6">
                        <label for="hashtags" class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="bi bi-hash mr-2 text-purple-500"></i>
                            Hashtags
                            <span class="tooltip ml-1">
                                <i class="bi bi-info-circle text-gray-400 cursor-help"></i>
                                <span class="tooltip-text">Add hashtags to help users discover your game</span>
                            </span>
                        </label>
                        <input 
                            type="text" 
                            id="hashtags" 
                            name="hashtags" 
                            value="{{ old('hashtags') }}" 
                            placeholder="action, adventure, puzzle (comma or space separated)"
                            class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm form-input @error('hashtags') error @enderror"
                        >
                        @error('hashtags')
                            <p class="mt-1 text-sm text-red-600 flex items-center">
                                <i class="bi bi-exclamation-circle mr-1"></i>
                                {{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>

                <!-- SEO Information Section -->
                <div class="p-6 sm:p-8 border-b border-gray-200">
                    <div class="flex items-center mb-6">
                        <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mr-4">
                            <i class="bi bi-search-heart-fill text-green-600 text-xl"></i>
                        </div>
                        <div>
                            <h2 class="text-xl font-semibold text-gray-900">SEO Information</h2>
                            <p class="text-gray-600 text-sm">Optimize your game for search engines</p>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <!-- Meta Keywords -->
                        <div class="form-group">
                            <label for="meta_keywords" class="block text-sm font-semibold text-gray-700 mb-2">
                                <i class="bi bi-key-fill mr-2 text-green-500"></i>
                                Meta Keywords
                            </label>
                            <input 
                                type="text" 
                                id="meta_keywords" 
                                name="meta_keywords" 
                                value="{{ old('meta_keywords') }}" 
                                placeholder="action game, shooter, multiplayer"
                                class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm form-input @error('meta_keywords') error @enderror"
                            >
                            @error('meta_keywords')
                                <p class="mt-1 text-sm text-red-600 flex items-center">
                                    <i class="bi bi-exclamation-circle mr-1"></i>
                                    {{ $message }}
                                </p>
                            @enderror
                        </div>

                        <!-- Meta Description -->
                        <div class="form-group">
                            <label for="meta_description" class="block text-sm font-semibold text-gray-700 mb-2">
                                <i class="bi bi-file-earmark-text-fill mr-2 text-green-500"></i>
                                Meta Description
                            </label>
                            <textarea 
                                id="meta_description" 
                                name="meta_description" 
                                rows="3" 
                                placeholder="Brief description for search engines"
                                class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm form-input @error('meta_description') error @enderror"
                            >{{ old('meta_description') }}</textarea>
                            @error('meta_description')
                                <p class="mt-1 text-sm text-red-600 flex items-center">
                                    <i class="bi bi-exclamation-circle mr-1"></i>
                                    {{ $message }}
                                </p>
                            @enderror
                        </div>
                    </div>
                </div>

                <!-- Game Image Section -->
                <div class="p-6 sm:p-8">
                    <div class="flex items-center mb-6">
                        <div class="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center mr-4">
                            <i class="bi bi-image-fill text-orange-600 text-xl"></i>
                        </div>
                        <div>
                            <h2 class="text-xl font-semibold text-gray-900">Game Thumbnail</h2>
                            <p class="text-gray-600 text-sm">Upload an attractive image for your game</p>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="dropzone rounded-xl p-8 text-center cursor-pointer" id="image-drop-area">
                            <input 
                                type="file" 
                                id="image" 
                                name="image" 
                                accept="image/*" 
                                class="hidden @error('image') error @enderror"
                            >
                            
                            <!-- Upload Icon and Text -->
                            <div id="upload-content" class="space-y-4">
                                <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                                    <i class="bi bi-cloud-upload text-blue-600 text-2xl"></i>
                                </div>
                                <div>
                                    <p class="text-lg font-semibold text-gray-900 mb-2">
                                        Drop your image here or click to browse
                                    </p>
                                    <p class="text-gray-600 text-sm">
                                        PNG, JPG, GIF up to 2MB • Recommended: 800×600px
                                    </p>
                                </div>
                            </div>
                            
                            <!-- Preview Area -->
                            <div id="preview-content" class="hidden space-y-4">
                                <div class="file-preview">
                                    <img id="image-preview" class="max-w-full max-h-48 rounded-lg shadow-lg mx-auto" alt="Preview">
                                    <div class="remove-btn" onclick="removeImage()">
                                        <i class="bi bi-x"></i>
                                    </div>
                                </div>
                                <div>
                                    <p id="file-info" class="text-sm text-gray-600"></p>
                                </div>
                            </div>
                        </div>
                        
                        @error('image')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="bi bi-exclamation-circle mr-1"></i>
                                {{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>

                <!-- Submit Button Section -->
                <div class="px-4 sm:px-6 lg:px-8 py-4 sm:py-6 bg-gray-50 border-t border-gray-200">
                    <div class="flex flex-col space-y-4 sm:space-y-0 sm:flex-row sm:items-center sm:justify-between">
                        <div class="text-sm text-gray-600 text-center sm:text-left">
                            <i class="bi bi-info-circle mr-1"></i>
                            All fields marked with * are required
                        </div>
                        <div class="flex flex-col sm:flex-row items-stretch sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
                            <a href="{{ route('admin.games.index') }}" class="inline-flex items-center justify-center px-4 sm:px-6 py-3 border border-gray-300 text-sm font-medium rounded-xl text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-200 shadow-sm">
                                <i class="bi bi-arrow-left mr-2"></i>
                                Cancel
                            </a>
                            <button 
                                type="submit" 
                                class="btn-gradient inline-flex items-center justify-center px-4 sm:px-8 py-3 border border-transparent text-sm font-semibold rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 shadow-lg"
                                id="submitBtn"
                            >
                                <i class="bi bi-plus-circle mr-2"></i>
                                <span id="submitText">Add Game</span>
                                <div id="loadingSpinner" class="spinner ml-2 hidden"></div>
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@section('scripts')
    <!-- Bootstrap 5 JS CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Rich Text Editor Functionality
            const buttons = document.querySelectorAll('.editor-toolbar button');
            const editor = document.getElementById('description-editor');
            const textarea = document.getElementById('description');
            const charCounter = document.querySelector('.char-counter');
            const maxLength = 1000;
            
            // Update hidden textarea with editor content
            function updateTextarea() {
                textarea.value = editor.innerHTML;
                updateCharCounter();
            }
            
            // Update character counter
            function updateCharCounter() {
                const textContent = editor.textContent || editor.innerText || '';
                const currentLength = textContent.length;
                const remaining = maxLength - currentLength;
                
                charCounter.textContent = `${currentLength}/${maxLength} characters`;
                
                if (remaining < 100) {
                    charCounter.classList.add('text-orange-500');
                    charCounter.classList.remove('text-gray-500');
                } else {
                    charCounter.classList.remove('text-orange-500');
                    charCounter.classList.add('text-gray-500');
                }
                
                if (currentLength > maxLength) {
                    charCounter.classList.add('text-red-500');
                    charCounter.classList.remove('text-orange-500', 'text-gray-500');
                }
            }
            
            // Initialize editor buttons
            buttons.forEach(button => {
                button.addEventListener('click', () => {
                    const command = button.dataset.command;
                    
                    if (command === 'h1' || command === 'h2' || command === 'h3') {
                        document.execCommand('formatBlock', false, command);
                    } else if (command === 'createLink') {
                        let url = prompt('Enter the link URL (e.g., https://example.com):', 'https://');
                        if (url) {
                            if (!/^https?:\/\//i.test(url)) {
                                url = 'https://' + url;
                            }
                            document.execCommand(command, false, url);
                            
                            // Find the newly created link and add target="_blank" attribute
                            const selection = window.getSelection();
                            if (selection.rangeCount > 0) {
                                const range = selection.getRangeAt(0);
                                const links = editor.querySelectorAll('a');
                                links.forEach(link => {
                                    if (range.intersectsNode(link)) {
                                        link.setAttribute('target', '_blank');
                                        link.setAttribute('rel', 'noopener noreferrer');
                                    }
                                });
                            }
                        }
                    } else {
                        document.execCommand(command, false, null);
                    }
                    
                    editor.focus();
                    updateTextarea();
                });
            });
            
            // Update textarea when editor content changes
            editor.addEventListener('input', updateTextarea);
            editor.addEventListener('blur', updateTextarea);
            editor.addEventListener('keyup', updateTextarea);
            
            // Initialize character counter
            updateCharCounter();

            // Image upload handling
            const imageInput = document.getElementById('image');
            const imagePreview = document.getElementById('image-preview');
            const uploadContent = document.getElementById('upload-content');
            const previewContent = document.getElementById('preview-content');
            const fileInfo = document.getElementById('file-info');
            const dropArea = document.getElementById('image-drop-area');
            const submitBtn = document.getElementById('submitBtn');
            const submitText = document.getElementById('submitText');
            const loadingSpinner = document.getElementById('loadingSpinner');

            // Image upload handling
            function handleFileSelect(file) {
                if (file) {
                    // Validate file type
                    if (!file.type.startsWith('image/')) {
                        alert('Please select an image file.');
                        return;
                    }

                    // Validate file size (2MB)
                    if (file.size > 2 * 1024 * 1024) {
                        alert('File size must be less than 2MB.');
                        return;
                    }

                    const reader = new FileReader();
                    reader.onload = function(e) {
                        imagePreview.src = e.target.result;
                        uploadContent.classList.add('hidden');
                        previewContent.classList.remove('hidden');
                        
                        // Update file info
                        const sizeInMB = (file.size / (1024 * 1024)).toFixed(2);
                        fileInfo.textContent = `${file.name} (${sizeInMB} MB)`;
                    };
                    reader.readAsDataURL(file);
                }
            }

            // File input change
            imageInput.addEventListener('change', function() {
                if (this.files && this.files[0]) {
                    handleFileSelect(this.files[0]);
                }
            });

            // Drag and drop functionality
            dropArea.addEventListener('click', () => imageInput.click());

            dropArea.addEventListener('dragover', (e) => {
                e.preventDefault();
                dropArea.classList.add('dragover');
            });

            dropArea.addEventListener('dragleave', () => {
                dropArea.classList.remove('dragover');
            });

            dropArea.addEventListener('drop', (e) => {
                e.preventDefault();
                dropArea.classList.remove('dragover');
                
                if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                    imageInput.files = e.dataTransfer.files;
                    handleFileSelect(e.dataTransfer.files[0]);
                }
            });

            // Remove image function
            window.removeImage = function() {
                imageInput.value = '';
                uploadContent.classList.remove('hidden');
                previewContent.classList.add('hidden');
                imagePreview.src = '';
                fileInfo.textContent = '';
            };

            // Form submission
            const form = document.getElementById('addGameForm');
            form.addEventListener('submit', function(e) {
                // Update textarea before submission
                updateTextarea();
                
                // Validate description
                const descriptionContent = editor.textContent || editor.innerText || '';
                if (!descriptionContent.trim()) {
                    e.preventDefault();
                    const richTextEditor = document.querySelector('.rich-text-editor');
                    richTextEditor.classList.add('error');
                    
                    // Show error message
                    let errorMsg = richTextEditor.parentElement.querySelector('.text-red-600');
                    if (!errorMsg) {
                        errorMsg = document.createElement('p');
                        errorMsg.className = 'mt-1 text-sm text-red-600 flex items-center';
                        errorMsg.innerHTML = '<i class="bi bi-exclamation-circle mr-1"></i>Description is required.';
                        richTextEditor.parentElement.appendChild(errorMsg);
                    }
                    return;
                }
                
                // Show loading state
                submitText.textContent = 'Adding Game...';
                loadingSpinner.classList.remove('hidden');
                submitBtn.disabled = true;
            });

            // Auto-hide alerts after 5 seconds
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.style.opacity = '0';
                    setTimeout(() => alert.remove(), 300);
                }, 5000);
            });

            // Auto-generate slug from game name
            const nameInput = document.getElementById('name');
            const slugInput = document.getElementById('slug');
            
            nameInput.addEventListener('input', function() {
                if (!slugInput.value.trim()) {
                    const slug = this.value
                        .toLowerCase()
                        .replace(/[^a-z0-9\s-]/g, '')
                        .replace(/\s+/g, '-')
                        .replace(/-+/g, '-')
                        .trim('-');
                    slugInput.value = slug;
                }
            });

            // Real-time validation feedback
            const inputs = form.querySelectorAll('input, select, textarea');
            inputs.forEach(input => {
                input.addEventListener('blur', function() {
                    if (this.hasAttribute('required') && !this.value.trim()) {
                        this.classList.add('error');
                    } else {
                        this.classList.remove('error');
                    }
                });

                input.addEventListener('input', function() {
                    if (this.value.trim()) {
                        this.classList.remove('error');
                    }
                });
            });

            // Editor validation
            editor.addEventListener('blur', function() {
                const content = this.textContent || this.innerText || '';
                const richTextEditor = this.closest('.rich-text-editor');
                
                if (!content.trim()) {
                    richTextEditor.classList.add('error');
                } else {
                    richTextEditor.classList.remove('error');
                }
            });

            editor.addEventListener('input', function() {
                const content = this.textContent || this.innerText || '';
                const richTextEditor = this.closest('.rich-text-editor');
                
                if (content.trim()) {
                    richTextEditor.classList.remove('error');
                }
            });
        });
    </script>
@endsection
