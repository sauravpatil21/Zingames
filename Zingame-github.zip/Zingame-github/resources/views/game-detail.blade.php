<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $game->name }} - ZinGames</title>
    <meta name="description" content="{{ $game->meta_description ?? 'Play ' . $game->name . ' online for free on ZinGames.' }}">
    <meta name="keywords" content="{{ $game->meta_keywords ?? '' }}">
    <meta name="author" content="ZinGames">
    <meta name="robots" content="index, follow">
    <meta property="og:title" content="{{ $game->name }} - ZinGames">
    <meta property="og:description" content="{{ Str::limit($game->description, 150) }}">
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url('/games/' . $game->slug) }}">
    @if($game->image)
    <meta property="og:image" content="{{ asset('storage/' . $game->image) }}">
    @endif
    <link rel="canonical" href="{{ url('/games/' . $game->slug) }}">

    <!-- Google Fonts - Poppins -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Custom Tailwind Configuration -->
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'poppins': ['Poppins', 'sans-serif'],
                    },
                    colors: {
                        'night': {
                            50: '#f8fafc',
                            100: '#f1f5f9',
                            200: '#e2e8f0',
                            300: '#cbd5e1',
                            400: '#94a3b8',
                            500: '#64748b',
                            600: '#475569',
                            700: '#334155',
                            800: '#1e293b',
                            900: '#0f172a',
                            950: '#020617',
                        },
                        'neon': {
                            'cyan': '#00d4ff',
                            'pink': '#ff0080',
                            'purple': '#8b5cf6',
                            'blue': '#3b82f6',
                        }
                    },
                    animation: {
                        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
                        'bounce-slow': 'bounce 2s infinite',
                        'float': 'float 6s ease-in-out infinite',
                        'glow': 'glow 2s ease-in-out infinite alternate',
                        'shimmer': 'shimmer 2.5s linear infinite',
                        'slide-in': 'slideIn 0.5s ease-out',
                    },
                    keyframes: {
                        float: {
                            '0%, 100%': { transform: 'translateY(0px)' },
                            '50%': { transform: 'translateY(-10px)' },
                        },
                        glow: {
                            '0%': { boxShadow: '0 0 5px #00d4ff, 0 0 10px #00d4ff, 0 0 15px #00d4ff' },
                            '100%': { boxShadow: '0 0 10px #00d4ff, 0 0 20px #00d4ff, 0 0 30px #00d4ff' },
                        },
                        shimmer: {
                            '0%': { transform: 'translateX(-100%)' },
                            '100%': { transform: 'translateX(100%)' },
                        },
                        slideIn: {
                            '0%': { transform: 'translateY(20px)', opacity: '0' },
                            '100%': { transform: 'translateY(0)', opacity: '1' },
                        }
                    }
                },
            },
        };
    </script>

    <style>
        /* Custom Scrollbar */
        .custom-scrollbar::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
            background: rgba(15, 23, 42, 0.3);
            border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: linear-gradient(180deg, #00d4ff, #8b5cf6);
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(180deg, #00d4ff, #ff0080);
        }

        /* Glassmorphism Effects */
        .glass {
            background: rgba(15, 23, 42, 0.7);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .glass-strong {
            background: rgba(15, 23, 42, 0.9);
            backdrop-filter: blur(30px);
            border: 1px solid rgba(255, 255, 255, 0.15);
        }

        /* Loading Animation */
        @keyframes loadingPulse {
            0%, 100% { 
                transform: scale(1); 
                opacity: 0.5; 
            }
            50% { 
                transform: scale(1.2); 
                opacity: 1; 
            }
        }

        .loading-dot {
            animation: loadingPulse 1.5s infinite ease-in-out;
        }
        .loading-dot:nth-child(2) { animation-delay: 0.2s; }
        .loading-dot:nth-child(3) { animation-delay: 0.4s; }

        /* Hover Effects */
        .hover-lift {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .hover-lift:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 40px rgba(0, 212, 255, 0.2);
        }

        .hover-glow:hover {
            box-shadow: 0 0 20px rgba(0, 212, 255, 0.4);
        }

        /* Shimmer Effect */
        .shimmer-effect {
            position: relative;
            overflow: hidden;
        }
        .shimmer-effect::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
            animation: shimmer 2s infinite;
        }

        /* Game Description Styling */
        .game-description {
            line-height: 1.8;
            color: #e2e8f0;
        }
        
        .game-description h1, .game-description h2, .game-description h3, 
        .game-description h4, .game-description h5, .game-description h6 {
            color: #f8fafc;
            font-weight: 600;
            margin: 1.5rem 0 1rem 0;
        }
        
        .game-description h1 { font-size: 1.8rem; }
        .game-description h2 { font-size: 1.6rem; }
        .game-description h3 { font-size: 1.4rem; }
        
        .game-description p {
            margin-bottom: 1rem;
        }
        
        .game-description a {
            color: #00d4ff;
            text-decoration: none;
            border-bottom: 1px solid transparent;
            transition: all 0.3s ease;
        }
        
        .game-description a:hover {
            color: #ff0080;
            border-bottom-color: #ff0080;
        }
        
        .game-description ul, .game-description ol {
            padding-left: 1.5rem;
            margin-bottom: 1rem;
        }
        
        .game-description li {
            margin-bottom: 0.5rem;
            }
            
        .game-description blockquote {
            border-left: 4px solid #00d4ff;
            padding-left: 1rem;
            font-style: italic;
            margin: 1.5rem 0;
            background: rgba(0, 212, 255, 0.05);
            padding: 1rem;
            border-radius: 0 0.5rem 0.5rem 0;
        }
        
        .game-description code {
            background: rgba(139, 92, 246, 0.2);
            color: #c4b5fd;
            padding: 0.2rem 0.4rem;
            border-radius: 0.25rem;
            font-size: 0.9em;
        }
        
        .game-description pre {
            background: rgba(15, 23, 42, 0.8);
            border: 1px solid rgba(139, 92, 246, 0.3);
            border-radius: 0.5rem;
            padding: 1rem;
                overflow-x: auto;
            margin: 1rem 0;
        }
        
        .game-description pre code {
            background: none;
            padding: 0;
            color: #e2e8f0;
            }
            
        .game-description img {
            max-width: 100%;
            height: auto;
            border-radius: 0.5rem;
            margin: 1rem 0;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            }
            
        .game-description table {
                width: 100%;
            border-collapse: collapse;
            margin: 1rem 0;
            background: rgba(15, 23, 42, 0.5);
            border-radius: 0.5rem;
            overflow: hidden;
        }
        
        .game-description th, .game-description td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .game-description th {
            background: rgba(139, 92, 246, 0.2);
            color: #f8fafc;
            font-weight: 600;
        }

        /* Horizontal Scroll Container */
        .horizontal-scroll {
            scrollbar-width: none;
            -ms-overflow-style: none;
        }
        .horizontal-scroll::-webkit-scrollbar {
            display: none;
        }

        /* Game Card Styling */
        .game-card {
                position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }
        
        .game-card::before {
            content: '';
            position: absolute;
                top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
            transition: left 0.5s ease;
        }
        
        .game-card:hover::before {
            left: 100%;
        }

        /* Tab Styling */
        .tab.active {
            background: linear-gradient(135deg, #00d4ff, #8b5cf6);
            color: #0f172a;
            font-weight: 600;
            border-radius: 0.5rem 0.5rem 0 0;
            }
            
        /* Hashtag Styling */
        .hashtag {
            background: linear-gradient(135deg, rgba(0, 212, 255, 0.2), rgba(139, 92, 246, 0.2));
            border: 1px solid rgba(0, 212, 255, 0.3);
            transition: all 0.3s ease;
            }
            
        .hashtag:hover {
            background: linear-gradient(135deg, rgba(0, 212, 255, 0.3), rgba(139, 92, 246, 0.3));
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 212, 255, 0.3);
            }
            
        /* Fullscreen Button */
        .fullscreen-btn {
            background: rgba(15, 23, 42, 0.8);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
            }
            
        .fullscreen-btn:hover {
            background: rgba(0, 212, 255, 0.2);
            border-color: #00d4ff;
            transform: scale(1.1);
            }
            
        /* Play Button Styling */
        .play-btn {
            background: linear-gradient(135deg, #00d4ff, #ff0080);
            position: relative;
            overflow: hidden;
        }
        
        .play-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s ease;
            }
            
        .play-btn:hover::before {
            left: 100%;
        }

        /* Responsive Design */
        @media (max-width: 1440px) {
            .game-iframe-container {
                height: 70vh;
            }
        }
        
        @media (max-width: 1024px) {
            .game-iframe-container {
                height: 65vh;
            }
            
            .game-header {
                flex-direction: column;
                align-items: center;
                text-align: center;
                gap: 1rem;
            }
            
            .game-title-wrapper {
                flex-direction: column;
                text-align: center;
            }
            
            .game-logo {
                margin-right: 0 !important;
                margin-bottom: 1rem;
            }
        }
        
        @media (max-width: 768px) {
            .game-iframe-container {
                height: 55vh;
            }
            
            .game-header {
                padding: 1rem !important;
            }
            
            .game-title-wrapper h1 {
                font-size: 1.5rem !important;
            }
            
            .game-tabs {
                font-size: 0.85rem;
            }
            
            .game-tabs .tab {
                padding: 0.75rem 0.5rem !important;
            }
            
            .game-description {
                font-size: 0.9rem;
                max-height: 60vh !important;
            }
            
            .recommended-games-container {
                padding: 0.5rem;
            }
            
            .game-card {
                min-width: 180px;
                width: 180px !important;
            }
            
            .loading-progress {
                width: 90% !important;
                max-width: 300px;
            }
            
            .loading-text {
                font-size: 1.5rem !important;
            }
            
            .loading-dots {
                gap: 0.5rem !important;
            }
            
            .loading-dot {
                width: 0.75rem !important;
                height: 0.75rem !important;
            }
            
            .fullscreen-btn {
                top: 1rem !important;
                right: 1rem !important;
                padding: 0.5rem !important;
            }
            
            .fullscreen-btn i {
                font-size: 1rem !important;
            }
        }
        
        @media (max-width: 480px) {
            .game-iframe-container {
                height: 45vh;
            }
            
            .game-header {
                padding: 0.75rem !important;
            }
            
            .game-title-wrapper h1 {
                font-size: 1.25rem !important;
            }
            
            .game-logo {
                width: 3rem !important;
                height: 3rem !important;
            }
            
            .game-tabs {
                font-size: 0.8rem;
            }
            
            .game-tabs .tab {
                padding: 0.5rem 0.25rem !important;
            }
            
            .game-description {
                font-size: 0.85rem;
                max-height: 50vh !important;
            }
            
            .game-card {
                min-width: 150px;
                width: 150px !important;
            }
            
            .game-card h4 {
                font-size: 0.9rem !important;
            }
            
            .game-card p {
                font-size: 0.75rem !important;
            }
            
            .play-btn {
                font-size: 0.75rem !important;
                padding: 0.5rem 0.75rem !important;
            }
            
            .loading-progress {
                width: 95% !important;
                max-width: 250px;
                height: 0.5rem !important;
            }
            
            .loading-text {
                font-size: 1.25rem !important;
            }
            
            .loading-dots {
                gap: 0.25rem !important;
            }
            
            .loading-dot {
                width: 0.5rem !important;
                height: 0.5rem !important;
            }
            
            .fullscreen-btn {
                top: 0.5rem !important;
                right: 0.5rem !important;
                padding: 0.25rem !important;
            }
            
            .fullscreen-btn i {
                font-size: 0.875rem !important;
            }
            
            .hashtag {
                font-size: 0.75rem !important;
                padding: 0.5rem 0.75rem !important;
            }
            
            .popular-categories-section .glass {
                padding: 1rem !important;
            }
            
            .popular-categories-section h3 {
                font-size: 1.25rem !important;
            }
        }
        
        @media (max-width: 360px) {
            .game-iframe-container {
                height: 40vh;
            }
            
            .game-title-wrapper h1 {
                font-size: 1.1rem !important;
            }
            
            .game-card {
                min-width: 130px;
                width: 130px !important;
            }
            
            .loading-progress {
                width: 100% !important;
                max-width: 200px;
            }
        }
    </style>
</head>

<body class="bg-gradient-to-br from-night-950 via-night-900 to-night-800 text-gray-200 font-poppins overflow-x-hidden min-h-screen">
    <!-- Include Header -->
    @include('partials.header')

    <!-- Include Sidebar -->
    @include('partials.sidebar')

    <!-- Main Content with Full Width Layout -->
    <div class="container mx-auto px-4 sm:px-6 py-6">
            <!-- Game Header -->
        <div class="game-header glass rounded-2xl p-6 mb-6 animate-slide-in">
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div class="game-title-wrapper flex items-center">
                    @if($game->image)
                        <img src="{{ asset('storage/' . $game->image) }}" alt="{{ $game->name }}" 
                             class="game-logo w-16 h-16 rounded-xl mr-4 object-cover border-2 border-neon-cyan/30">
                    @else
                        <img src="https://source.unsplash.com/random/64x64/?game" alt="{{ $game->name }}" 
                             class="game-logo w-16 h-16 rounded-xl mr-4 object-cover border-2 border-neon-cyan/30">
                    @endif
                    <div>
                        <h1 class="text-2xl sm:text-3xl font-bold text-white mb-1">{{ $game->name }}</h1>
                        <p class="text-neon-cyan text-sm">{{ $game->category->name }}</p>
                    </div>
                    </div>
                </div>
            </div>

            <!-- Game Iframe Container -->
        <div class="game-iframe-container relative w-full h-[75vh] bg-night-950 rounded-2xl overflow-hidden mb-6 border border-neon-cyan/20 shadow-2xl animate-slide-in">
            <iframe id="game-iframe" class="game-iframe absolute top-0 left-0 w-full h-full border-none" 
                    src="{{ $game->game_link }}" allowfullscreen></iframe>
            
            <!-- Loading Overlay -->
            <div class="loading-overlay absolute top-0 left-0 w-full h-full glass-strong flex flex-col justify-center items-center z-10" id="loadingOverlay">
                <div class="text-center px-4">
                    <div class="loading-text text-2xl font-bold text-white mb-6 animate-pulse">Loading Game</div>
                    <div class="loading-dots flex gap-3 mb-6 justify-center">
                        <div class="loading-dot w-4 h-4 bg-neon-cyan rounded-full"></div>
                        <div class="loading-dot w-4 h-4 bg-neon-pink rounded-full"></div>
                        <div class="loading-dot w-4 h-4 bg-neon-purple rounded-full"></div>
                    </div>
                    <div class="loading-progress w-full max-w-xs h-3 bg-night-800 rounded-full overflow-hidden border border-neon-cyan/30">
                        <div class="progress-bar h-full bg-gradient-to-r from-neon-cyan via-neon-purple to-neon-pink rounded-full transition-all duration-500" id="progressBar"></div>
                    </div>
                    <div class="mt-4 text-lg text-white font-semibold">
                        <span id="loadPercent">0%</span>
                    </div>
                </div>
            </div>
            
                <!-- Fullscreen Toggle Button -->
            <button id="fullscreenBtn" class="fullscreen-btn absolute top-6 right-6 text-white p-3 rounded-full z-20">
                <i class="fas fa-expand text-xl"></i>
                </button>
            </div>

            <!-- Game Info Tabs -->
        <div class="game-info glass rounded-2xl p-4 sm:p-6 mb-8 animate-slide-in">
            <div class="game-tabs flex border-b border-gray-700 mb-4 sm:mb-6">
                <div class="tab flex-1 py-2 sm:py-3 text-center text-sm sm:text-base font-medium cursor-pointer transition-all duration-300 hover:bg-night-700/50 active" data-tab="description">
                    <i class="fas fa-info-circle mr-1 sm:mr-2"></i>Description
                </div>
                <div class="tab flex-1 py-2 sm:py-3 text-center text-sm sm:text-base font-medium cursor-pointer transition-all duration-300 hover:bg-night-700/50" data-tab="details">
                    <i class="fas fa-cog mr-1 sm:mr-2"></i>Details
                </div>
                </div>

                <div class="tab-content active" id="description-content">
                <div class="game-description max-h-96 overflow-y-auto custom-scrollbar pr-4">
                        {!! $game->description !!}
                    </div>
                    @if($game->hashtags)
                    <div class="hashtags flex flex-wrap gap-3 mt-6">
                            @foreach(explode(' ', $game->hashtags) as $tag)
                            <span class="hashtag text-neon-cyan px-4 py-2 rounded-full text-sm font-medium">
                                #{{ $tag }}
                            </span>
                            @endforeach
                        </div>
                    @endif
                </div>

                <div class="tab-content hidden" id="details-content">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
                    <div class="space-y-3 sm:space-y-4">
                        <div class="flex justify-between items-center p-3 sm:p-4 glass rounded-xl">
                            <span class="text-gray-400 font-medium text-sm sm:text-base">Category:</span>
                            <span class="text-white font-semibold text-sm sm:text-base">{{ $game->category->name }}</span>
                        </div>
                        <div class="flex justify-between items-center p-3 sm:p-4 glass rounded-xl">
                            <span class="text-gray-400 font-medium text-sm sm:text-base">Release Date:</span>
                            <span class="text-white font-semibold text-sm sm:text-base">{{ \Carbon\Carbon::parse($game->release_date)->format('d M, Y') }}</span>
                        </div>
                    </div>
                    <div class="space-y-3 sm:space-y-4">
                        <div class="flex justify-between items-center p-3 sm:p-4 glass rounded-xl">
                            <span class="text-gray-400 font-medium text-sm sm:text-base">Platform:</span>
                            <span class="text-white font-semibold text-sm sm:text-base">Browser (HTML5)</span>
                        </div>
                        <div class="flex justify-between items-center p-3 sm:p-4 glass rounded-xl">
                            <span class="text-gray-400 font-medium text-sm sm:text-base">Views:</span>
                            <span class="text-white font-semibold text-sm sm:text-base">{{ number_format($game->views ?? 0) }}</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recommended Games Section -->
        <div class="recommended-games-section animate-slide-in">
            <div class="glass rounded-2xl p-6">
                <h3 class="text-2xl font-bold text-white text-center mb-8 flex items-center justify-center">
                    <i class="fas fa-gamepad mr-3 text-neon-cyan"></i>
                    Recommended Games
                </h3>

                <!-- Horizontal Scrolling Games -->
                <div class="recommended-games-container overflow-x-auto horizontal-scroll">
                    <div class="flex gap-4 sm:gap-6 pb-4" style="min-width: max-content;">
                        @foreach($relatedGames->take(12) as $recommendedGame)
                            <div class="game-card flex-shrink-0 w-48 sm:w-56 md:w-64 glass rounded-xl overflow-hidden hover-lift">
                                <a href="{{ url('/games/' . $recommendedGame->slug) }}" 
                                   class="block">
                        @if($recommendedGame->image)
                                        <img src="{{ asset('storage/' . $recommendedGame->image) }}" alt="{{ $recommendedGame->name }}" 
                                             class="w-full h-32 sm:h-36 md:h-40 object-cover transition-transform duration-300 hover:scale-110">
                        @else
                                        <img src="https://source.unsplash.com/random/256x160/?game" alt="{{ $recommendedGame->name }}" 
                                             class="w-full h-32 sm:h-36 md:h-40 object-cover transition-transform duration-300 hover:scale-110">
                        @endif
                                    <div class="p-3 sm:p-4">
                                        <h4 class="text-sm sm:text-base md:text-lg font-semibold text-white mb-2 line-clamp-2">{{ $recommendedGame->name }}</h4>
                                        <p class="text-xs sm:text-sm text-gray-400 mb-2 sm:mb-3">{{ $recommendedGame->category->name }}</p>
                                        <span class="play-btn inline-block text-white px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all duration-300 hover:scale-105">
                                            <i class="fas fa-play mr-1"></i>Play Now
                                        </span>
                        </div>
                    </a>
                            </div>
                @endforeach
                    </div>
                </div>
            </div>
            </div>

        <!-- Popular Categories Section -->
        <div class="popular-categories-section mt-8 animate-slide-in">
            <div class="glass rounded-2xl p-4 sm:p-6">
                <h3 class="text-xl sm:text-2xl font-bold text-white text-center mb-6 sm:mb-8 flex items-center justify-center">
                    <i class="fas fa-tags mr-2 sm:mr-3 text-neon-cyan"></i>
                    Popular Categories
                </h3>
                <div class="flex flex-wrap gap-2 sm:gap-3 justify-center">
                    @if(isset($categories) && count($categories) > 0)
                        @foreach($categories->take(15) as $category)
                            <a href="{{ url('/category/' . $category->id . '/' . \Illuminate\Support\Str::slug($category->name)) }}" 
                               class="px-3 sm:px-6 py-2 sm:py-3 glass rounded-full text-xs sm:text-sm text-neon-cyan hover:bg-neon-cyan/20 transition-all duration-300 hover-lift">
                                {{ $category->name }}
                            </a>
                        @endforeach
                    @endif
                </div>
            </div>
        </div>
    </div>

    <!-- Include Footer -->
    @include('partials.footer')

    <!-- JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Loading Animation
            const loadingOverlay = document.getElementById('loadingOverlay');
            const progressBar = document.getElementById('progressBar');
            const loadPercent = document.getElementById('loadPercent');
            
            // Simulate loading progress with realistic delays
            let progress = 0;
            const loadingInterval = setInterval(() => {
                progress += Math.random() * 8 + 2; // More realistic progress
                if (progress >= 100) {
                    progress = 100;
                    clearInterval(loadingInterval);
                    setTimeout(() => {
                        loadingOverlay.style.opacity = 0;
                        setTimeout(() => {
                            loadingOverlay.style.display = 'none';
                        }, 500);
                    }, 800);
                }
                progressBar.style.width = `${progress}%`;
                loadPercent.textContent = `${Math.floor(progress)}%`;
            }, 300);

            // Tab Functionality with Auto-scroll
            const tabs = document.querySelectorAll('.tab');
            const tabContents = document.querySelectorAll('.tab-content');
            
            tabs.forEach(tab => {
                tab.addEventListener('click', () => {
                    const tabId = tab.getAttribute('data-tab');
                    
                    // Remove active class from all tabs
                    tabs.forEach(t => t.classList.remove('active'));
                    tabContents.forEach(content => content.classList.add('hidden'));
                    
                    // Add active class to clicked tab
                    tab.classList.add('active');
                    document.getElementById(`${tabId}-content`).classList.remove('hidden');
                    
                    // Auto-scroll to tab content
                    document.getElementById(`${tabId}-content`).scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                });
            });

            // Process all links in game description
            const gameDescription = document.querySelector('.game-description');
            if (gameDescription) {
                const links = gameDescription.querySelectorAll('a');
                links.forEach(link => {
                    link.setAttribute('target', '_blank');
                    link.setAttribute('rel', 'noopener noreferrer');
                });
                
                // Wrap tables in scrollable div
                const tables = gameDescription.querySelectorAll('table');
                tables.forEach(table => {
                    if (!table.parentNode.classList.contains('table-wrapper')) {
                        const wrapper = document.createElement('div');
                        wrapper.className = 'table-wrapper overflow-x-auto';
                        table.parentNode.insertBefore(wrapper, table);
                        wrapper.appendChild(table);
                    }
                });
            }

            // Fullscreen Toggle Functionality
            const fullscreenBtn = document.getElementById('fullscreenBtn');
            const gameIframeContainer = document.querySelector('.game-iframe-container');

            fullscreenBtn.addEventListener('click', () => {
                if (!document.fullscreenElement) {
                    if (gameIframeContainer.requestFullscreen) {
                        gameIframeContainer.requestFullscreen();
                    } else if (gameIframeContainer.webkitRequestFullscreen) {
                        gameIframeContainer.webkitRequestFullscreen();
                    } else if (gameIframeContainer.msRequestFullscreen) {
                        gameIframeContainer.msRequestFullscreen();
                    }
                    fullscreenBtn.innerHTML = '<i class="fas fa-compress text-xl"></i>';
                } else {
                    if (document.exitFullscreen) {
                        document.exitFullscreen();
                    } else if (document.webkitExitFullscreen) {
                        document.webkitExitFullscreen();
                    } else if (document.msExitFullscreen) {
                        document.msExitFullscreen();
                    }
                    fullscreenBtn.innerHTML = '<i class="fas fa-expand text-xl"></i>';
                }
            });

            // Adjust iframe size on fullscreen change
            document.addEventListener('fullscreenchange', () => {
                if (document.fullscreenElement) {
                    gameIframeContainer.classList.remove('h-[75vh]');
                    gameIframeContainer.classList.add('h-screen');
                } else {
                    gameIframeContainer.classList.remove('h-screen');
                    gameIframeContainer.classList.add('h-[75vh]');
                }
            });

            // Add shimmer effect to game cards on hover
            const gameCards = document.querySelectorAll('.game-card');
            gameCards.forEach(card => {
                card.addEventListener('mouseenter', () => {
                    card.classList.add('shimmer-effect');
                });
                card.addEventListener('mouseleave', () => {
                    card.classList.remove('shimmer-effect');
                });
            });

            // Smooth scroll for internal links
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    const target = document.querySelector(this.getAttribute('href'));
                    if (target) {
                        target.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                });
            });

            // Add scroll indicators for horizontal scroll
            const scrollContainer = document.querySelector('.recommended-games-container');
            if (scrollContainer) {
                let isScrolling = false;
                let startX;
                let scrollLeft;

                scrollContainer.addEventListener('mousedown', (e) => {
                    isScrolling = true;
                    startX = e.pageX - scrollContainer.offsetLeft;
                    scrollLeft = scrollContainer.scrollLeft;
                });

                scrollContainer.addEventListener('mouseleave', () => {
                    isScrolling = false;
                });

                scrollContainer.addEventListener('mouseup', () => {
                    isScrolling = false;
                });

                scrollContainer.addEventListener('mousemove', (e) => {
                    if (!isScrolling) return;
                    e.preventDefault();
                    const x = e.pageX - scrollContainer.offsetLeft;
                    const walk = (x - startX) * 2;
                    scrollContainer.scrollLeft = scrollLeft - walk;
                });
            }
        });
    </script>
</body>
</html>
