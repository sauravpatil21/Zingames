<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>@yield('title') - {{ config('app.name', 'ZinGames') }}</title>
    
    <!-- Favicon -->
    <link rel="shortcut icon" href="{{ asset('images/favicon.ico') }}" type="image/x-icon">
    
    <!-- CSS Libraries -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Custom Styles -->
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    
    <!-- Meta Tags -->
    <meta name="description" content="@yield('meta_description', 'ZinGames - Play Free Online Games')">
    <meta name="keywords" content="@yield('meta_keywords', 'games, online games, free games, browser games')">
    
    <!-- Additional Styles -->
    @yield('styles')
    
    <style>
        body {
            background-color: #24252A;
            color: #ffffff;
            font-family: 'Montserrat', sans-serif;
        }
        
        .text-cyan {
            color: #0088a9;
        }
        
        .bg-cyan {
            background-color: #0088a9;
        }
        
        .btn-cyan {
            background-color: #0088a9;
            color: white;
        }
        
        .btn-cyan:hover {
            background-color: #006d87;
            color: white;
        }
    </style>
</head>
<body>
    <div id="app">
        @yield('content')
    </div>
    
    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom Scripts -->
    <script src="{{ asset('js/main.js') }}"></script>
    
    <!-- Additional Scripts -->
    @yield('scripts')
</body>
</html> 