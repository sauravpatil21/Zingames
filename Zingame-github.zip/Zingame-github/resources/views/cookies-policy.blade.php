<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cookies Policy - ZinGames</title>
    <meta name="description" content="ZinGames cookie policy explains how we use cookies and similar technologies, your privacy choices, and how we personalize your gaming experience while respecting your data.">
    <meta name="keywords" content="cookies policy, privacy, ZinGames cookies, online gaming cookies, user tracking, cookie management">
    <meta name="author" content="ZinGames">
    <meta name="robots" content="index, follow">
    <meta property="og:title" content="Cookies Policy - ZinGames">
    <meta property="og:description" content="Learn how ZinGames uses cookies to enhance your gaming experience, personalize content, and respect your privacy choices.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url('/cookies-policy') }}">
    <meta property="og:image" content="{{ asset('img/favicon.ico') }}">
    <link rel="canonical" href="{{ url('/cookies-policy') }}">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome CDN for Social Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
        integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        /* Custom Static CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #0f172a, #1e293b);
            color: #e0e0e0;
            line-height: 1.6;
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }

        /* Main Layout */
        .main-container {
            display: flex;
            min-height: calc(100vh - 80px);
            position: relative;
            overflow: hidden;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 250px;
            background: linear-gradient(145deg, #1e293b, #2d3748);
            padding: 1.5rem 0;
            height: calc(100vh - 80px);
            position: fixed;
            top: 80px;
            left: -250px;
            z-index: 1500;
            transition: all 0.4s ease;
            box-shadow: 5px 0 20px rgba(0, 0, 0, 0.4);
            overflow-y: auto;
        }

        .sidebar.open {
            left: 0;
        }

        /* About Us Container */
        .about-container {
            flex: 1;
            padding: 2rem 3rem;
            transition: margin-left 0.4s ease;
            margin-left: 0;
        }

        .about-container.shifted {
            margin-left: 250px;
        }

        .about-section {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            padding: 2.5rem;
            margin-bottom: 3rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .about-section:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: 700;
            color: #ffffff;
            margin-bottom: 1.5rem;
            text-shadow: 0 0 15px rgba(66, 153, 225, 0.8);
            position: relative;
            display: inline-block;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 0;
            width: 60px;
            height: 4px;
            background: linear-gradient(90deg, #4299e1, #4c51bf);
            border-radius: 2px;
        }

        .about-text {
            font-size: 1.1rem;
            line-height: 1.8;
            color: #d0d0d0;
            margin-bottom: 1.5rem;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .sidebar {
                width: 220px;
                left: -220px;
            }

            .sidebar.open {
                left: 0;
            }

            .about-container.shifted {
                margin-left: 220px;
            }
            
            .about-section {
                padding: 2rem;
            }
            
            .section-title {
                font-size: 2.2rem;
            }
        }

        @media (max-width: 768px) {
            .main-container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                top: 0;
                left: -100%;
            }
            
            .sidebar.open {
                left: 0;
            }
            
            .about-container {
                padding: 1.5rem;
                margin-left: 0;
            }
            
            .about-container.shifted {
                margin-left: 0;
            }
            
            .about-section {
                padding: 1.5rem;
            }
            
            .section-title {
                font-size: 1.8rem;
            }
            
            .about-text {
                font-size: 1rem;
            }
        }
        
        @media (max-width: 480px) {
            .about-container {
                padding: 1rem;
            }
            
            .about-section {
                padding: 1.25rem;
                margin-bottom: 2rem;
            }
            
            .section-title {
                font-size: 1.5rem;
            }
            
            .about-text {
                font-size: 0.95rem;
            }
        }
    </style>
</head>

<body>
    <!-- Particles Background -->
    <div class="particles">
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
    </div>

    <!-- Include Header -->
    @include('partials.header')

    <!-- Main Content -->
    <main class="main-container">
        <!-- Include Sidebar -->
        @include('partials.sidebar')

        <!-- Cookies Policy Container -->
        <section class="about-container" id="aboutContainer">
            <div class="about-section">
                <div class="flex flex-1">
                    <main class="flex-1 p-8 pt-[90px]">
                        <h1 class="text-3xl font-bold mb-6 text-gray-100">Cookie Policy</h1>
                        
                        <p class="mb-6 text-gray-300">At ApplySet Media, we prioritize the privacy of all users visiting the ZinGames website. This Cookie Policy provides clear insights into ZinGames' privacy practices. It details the types of data we collect from our website visitors, especially those from the European Economic Area (EEA)*, and explains the use of cookies and similar technologies on zingames.com and associated domains (referred to as the <b>"ZinGames Website"</b>). Additionally, it offers background information on cookies and guidance on managing your cookie preferences.</p>
                        
                        <p class="mb-6 text-gray-300">ApplySet Media Pvt. Ltd. ("ApplySet Media", "we", "our", or "us") is responsible for processing your data through the ZinGames Website (hereinafter referred to as "ZinGames", "Site"). For further information on how we manage your data and your privacy rights, please consult the ZinGames Privacy Policy.</p>
                        
                        <p class="mb-6 text-gray-300">Please be aware that we may update this Cookie Statement from time to time. Please check here often for updates. Your continued use of the Site will be considered as your consent to the revised terms. We encourage you to review this Cookie Statement regularly to stay informed about the most recent version.</p>
                        
                        <p class="mb-6 text-gray-300">Your region is determined based on your IP address. Using a VPN might prevent you from seeing the Cookie Policy relevant to your actual location.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">Understanding Cookies</h3>
                        <p class="mb-6 text-gray-300">Cookies are small data files stored on your computer, tablet, smartphone, or other internet-enabled devices via your web browser. Websites place these cookies on your device through your browser, such as Microsoft Edge, Firefox, Safari, Google Chrome, Opera, Brave, and others.</p>
                        
                        <p class="mb-6 text-gray-300">There are two main categories of cookies:</p>
                        <ul class="list-disc list-inside mb-6 pl-5 text-gray-300">
                            <li><b>First-Party Cookies:</b> These are cookies that ZinGames places on your device for our own purposes.</li>
                            <li><b>Third-Party Cookies:</b> These cookies are placed by or on behalf of external parties (e.g., advertisers). ZinGames may also obtain cookie information from third parties when you visit other websites.</li>
                        </ul>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">Purpose of Cookies</h3>
                        <p class="mb-6 text-gray-300">Cookies enable ZinGames to recognize your device as you navigate through the ZinGames Website, remembering settings such as language preferences and game progress. Third-party cookies may also be used for similar purposes.</p>
                        
                        <p class="mb-6 text-gray-300">For more information on cookies, visit <b>www.allaboutcookies.org.</b></p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">Cookie Lifespan</h3>
                        <p class="mb-6 text-gray-300">Cookies have a defined validity period:</p>
                        <ul class="list-disc list-inside mb-6 pl-5 text-gray-300">
                            <li><b>Default Period:</b> Cookies are automatically removed by your browser after their validity period expires. ApplySet Media ensures they are removed after the specified time in the Cookie Table.</li>
                            <li><b>Early Deletion/Refusal:</b> You can manually delete cookies before they expire or refuse cookies that require your consent. Refer to "Managing Cookies and Cookie Settings" for more information.</li>
                        </ul>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">Similar Technologies</h3>
                        <p class="mb-6 text-gray-300">In addition to cookies, other technologies such as HTML5 Local Storage and Web Beacons (tracking pixels) can be used for similar purposes.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">Types of Cookies We Use</h3>
                        <p class="mb-6 text-gray-300">ZinGames employs three types of cookies:</p>
                        <ul class="list-disc list-inside mb-6 pl-5 text-gray-300">
                            <li><b>Functional Cookies:</b> Essential for the proper functioning and navigation of the website. These cookies do not require your consent.</li>
                            <li><b>Analytical Cookies:</b> Used to analyze website usage and improve our services. Consent is not always required unless it significantly impacts your privacy.</li>
                            <li><b>Advertising Cookies:</b> Used to personalize your experience and deliver relevant ads. These cookies require your prior consent.</li>
                        </ul>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">Who Places Which Cookies?</h3>
                        <p class="mb-6 text-gray-300"><b>ZinGames Cookies:</b> Placed directly by or on behalf of ZinGames. This includes all functional cookies, some analytical cookies, and certain advertising cookies.</p>
                        
                        <p class="mb-6 text-gray-300"><b>Developer Cookies:</b> Game developers may include cookies in their games for tracking purposes. While ZinGames is not responsible for these cookies, we ensure contractual safeguards are in place and provide a list of cookies used by developers.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">Externally Hosted Games and Websites</h3>
                        <p class="mb-6 text-gray-300">This Cookie Policy applies only to cookies used on the ZinGames Website. We are not responsible for cookies placed by third parties when you visit other websites. We inform you via a banner if you access a third-party website from ZinGames.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">Managing Cookies and Cookie Settings</h3>
                        <p class="mb-6 text-gray-300"><b>Cookie Settings on ZinGames Website:</b> You can change your cookie settings when you visit our website for the first time. This allows you to control the use of data for personalization, performance measurement, and more.</p>
                        
                        <p class="mb-6 text-gray-300"><b>Browser Settings:</b> Most browsers allow you to adjust settings to receive warnings before cookies are placed, refuse all cookies, or delete existing cookies. These settings need to be adjusted on each browser and device you use.</p>
                        
                        <p class="mb-6 text-gray-300">Blocking or deleting certain cookies may affect the functionality of the ZinGames Website. While you may still see advertisements, they may be less relevant.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">How to Change or Delete Cookie Settings in Your Browser</h3>
                        <p class="mb-6 text-gray-300">For convenience, here are links on how to change cookie settings in popular browsers:</p>
                        <ul class="list-disc list-inside mb-6 pl-5 text-gray-300">
                            <li><a href="https://support.microsoft.com/en-us/help/17442/windows-internet-explorer-delete-manage-cookies" class="text-blue-400 hover:underline">Internet Explorer</a></li>
                            <li><a href="https://support.microsoft.com/en-us/help/4468242/microsoft-edge-browsing-data-and-privacy-microsoft-privacy" class="text-blue-400 hover:underline">Microsoft Edge</a></li>
                            <li><a href="https://support.mozilla.org/en-US/kb/cookies-information-websites-store-on-your-computer" class="text-blue-400 hover:underline">Mozilla Firefox</a></li>
                            <li><a href="https://support.google.com/chrome/answer/95647" class="text-blue-400 hover:underline">Google Chrome</a></li>
                            <li><a href="https://support.apple.com/en-in/guide/safari/sfri11471/mac" class="text-blue-400 hover:underline">Safari</a></li>
                            <li><a href="https://help.opera.com/en/latest/web-preferences/#cookies" class="text-blue-400 hover:underline">Opera</a></li>
                        </ul>
                        
                        <p class="mb-6 text-gray-300">If you have further questions about our cookie policy, please contact us at <a href="mailto:privacy@zingames.com" class="text-blue-400 hover:underline">privacy@zingames.com</a>.</p>
                    </main>
                </div>
            </div>
        </section>
    </main>

    <!-- Include Footer -->
    @include('partials.footer')

    <!-- JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Sidebar Toggle
            const sidebar = document.getElementById('sidebar');
            const sidebarToggle = document.getElementById('sidebarToggle');
            const aboutContainer = document.getElementById('aboutContainer');

            sidebarToggle.addEventListener('click', () => {
                sidebar.classList.toggle('open');
                aboutContainer.classList.toggle('shifted');
                sidebarToggle.querySelector('i').classList.toggle('fa-bars');
                sidebarToggle.querySelector('i').classList.toggle('fa-times');
            });

            // Close sidebar on outside click
            document.addEventListener('click', (e) => {
                if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
                    sidebar.classList.remove('open');
                    aboutContainer.classList.remove('shifted');
                    sidebarToggle.querySelector('i').classList.remove('fa-times');
                    sidebarToggle.querySelector('i').classList.add('fa-bars');
                }
            });

            // Header scroll effect
            window.addEventListener('scroll', () => {
                const header = document.querySelector('.header');
                if (window.scrollY > 50) {
                    header.classList.add('scrolled');
                } else {
                    header.classList.remove('scrolled');
                }
            });
        });
    </script>
</body>

</html> 