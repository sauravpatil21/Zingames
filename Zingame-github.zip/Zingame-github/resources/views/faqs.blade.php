<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Frequently Asked Questions - ZinGames</title>
    <meta name="description" content="Find answers to the most commonly asked questions about ZinGames, including game safety, educational content, technical requirements, and more.">
    <meta name="keywords" content="ZinGames FAQs, gaming questions, online games help, frequently asked questions, game safety, free games">
    <meta name="author" content="ZinGames">
    <meta name="robots" content="index, follow">
    <meta property="og:title" content="Frequently Asked Questions - ZinGames">
    <meta property="og:description" content="Get answers to common questions about ZinGames platform, game safety, educational content, technical requirements, and more.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url('/faqs') }}">
    <meta property="og:image" content="{{ asset('img/favicon.ico') }}">
    <link rel="canonical" href="{{ url('/faqs') }}">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome CDN for Social Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
        integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        /* Custom Static CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #0f172a, #1e293b);
            color: #e0e0e0;
            line-height: 1.6;
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }

        /* Main Layout */
        .main-container {
            display: flex;
            min-height: calc(100vh - 80px);
            position: relative;
            overflow: hidden;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 250px;
            background: linear-gradient(145deg, #1e293b, #2d3748);
            padding: 1.5rem 0;
            height: calc(100vh - 80px);
            position: fixed;
            top: 80px;
            left: -250px;
            z-index: 1500;
            transition: all 0.4s ease;
            box-shadow: 5px 0 20px rgba(0, 0, 0, 0.4);
            overflow-y: auto;
        }

        .sidebar.open {
            left: 0;
        }

        /* About Us Container */
        .about-container {
            flex: 1;
            padding: 2rem 3rem;
            transition: margin-left 0.4s ease;
            margin-left: 0;
        }

        .about-container.shifted {
            margin-left: 250px;
        }

        .about-section {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            padding: 2.5rem;
            margin-bottom: 3rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .about-section:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: 700;
            color: #ffffff;
            margin-bottom: 1.5rem;
            text-shadow: 0 0 15px rgba(66, 153, 225, 0.8);
            position: relative;
            display: inline-block;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 0;
            width: 60px;
            height: 4px;
            background: linear-gradient(90deg, #4299e1, #4c51bf);
            border-radius: 2px;
        }

        .about-text {
            font-size: 1.1rem;
            line-height: 1.8;
            color: #d0d0d0;
            margin-bottom: 1.5rem;
        }

        /* FAQs Accordion Styling */
        .faq-item {
            background: rgba(43, 43, 60, 0.5);
            border-radius: 8px;
            margin-bottom: 1rem;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .faq-item:hover {
            background: rgba(43, 43, 60, 0.8);
        }

        .faq-question {
            padding: 1.25rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-weight: 600;
            color: #e0e0e0;
        }

        .faq-question i {
            transition: transform 0.3s ease;
        }

        .faq-answer {
            padding: 0 1.25rem;
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease, padding 0.3s ease;
        }

        .faq-item.active .faq-question i {
            transform: rotate(45deg);
        }

        .faq-item.active .faq-answer {
            padding: 0 1.25rem 1.25rem;
            max-height: 500px;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .sidebar {
                width: 220px;
                left: -220px;
            }

            .sidebar.open {
                left: 0;
            }

            .about-container.shifted {
                margin-left: 220px;
            }
            
            .about-section {
                padding: 2rem;
            }
            
            .section-title {
                font-size: 2.2rem;
            }
            
            .faq-item {
                margin-bottom: 0.75rem;
            }
            
            .faq-question {
                padding: 1rem;
            }
            
            .faq-item.active .faq-answer {
                padding: 0 1rem 1rem;
            }
        }

        @media (max-width: 768px) {
            .main-container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                top: 0;
                left: -100%;
            }
            
            .sidebar.open {
                left: 0;
            }
            
            .about-container {
                padding: 1.5rem;
                margin-left: 0;
            }
            
            .about-container.shifted {
                margin-left: 0;
            }
            
            .about-section {
                padding: 1.5rem;
            }
            
            .section-title {
                font-size: 1.8rem;
            }
            
            .about-text {
                font-size: 1rem;
            }
            
            h1 {
                font-size: 1.8rem;
                margin-bottom: 1.5rem;
            }
            
            .faq-item {
                margin-bottom: 0.6rem;
            }
            
            .faq-question {
                padding: 0.8rem;
                font-size: 0.95rem;
            }
            
            .faq-question i.fas.fa-question-circle {
                font-size: 1.2rem;
            }
            
            .faq-item.active .faq-answer {
                padding: 0 0.8rem 0.8rem;
                max-height: 800px;
            }
            
            .faq-answer p {
                font-size: 0.9rem;
            }
        }
        
        @media (max-width: 480px) {
            .about-container {
                padding: 1rem;
            }
            
            .about-section {
                padding: 1.25rem;
                margin-bottom: 2rem;
            }
            
            .section-title {
                font-size: 1.5rem;
            }
            
            .about-text {
                font-size: 0.95rem;
            }
            
            h1 {
                font-size: 1.5rem;
                margin-bottom: 1.25rem;
            }
            
            .faq-item {
                margin-bottom: 0.5rem;
            }
            
            .faq-question {
                padding: 0.7rem;
                font-size: 0.9rem;
            }
            
            .faq-question i.fas.fa-question-circle {
                font-size: 1rem;
                margin-right: 0.5rem;
            }
            
            .faq-item.active .faq-answer {
                padding: 0 0.7rem 0.7rem;
            }
            
            .faq-answer p {
                font-size: 0.85rem;
                padding: 0.5rem 0;
            }
        }
    </style>
</head>

<body>
    <!-- Particles Background -->
    <div class="particles">
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
    </div>

    <!-- Include Header -->
    @include('partials.header')

    <!-- Main Content -->
    <main class="main-container">
        <!-- Include Sidebar -->
        @include('partials.sidebar')

        <!-- FAQs Container -->
        <section class="about-container" id="aboutContainer">
            <div class="about-section">
                <h1 class="text-3xl font-bold mb-8 text-center text-white">Frequently Asked Questions</h1>
                
                <div class="max-w-3xl mx-auto">
                    <div class="faq-item mb-4" itemscope itemtype="https://schema.org/Question">
                        <div class="faq-question flex items-center">
                            <i class="fas fa-question-circle text-yellow-400 text-xl mr-3"></i>
                            <span itemprop="name" class="flex-1">What is ZinGames?</span>
                            <i class="fas fa-plus text-gray-400"></i>
                        </div>
                        <div class="faq-answer" itemscope itemtype="https://schema.org/Answer">
                            <p itemprop="text" class="text-gray-300 py-2">
                                ZinGames is a free browser-based gaming platform that offers a wide variety of games across different categories. We provide a secure and entertaining environment for players of all ages, with a focus on both fun and educational content. All our games are playable directly in your web browser without requiring downloads or installations.
                            </p>
                        </div>
                    </div>

                    <div class="faq-item mb-4" itemscope itemtype="https://schema.org/Question">
                        <div class="faq-question flex items-center">
                            <i class="fas fa-question-circle text-yellow-400 text-xl mr-3"></i>
                            <span itemprop="name" class="flex-1">How educational are the games on ZinGames?</span>
                            <i class="fas fa-plus text-gray-400"></i>
                        </div>
                        <div class="faq-answer" itemscope itemtype="https://schema.org/Answer">
                            <p itemprop="text" class="text-gray-300 py-2">
                                ZinGames offers a range of educational games designed to develop various cognitive skills including problem-solving, memory, math, logic, and language skills. Our Educational category features games specifically designed with learning objectives, while many of our puzzle and strategy games also promote critical thinking. We regularly review and add new educational content to ensure a balanced mix of entertainment and learning.
                            </p>
                        </div>
                    </div>

                    <div class="faq-item mb-4" itemscope itemtype="https://schema.org/Question">
                        <div class="faq-question flex items-center">
                            <i class="fas fa-question-circle text-yellow-400 text-xl mr-3"></i>
                            <span itemprop="name" class="flex-1">How secure is playing on ZinGames?</span>
                            <i class="fas fa-plus text-gray-400"></i>
                        </div>
                        <div class="faq-answer" itemscope itemtype="https://schema.org/Answer">
                            <p itemprop="text" class="text-gray-300 py-2">
                                At ZinGames, security is a top priority. We rigorously vet all games before adding them to our platform to ensure they're free from malware and inappropriate content. Our website employs HTTPS encryption to protect data transmission, and we don't require any personal information to play most games. For parents, we provide comprehensive guidance on safe gaming practices and parental controls. We also regularly update our security protocols to maintain a safe gaming environment.
                            </p>
                        </div>
                    </div>

                    <div class="faq-item mb-4" itemscope itemtype="https://schema.org/Question">
                        <div class="faq-question flex items-center">
                            <i class="fas fa-question-circle text-yellow-400 text-xl mr-3"></i>
                            <span itemprop="name" class="flex-1">What should I do if I encounter inappropriate advertising on ZinGames?</span>
                            <i class="fas fa-plus text-gray-400"></i>
                        </div>
                        <div class="faq-answer" itemscope itemtype="https://schema.org/Answer">
                            <p itemprop="text" class="text-gray-300 py-2">
                                We carefully select our advertising partners to ensure age-appropriate content, but occasionally inappropriate ads might slip through. If you encounter any concerning advertisements, please report them immediately to <strong>privacy@zingames.com</strong> with details including a screenshot if possible, the game you were playing, and the time you saw the ad. We take these reports very seriously and will address the issue promptly to maintain our family-friendly environment.
                            </p>
                        </div>
                    </div>

                    <div class="faq-item mb-4" itemscope itemtype="https://schema.org/Question">
                        <div class="faq-question flex items-center">
                            <i class="fas fa-question-circle text-yellow-400 text-xl mr-3"></i>
                            <span itemprop="name" class="flex-1">Are there any risks of viruses with ZinGames?</span>
                            <i class="fas fa-plus text-gray-400"></i>
                        </div>
                        <div class="faq-answer" itemscope itemtype="https://schema.org/Answer">
                            <p itemprop="text" class="text-gray-300 py-2">
                                ZinGames is designed to be completely safe from viruses and malware. All our games run directly in your browser and don't require downloads or installations that could contain malicious software. Our technical team regularly scans the platform for security vulnerabilities, and we employ strict security measures to protect our users. Always ensure you're visiting the official ZinGames website (zingames.com) and not a copycat site to maintain your security.
                            </p>
                        </div>
                    </div>

                    <div class="faq-item mb-4" itemscope itemtype="https://schema.org/Question">
                        <div class="faq-question flex items-center">
                            <i class="fas fa-question-circle text-yellow-400 text-xl mr-3"></i>
                            <span itemprop="name" class="flex-1">Is downloading required to play games on ZinGames?</span>
                            <i class="fas fa-plus text-gray-400"></i>
                        </div>
                        <div class="faq-answer" itemscope itemtype="https://schema.org/Answer">
                            <p itemprop="text" class="text-gray-300 py-2">
                                No, downloading is not required to play games on ZinGames. All our games are browser-based and run directly in your web browser using technologies like HTML5 and JavaScript. This means you can start playing immediately without waiting for downloads, installations, or updates. This approach not only makes gaming more accessible but also eliminates security concerns associated with downloading files.
                            </p>
                        </div>
                    </div>

                    <div class="faq-item mb-4" itemscope itemtype="https://schema.org/Question">
                        <div class="faq-question flex items-center">
                            <i class="fas fa-question-circle text-yellow-400 text-xl mr-3"></i>
                            <span itemprop="name" class="flex-1">Is it true that all games on ZinGames are free?</span>
                            <i class="fas fa-plus text-gray-400"></i>
                        </div>
                        <div class="faq-answer" itemscope itemtype="https://schema.org/Answer">
                            <p itemprop="text" class="text-gray-300 py-2">
                                Yes, all games on ZinGames are completely free to play. We maintain our platform through non-intrusive advertising that allows us to provide quality games without charging users. While some games may offer optional in-game purchases or premium features, these are clearly marked and entirely optional. Our core philosophy is to make gaming accessible to everyone without financial barriers.
                            </p>
                        </div>
                    </div>

                    <div class="faq-item mb-4" itemscope itemtype="https://schema.org/Question">
                        <div class="faq-question flex items-center">
                            <i class="fas fa-question-circle text-yellow-400 text-xl mr-3"></i>
                            <span itemprop="name" class="flex-1">How do I suggest a new game or feature for ZinGames?</span>
                            <i class="fas fa-plus text-gray-400"></i>
                        </div>
                        <div class="faq-answer" itemscope itemtype="https://schema.org/Answer">
                            <p itemprop="text" class="text-gray-300 py-2">
                                We welcome suggestions from our community! To recommend a new game or feature, please use our Contact Us page or email us directly at <strong>suggestions@zingames.com</strong>. Include as much detail as possible about your suggestion, including game links if applicable. Our team reviews all submissions and prioritizes them based on user interest and technical feasibility. While we can't implement every suggestion, your feedback is invaluable in helping us improve the ZinGames experience.
                            </p>
                        </div>
                    </div>

                    <div class="faq-item mb-4" itemscope itemtype="https://schema.org/Question">
                        <div class="faq-question flex items-center">
                            <i class="fas fa-question-circle text-yellow-400 text-xl mr-3"></i>
                            <span itemprop="name" class="flex-1">What type of multiplayer games does ZinGames offer?</span>
                            <i class="fas fa-plus text-gray-400"></i>
                        </div>
                        <div class="faq-answer" itemscope itemtype="https://schema.org/Answer">
                            <p itemprop="text" class="text-gray-300 py-2">
                                ZinGames offers various types of multiplayer experiences. We have local multiplayer games that you can play with friends on the same device, as well as online multiplayer games that connect players from around the world. Our multiplayer selection includes competitive games like racing and sports, cooperative puzzle-solving, and strategy games. All multiplayer interactions are moderated to ensure a positive gaming environment suitable for players of all ages.
                            </p>
                        </div>
                    </div>

                    <div class="faq-item mb-4" itemscope itemtype="https://schema.org/Question">
                        <div class="faq-question flex items-center">
                            <i class="fas fa-question-circle text-yellow-400 text-xl mr-3"></i>
                            <span itemprop="name" class="flex-1">How frequently does ZinGames update its game library?</span>
                            <i class="fas fa-plus text-gray-400"></i>
                        </div>
                        <div class="faq-answer" itemscope itemtype="https://schema.org/Answer">
                            <p itemprop="text" class="text-gray-300 py-2">
                                We add new games to our library regularly, typically adding several new titles each month. Our content team continuously evaluates new games for quality, engagement, and appropriateness before adding them to the platform. We also perform maintenance updates on existing games to ensure they continue to function properly with the latest browser technologies. You can check our homepage or follow our social media channels to stay updated on the newest additions to our library.
                            </p>
                        </div>
                    </div>

                    <div class="faq-item mb-4" itemscope itemtype="https://schema.org/Question">
                        <div class="faq-question flex items-center">
                            <i class="fas fa-question-circle text-yellow-400 text-xl mr-3"></i>
                            <span itemprop="name" class="flex-1">Can I submit feedback or a review for a game on ZinGames?</span>
                            <i class="fas fa-plus text-gray-400"></i>
                        </div>
                        <div class="faq-answer" itemscope itemtype="https://schema.org/Answer">
                            <p itemprop="text" class="text-gray-300 py-2">
                                Yes! We value user feedback and encourage players to share their experiences. Each game page has a rating system and comment section where you can leave your thoughts and suggestions. Your reviews help other players discover great games and provide developers with valuable insights. We monitor all comments to ensure they meet our community guidelines and contribute positively to the ZinGames experience.
                            </p>
                        </div>
                    </div>

                    <div class="faq-item mb-4" itemscope itemtype="https://schema.org/Question">
                        <div class="faq-question flex items-center">
                            <i class="fas fa-question-circle text-yellow-400 text-xl mr-3"></i>
                            <span itemprop="name" class="flex-1">Do ZinGames require internet access to play?</span>
                            <i class="fas fa-plus text-gray-400"></i>
                        </div>
                        <div class="faq-answer" itemscope itemtype="https://schema.org/Answer">
                            <p itemprop="text" class="text-gray-300 py-2">
                                Yes, most games on ZinGames require an active internet connection as they run directly in your browser. However, some games may continue to function after they've loaded even if your connection is temporarily interrupted. For the best experience, we recommend a stable internet connection. Some browsers also support offline caching, allowing certain games to be played without an internet connection after initial loading, though this functionality varies by browser and game.
                            </p>
                        </div>
                    </div>

                    <div class="faq-item mb-4" itemscope itemtype="https://schema.org/Question">
                        <div class="faq-question flex items-center">
                            <i class="fas fa-question-circle text-yellow-400 text-xl mr-3"></i>
                            <span itemprop="name" class="flex-1">What kind of support does ZinGames offer to players?</span>
                            <i class="fas fa-plus text-gray-400"></i>
                        </div>
                        <div class="faq-answer" itemscope itemtype="https://schema.org/Answer">
                            <p itemprop="text" class="text-gray-300 py-2">
                                ZinGames offers multiple support channels for our players. Our comprehensive FAQ section addresses common questions, while our Contact Us page allows you to submit specific inquiries. For technical issues, we provide troubleshooting guides and personalized support via email at <strong>support@zingames.com</strong>. Our community forums are also a great resource where players can share tips and solutions. We aim to respond to all support requests within 24-48 hours during business days.
                            </p>
                        </div>
                    </div>

                    <div class="faq-item mb-4" itemscope itemtype="https://schema.org/Question">
                        <div class="faq-question flex items-center">
                            <i class="fas fa-question-circle text-yellow-400 text-xl mr-3"></i>
                            <span itemprop="name" class="flex-1">Are there any age restrictions for playing games on ZinGames?</span>
                            <i class="fas fa-plus text-gray-400"></i>
                        </div>
                        <div class="faq-answer" itemscope itemtype="https://schema.org/Answer">
                            <p itemprop="text" class="text-gray-300 py-2">
                                ZinGames is designed to be suitable for players of all ages, with a particular focus on children and families. All games on our platform are carefully vetted to ensure age-appropriate content. We recommend parental supervision for children under 13, as outlined in our Information for Parents page. Some games may have specific age recommendations based on complexity or content, which are clearly indicated on the game's page to help parents make informed decisions.
                            </p>
                        </div>
                    </div>

                    <div class="faq-item mb-4" itemscope itemtype="https://schema.org/Question">
                        <div class="faq-question flex items-center">
                            <i class="fas fa-question-circle text-yellow-400 text-xl mr-3"></i>
                            <span itemprop="name" class="flex-1">How does ZinGames handle user data and privacy?</span>
                            <i class="fas fa-plus text-gray-400"></i>
                        </div>
                        <div class="faq-answer" itemscope itemtype="https://schema.org/Answer">
                            <p itemprop="text" class="text-gray-300 py-2">
                                ZinGames takes privacy very seriously, especially for our younger users. We collect minimal personal data, primarily using cookies for essential site functionality and anonymous analytics to improve our service. We never sell user data to third parties. Game progress may be stored locally in your browser for convenience. For full details on our data practices, please review our comprehensive Privacy Policy and Cookie Policy, which outline exactly what information we collect and how it's used.
                            </p>
                        </div>
                    </div>

                    <div class="faq-item mb-4" itemscope itemtype="https://schema.org/Question">
                        <div class="faq-question flex items-center">
                            <i class="fas fa-question-circle text-yellow-400 text-xl mr-3"></i>
                            <span itemprop="name" class="flex-1">Can I play games on ZinGames with friends remotely?</span>
                            <i class="fas fa-plus text-gray-400"></i>
                        </div>
                        <div class="faq-answer" itemscope itemtype="https://schema.org/Answer">
                            <p itemprop="text" class="text-gray-300 py-2">
                                Yes, many of our multiplayer games support remote play with friends. Games with online multiplayer functionality typically have built-in matchmaking or allow you to create private rooms that you can invite friends to join via a shared link or room code. For games without built-in multiplayer, you can use screen-sharing tools like Discord or Zoom alongside ZinGames to create a shared gaming experience. Check the description on each game's page for specific multiplayer features.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Include Footer -->
    @include('partials.footer')

    <!-- JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Sidebar Toggle
            const sidebar = document.getElementById('sidebar');
            const sidebarToggle = document.getElementById('sidebarToggle');
            const aboutContainer = document.getElementById('aboutContainer');

            sidebarToggle.addEventListener('click', () => {
                sidebar.classList.toggle('open');
                aboutContainer.classList.toggle('shifted');
                sidebarToggle.querySelector('i').classList.toggle('fa-bars');
                sidebarToggle.querySelector('i').classList.toggle('fa-times');
            });

            // Close sidebar on outside click
            document.addEventListener('click', (e) => {
                if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
                    sidebar.classList.remove('open');
                    aboutContainer.classList.remove('shifted');
                    sidebarToggle.querySelector('i').classList.remove('fa-times');
                    sidebarToggle.querySelector('i').classList.add('fa-bars');
                }
            });

            // Header scroll effect
            window.addEventListener('scroll', () => {
                const header = document.querySelector('.header');
                if (window.scrollY > 50) {
                    header.classList.add('scrolled');
                } else {
                    header.classList.remove('scrolled');
                }
            });

            // FAQ Accordion
            const faqItems = document.querySelectorAll('.faq-item');
            faqItems.forEach(item => {
                const question = item.querySelector('.faq-question');
                question.addEventListener('click', () => {
                    item.classList.toggle('active');
                });
            });
        });
    </script>
</body>

</html> 