<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy - ZinGames</title>
    <meta name="description" content="ZinGames privacy policy - Learn how we collect, use, and protect your personal information. Our commitment to data security and your privacy rights.">
    <meta name="keywords" content="privacy policy, data protection, online gaming privacy, ZinGames privacy, user data, personal information">
    <meta name="author" content="ZinGames">
    <meta name="robots" content="index, follow">
    <meta property="og:title" content="Privacy Policy - ZinGames">
    <meta property="og:description" content="ZinGames privacy policy - Learn how we collect, use, and protect your personal information.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url('/privacy-policy') }}">
    <meta property="og:image" content="{{ asset('img/favicon.ico') }}">
    <link rel="canonical" href="{{ url('/privacy-policy') }}">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome CDN for Social Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
        integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        /* Custom Static CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #0f172a, #1e293b);
            color: #e0e0e0;
            line-height: 1.6;
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }

        /* Main Layout */
        .main-container {
            display: flex;
            min-height: calc(100vh - 80px);
            position: relative;
            overflow: hidden;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 250px;
            background: linear-gradient(145deg, #1e293b, #2d3748);
            padding: 1.5rem 0;
            height: calc(100vh - 80px);
            position: fixed;
            top: 80px;
            left: -250px;
            z-index: 1500;
            transition: all 0.4s ease;
            box-shadow: 5px 0 20px rgba(0, 0, 0, 0.4);
            overflow-y: auto;
        }

        .sidebar.open {
            left: 0;
        }

        /* About Us Container */
        .about-container {
            flex: 1;
            padding: 2rem 3rem;
            transition: margin-left 0.4s ease;
            margin-left: 0;
        }

        .about-container.shifted {
            margin-left: 250px;
        }

        .about-section {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            padding: 2.5rem;
            margin-bottom: 3rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .about-section:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: 700;
            color: #ffffff;
            margin-bottom: 1.5rem;
            text-shadow: 0 0 15px rgba(66, 153, 225, 0.8);
            position: relative;
            display: inline-block;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 0;
            width: 60px;
            height: 4px;
            background: linear-gradient(90deg, #4299e1, #4c51bf);
            border-radius: 2px;
        }

        .about-text {
            font-size: 1.1rem;
            line-height: 1.8;
            color: #d0d0d0;
            margin-bottom: 1.5rem;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .sidebar {
                width: 220px;
                left: -220px;
            }

            .sidebar.open {
                left: 0;
            }

            .about-container.shifted {
                margin-left: 220px;
            }
            
            .about-section {
                padding: 2rem;
            }
            
            .section-title {
                font-size: 2.2rem;
            }
        }

        @media (max-width: 768px) {
            .main-container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                top: 0;
                left: -100%;
            }
            
            .sidebar.open {
                left: 0;
            }
            
            .about-container {
                padding: 1.5rem;
                margin-left: 0;
            }
            
            .about-container.shifted {
                margin-left: 0;
            }
            
            .about-section {
                padding: 1.5rem;
            }
            
            .flex-1 {
                padding: 1rem;
                padding-top: 70px;
            }
            
            h1 {
                font-size: 1.8rem;
                margin-bottom: 1rem;
            }
            
            h3 {
                font-size: 1.4rem;
                margin-bottom: 0.75rem;
            }
            
            .section-title {
                font-size: 1.8rem;
            }
            
            .about-text {
                font-size: 1rem;
            }
            
            ul.list-disc {
                padding-left: 1.5rem;
            }
            
            ol li {
                margin-bottom: 1rem;
            }
        }
        
        @media (max-width: 480px) {
            .about-container {
                padding: 1rem;
            }
            
            .about-section {
                padding: 1.25rem;
                margin-bottom: 2rem;
            }
            
            .flex-1 {
                padding: 0.75rem;
                padding-top: 60px;
            }
            
            h1 {
                font-size: 1.5rem;
            }
            
            h3 {
                font-size: 1.2rem;
            }
            
            .section-title {
                font-size: 1.5rem;
            }
            
            .about-text, p {
                font-size: 0.95rem;
            }
            
            ul.list-disc {
                padding-left: 1rem;
            }
            
            li {
                margin-bottom: 0.5rem;
            }
        }
    </style>
</head>

<body>
    <!-- Particles Background -->
    <div class="particles">
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
    </div>

    <!-- Include Header -->
    @include('partials.header')

    <!-- Main Content -->
    <main class="main-container">
        <!-- Include Sidebar -->
        @include('partials.sidebar')

        <!-- Privacy Policy Container -->
        <section class="about-container" id="aboutContainer">
            <div class="about-section">
                <div class="flex flex-1">
                    <main class="flex-1 p-8 pt-[90px]">
                        <h1 class="text-4xl font-bold mb-6 text-gray-100">Privacy Policy</h1>
                        
                        <p class="mb-6 text-gray-300">Zingames, operated by Applyset Media, a limited liability company under the Indian law, registered at Surat, Gujarat, India (hereinafter referred to as <b>"Zingames", "Applyset Media", "we", "us", or "our"</b>), operates the website zingames.com (hereinafter referred to as <b>"Site" or "Website"</b>). This Privacy Policy applies to all services and products offered by Zingames and Zingames.com. Please note that Zingames is not responsible for the privacy practices of other websites and sources.</p>

                        <p class="mb-6 text-gray-300">Zingames is the data controller for the purposes of this Privacy Policy. By using our Site, you agree to this Privacy Policy and confirm that you are of legal age to agree to its terms.</p>

                        <p class="mb-6 text-gray-300">We may update this Privacy Policy to reflect new technologies, practices, or legal requirements. Please check here often for updates. Your continued use of the Site will be considered as your consent to the revised terms. We respect the privacy of all users and ensure that the personal information you provide is treated confidentially. We understand the trust you place in us and are committed to protecting your privacy. This page explains what information we collect when you use our Site, why we collect it, and how it enhances your user experience.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">1. Data Collection and Utilization</h3>
                        <p class="mb-6 text-gray-300">All functionalities on the Zingames Website are accessible without requiring registration. We do not collect or process personal contact information such as your name, email address, or phone number unless you actively reach out to us. Additionally, our game developers are typically required to remove all outgoing links, branding, and advertisements (such as splash screens, social links, and app store links) from their games.</p>

                        <p class="mb-6 text-gray-300">However, Zingames does gather certain electronic data, which we may process in various ways. Below is an overview of our data processing practices and detailed information about specific contexts.</p>

                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">General Data Processing Purposes</h3>
                        <p class="mb-4 text-gray-300">We may process your data for the following reasons:</p>
                        <ul class="list-disc list-inside mb-6 text-gray-300 pl-5">
                            <li>Maintenance, administration, and security of our networks</li>
                            <li>Internal controls and business operations</li>
                            <li>Analyzing and enhancing our products</li>
                            <li>Addressing requests, complaints, and disputes</li>
                            <li>Exercising and defending our legal rights</li>
                            <li>Complying with legal obligations and requests from government authorities</li>
                        </ul>

                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">General Data Processing Grounds</h3>
                        <p class="mb-6 text-gray-300">We may process your data based on legal obligations, meaning we handle your data as required by law, such as for statutory retention periods.</p>

                        <p class="mb-6 text-gray-300"><b>Legitimate Interest: </b>Sometimes, we process your data based on our legitimate interests. This means we balance our interests against your privacy rights, and if our interests prevail, we proceed with the processing. If you want more information about this, you can contact us directly using the contact details provided below.</p>

                        <p class="mb-6 text-gray-300"><b>Minors and Other Protected Individuals: </b>The Zingames Website is not intended for individuals under 13 years old or those under legal guardianship or supervision. If we do focus on such individuals, Zingames will take extra precautions to ensure their privacy and security.</p>

                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">Specific Data Processing Scenarios</h3>
                        <p class="mb-4 text-gray-300"><b>General Website Usage</b></p>
                        <p class="mb-6 text-gray-300">We process your data to provide, maintain, and improve the Zingames Website, our apps, and for our social media activities. For more specific information on the cookies and similar technologies used, please refer to our Cookie Statement.</p>

                        <p class="mb-4 text-gray-300"><b>Visitors to Our Website</b></p>
                        <p class="mb-4 text-gray-300">When you visit the Zingames Websites, your data may be processed for the following purposes:</p>
                        <ul class="list-disc list-inside mb-6 text-gray-300 pl-5">
                            <li>Functioning of the Zingames Website (including remembering your settings and consent choices)</li>
                            <li>Advertising and marketing to you, including targeted advertising and presenting relevant advertisements</li>
                            <li>Displaying privacy information relevant to your region (the specific data processed depends on the region from which you access the Zingames Website)</li>
                        </ul>
                        
                        <p class="mb-4 text-gray-300"><b>Data Collected During Visits</b></p>
                        <p class="mb-4 text-gray-300">When you visit the Zingames Website, we may automatically collect and process the following information about you:</p>
                        <ul class="list-disc list-inside mb-6 text-gray-300 pl-5">
                            <li>IP address</li>
                            <li>Device ID</li>
                            <li>Browser type</li>
                            <li>Global geographic location (e.g., country or city level)</li>
                            <li>Advertisements displayed to you and your interactions with them (e.g., whether you clicked on an advertisement)</li>
                            <li>Other technical information (e.g., interaction between your device and the Zingames Website, web pages visited, links clicked, and log data)</li>
                        </ul>

                        <p class="mb-6 text-gray-300"><b>Sensitive Information</b></p>
                        <p class="mb-6 text-gray-300">In the context of the Zingames Website, we generally do not process sensitive information such as health-related data. If we decide to process sensitive information, you will be informed separately, and we will request explicit consent where necessary.</p>

                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">2. Methods of Data Collection</h3>
                        <p class="mb-4 text-gray-300">We gather data through various means:</p>
                        <ul class="list-disc list-inside mb-6 text-gray-300 pl-5">
                            <li><b>Data You Provide:</b> Information you directly share with us, such as in messages or forms you fill out.</li>
                            <li><b>Internal Sources:</b> Data retrieved from other Zingames systems, including our CRM for game developers.</li>
                            <li><b>Third-Party Sources:</b> Information obtained from external entities, such as advertising partners.</li>
                            <li><b>Automatic Collection:</b> Data collected automatically through cookies and similar technologies, including usage data when your device connects to our web servers.</li>
                            <li><b>Inferred Data:</b> Information deduced from existing data, such as your language preferences.</li>
                        </ul>

                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">3. Data Sharing Policy</h3>
                        <p class="mb-6 text-gray-300">At Zingames, we only disclose your data to third parties under specific conditions:</p>
                        <ul class="list-disc list-inside mb-6 text-gray-300 pl-5">
                            <li>It is essential for the delivery of a service or the involvement of a third party.</li>
                            <li>Authorized personnel within the third party have confidentiality obligations.</li>
                            <li>The third party complies with applicable data protection regulations.</li>
                        </ul>

                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">4. Ensuring Data Security</h3>
                        <p class="mb-6 text-gray-300">The protection of your privacy and data is of utmost importance. We have established comprehensive technical and organizational safeguards to protect personal data, ensuring the confidentiality, integrity, and availability of your information. All personnel at Zingames and those involved in data processing are obligated to adhere to strict confidentiality agreements.</p>

                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">5. International Data Transfers</h3>
                        <p class="mb-6 text-gray-300">We understand that parties involved in data processing may be located in various countries. Regardless of these locations, we prioritize the security and protection of your personal data.</p>

                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">6. Data Retention Policy</h3>
                        <p class="mb-6 text-gray-300">At Zingames, we ensure that your personal data is retained only for as long as necessary to fulfill the purposes for which it was collected, unless longer retention is required by legal obligations, ongoing proceedings, or the protection of freedom of expression.</p>

                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">7. Your Privacy Rights and How to Exercise Them</h3>
                        <p class="mb-6 text-gray-300">We are committed to ensuring you have full control over your personal data. You have several rights under data protection laws regarding your personal information.</p>

                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">8. Parties Responsible for Data Processing</h3>
                        <p class="mb-6 text-gray-300">Zingames is primarily responsible for the processing of your personal data. However, other entities involved in our services may also bear responsibility for specific processing activities.</p>

                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">9. Updates to Our Privacy Policy</h3>
                        <p class="mb-6 text-gray-300">At Zingames, we may revise this Privacy Policy to incorporate new technologies, enhance our practices, or comply with legal changes. The most current version will always be accessible on Zingames.com.</p>

                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">10. Regional Privacy Addenda</h3>
                        <p class="mb-6 text-gray-300">Specific privacy rights and protections may vary depending on your location. Please refer to the regional addenda for information applicable to your jurisdiction.</p>

                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">11. Contact Us</h3>
                        <p class="mb-6 text-gray-300">For any inquiries regarding this Privacy Policy or our data practices, please contact us at <b>privacy@zingames.com</b> or through the following contact details:</p>
                        
                        <p class="mb-1 text-gray-300">Address:</p>
                        <p class="mb-1 text-gray-300">Applyset Media</p>
                        <p class="mb-1 text-gray-300">88, Gokul park, Utran, Chorasi, Surat- 394105, Gujarat, India</p>
                        <p class="mb-6 text-gray-300">privacy@zingames.com</p>
                        
                        <p class="text-gray-300">If you prefer to communicate in another language, please notify us via email, and we will do our best to accommodate your request.</p>
                    </main>
                </div>
            </div>
        </section>
    </main>

    <!-- Include Footer -->
    @include('partials.footer')

    <!-- JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Sidebar Toggle
            const sidebar = document.getElementById('sidebar');
            const sidebarToggle = document.getElementById('sidebarToggle');
            const aboutContainer = document.getElementById('aboutContainer');

            sidebarToggle.addEventListener('click', () => {
                sidebar.classList.toggle('open');
                aboutContainer.classList.toggle('shifted');
                sidebarToggle.querySelector('i').classList.toggle('fa-bars');
                sidebarToggle.querySelector('i').classList.toggle('fa-times');
            });

            // Close sidebar on outside click
            document.addEventListener('click', (e) => {
                if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
                    sidebar.classList.remove('open');
                    aboutContainer.classList.remove('shifted');
                    sidebarToggle.querySelector('i').classList.remove('fa-times');
                    sidebarToggle.querySelector('i').classList.add('fa-bars');
                }
            });

            // Header scroll effect
            window.addEventListener('scroll', () => {
                const header = document.querySelector('.header');
                if (window.scrollY > 50) {
                    header.classList.add('scrolled');
                } else {
                    header.classList.remove('scrolled');
                }
            });
        });
    </script>
</body>

</html> 