<!-- Sidebar with Categories -->
<aside class="sidebar fixed top-16 left-0 w-64 sm:w-72 h-[calc(100vh-4rem)] bg-gradient-to-b from-gray-900 to-indigo-950 shadow-2xl transform -translate-x-full transition-transform duration-500 ease-in-out z-40 overflow-y-auto" id="sidebar">
    <div class="p-4 sm:p-6">
        <h2 class="text-lg sm:text-xl font-bold text-white mb-4 sm:mb-6 bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">Categories</h2>
        @foreach($categories as $category)
            <a 
                href="{{ url('/category/' . $category->id . '/' . \Illuminate\Support\Str::slug($category->name)) }}" 
                class="sidebar-category group flex items-center space-x-3 sm:space-x-4 py-2 sm:py-3 px-3 sm:px-4 rounded-lg text-gray-200 hover:bg-gray-800 hover:text-white transition-all duration-300 relative overflow-hidden"
            >
                <span class="category-icon text-base sm:text-lg w-5 sm:w-6 h-5 sm:h-6 flex items-center justify-center transform group-hover:scale-125 transition-transform duration-300">
                    @switch(strtolower($category->name))
                        @case('action')
                            <i class="fas fa-running"></i>
                            @break
                        @case('adventure')
                            <i class="fas fa-mountain"></i>
                            @break
                        @case('arcade')
                            <i class="fas fa-gamepad"></i>
                            @break
                        @case('board')
                            <i class="fas fa-chess-board"></i>
                            @break
                        @case('card')
                            <i class="fas fa-heart"></i>
                            @break
                        @case('casino')
                            <i class="fas fa-dice"></i>
                            @break
                        @case('educational')
                            <i class="fas fa-graduation-cap"></i>
                            @break
                        @case('fighting')
                            <i class="fas fa-fist-raised"></i>
                            @break
                        @case('puzzle')
                            <i class="fas fa-puzzle-piece"></i>
                            @break
                        @case('racing')
                            <i class="fas fa-car-side"></i>
                            @break
                        @case('shooting')
                            <i class="fas fa-crosshairs"></i>
                            @break
                        @case('sports')
                            <i class="fas fa-futbol"></i>
                            @break
                        @case('strategy')
                            <i class="fas fa-chess"></i>
                            @break
                        @default
                            <i class="fas fa-gamepad"></i>
                    @endswitch
                </span>
                <span class="text-sm sm:text-base font-medium">{{ $category->name }}</span>
                <div class="absolute inset-0 bg-gradient-to-r from-indigo-500 to-purple-500 opacity-0 group-hover:opacity-10 blur-md transition-opacity duration-300 rounded-lg"></div>
            </a>
        @endforeach
    </div>
</aside>

<!-- Inline CSS for Sidebar -->
<style>
    /* Ensure smooth scrolling for the sidebar */
    .sidebar {
        scrollbar-width: thin;
        scrollbar-color: #6366f1 #1e293b;
    }

    .sidebar::-webkit-scrollbar {
        width: 8px;
    }

    .sidebar::-webkit-scrollbar-track {
        background: #1e293b;
    }

    .sidebar::-webkit-scrollbar-thumb {
        background-color: #6366f1;
        border-radius: 20px;
        border: 2px solid #1e293b;
    }

    /* Animation for category hover */
    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
    }

    .group:hover .category-icon {
        animation: pulse 0.5s ease-in-out;
    }
</style>

<!-- Inline JavaScript for Sidebar Toggle -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const gamesContainer = document.getElementById('gamesContainer');
        const contentContainer = document.getElementById('contentContainer');
        
        // Determine which container we're using (games or content)
        const activeContainer = gamesContainer || contentContainer;

        if (sidebarToggle && sidebar) {
            sidebarToggle.addEventListener('click', function () {
                sidebar.classList.toggle('translate-x-0');
                sidebar.classList.toggle('-translate-x-full');
                
                // Toggle the shifted class on the active container
                if (activeContainer) {
                    activeContainer.classList.toggle('shifted');
                }
                
                // Toggle the icon
                const icon = sidebarToggle.querySelector('i');
                if (icon) {
                    icon.classList.toggle('fa-bars');
                    icon.classList.toggle('fa-times');
                }
            });

            // Close sidebar when clicking outside
            document.addEventListener('click', function (event) {
                const isClickInsideSidebar = sidebar.contains(event.target);
                const isClickOnToggle = sidebarToggle.contains(event.target);

                if (!isClickInsideSidebar && !isClickOnToggle && sidebar.classList.contains('translate-x-0')) {
                    sidebar.classList.remove('translate-x-0');
                    sidebar.classList.add('-translate-x-full');
                    
                    // Remove shifted class from the active container
                    if (activeContainer) {
                        activeContainer.classList.remove('shifted');
                    }
                    
                    // Reset icon
                    const icon = sidebarToggle.querySelector('i');
                    if (icon) {
                        icon.classList.remove('fa-times');
                        icon.classList.add('fa-bars');
                    }
                }
            });
        }
    });
</script>