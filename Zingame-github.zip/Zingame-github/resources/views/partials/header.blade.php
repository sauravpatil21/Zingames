<!-- Header -->
<header class="sticky top-0 z-50 bg-gradient-to-br from-[#0f172a] via-[#2563eb] to-[#4299e1] bg-opacity-90 backdrop-blur-md shadow-2xl transition-all duration-300 py-4" id="mainHeader">
    <div class="max-w-7xl mx-auto px-4 flex flex-row justify-between items-center gap-3">
        <!-- Logo Section -->
        <a href="/" class="flex items-center gap-3 group relative">
            <span class="absolute inset-0 rounded-full blur-2xl opacity-0 group-hover:opacity-40 transition-opacity duration-500 bg-gradient-to-r from-[#2563eb] to-[#4299e1]"></span>
            <img src="{{ asset('img/logo.png') }}" alt="ZinGames Logo" class="w-12 h-12 sm:w-16 sm:h-16 rounded-full shadow-lg group-hover:scale-110 group-hover:rotate-6 transition-transform duration-300">
            <span class="text-2xl sm:text-3xl font-extrabold text-white drop-shadow-[0_0_16px_#4299e1] tracking-wide group-hover:text-[#4299e1] transition-colors duration-300">ZinGames</span>
        </a>
        <!-- Search Bar: Only show on md and above -->
        <form action="{{ route('games.search') }}" method="GET" class="hidden md:flex items-center bg-white/10 border border-[#2563eb] rounded-full px-4 py-2 shadow-lg focus-within:ring-2 focus-within:ring-[#4299e1] transition-all duration-300 max-w-lg mx-2 flex-1">
            <input type="text" name="query" placeholder="Search games..." class="bg-transparent outline-none text-white placeholder-gray-300 flex-1 px-2 py-1 focus:ring-0 text-base" aria-label="Search games" required>
            <button type="submit" class="ml-2 px-4 py-2 rounded-full bg-gradient-to-r from-[#2563eb] to-[#4299e1] hover:from-[#4299e1] hover:to-[#2563eb] text-white font-semibold shadow-lg transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-[#4299e1]">
                <i class="fas fa-search"></i>
            </button>
        </form>
        <!-- Burger Menu (Always visible) -->
        <button id="sidebarToggle" class="flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-r from-[#2563eb] to-[#4299e1] text-white shadow-lg hover:scale-110 hover:shadow-xl transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-[#4299e1] ml-2" aria-label="Open menu">
            <i class="fas fa-bars text-xl"></i>
        </button>
    </div>
    <script>
      // Shrink header on scroll
      document.addEventListener('DOMContentLoaded', () => {
        const header = document.getElementById('mainHeader');
        window.addEventListener('scroll', () => {
          if(window.scrollY > 30) {
            header.classList.add('py-2');
            header.classList.remove('py-4');
          } else {
            header.classList.remove('py-2');
            header.classList.add('py-4');
          }
        });
      });
    </script>
</header>
