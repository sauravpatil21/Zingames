<!-- Footer -->
<footer class="bg-gradient-to-r from-gray-900 via-blue-950 to-gray-900 text-white py-20 mt-12 relative overflow-hidden transition-all duration-1000">
    <div class="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none animate-grid"></div>
    <div class="container mx-auto px-8 relative z-10">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div class="relative group p-6 rounded-xl bg-gray-800/30 backdrop-blur-md hover:bg-gray-700/50 transition-all duration-500 shadow-lg">
                <h4 class="text-3xl font-bold mb-6 tracking-tight text-blue-300 font-poppins">ZinGames</h4>
                <p class="text-gray-200 leading-relaxed text-base font-inter transition-all duration-300 group-hover:text-white group-hover:scale-105 transform">Your one-stop destination for endless fun and interactive games. Explore, learn, and enjoy with ZinGames!</p>
                <div class="absolute inset-0 bg-blue-500 opacity-0 group-hover:opacity-20 rounded-xl transition-opacity duration-700 glow-effect"></div>
            </div>
            <div class="p-6 rounded-xl bg-gray-800/30 backdrop-blur-md hover:bg-gray-700/50 transition-all duration-500 shadow-lg">
                <h4 class="text-3xl font-bold mb-6 tracking-tight text-blue-300 font-poppins">Quick Links</h4>
                <ul class="space-y-4 font-inter">
                    <li><a href="/about-us" class="text-blue-400 hover:text-blue-200 font-medium transition-all duration-300 transform hover:translate-x-3 hover:glow-link">About Us</a></li>
                    <li><a href="/contact-us" class="text-blue-400 hover:text-blue-200 font-medium transition-all duration-300 transform hover:translate-x-3 hover:glow-link">Contact Us</a></li>
                    <li><a href="/cookies-policy" class="text-blue-400 hover:text-blue-200 font-medium transition-all duration-300 transform hover:translate-x-3 hover:glow-link">Cookies Policy</a></li>
                    <li><a href="/faqs" class="text-blue-400 hover:text-blue-200 font-medium transition-all duration-300 transform hover:translate-x-3 hover:glow-link">FAQs</a></li>
                    <li><a href="/information-for-parents" class="text-blue-400 hover:text-blue-200 font-medium transition-all duration-300 transform hover:translate-x-3 hover:glow-link">Information for Parents</a></li>
                    <li><a href="/privacy-policy" class="text-blue-400 hover:text-blue-200 font-medium transition-all duration-300 transform hover:translate-x-3 hover:glow-link">Privacy Policy</a></li>
                    <li><a href="/terms-of-use" class="text-blue-400 hover:text-blue-200 font-medium transition-all duration-300 transform hover:translate-x-3 hover:glow-link">Terms of Use</a></li>
                    <li><a href="/" class="text-blue-400 hover:text-blue-200 font-medium transition-all duration-300 transform hover:translate-x-3 hover:glow-link">Games</a></li>
                    <li><a href="#" class="text-blue-400 hover:text-blue-200 font-medium transition-all duration-300 transform hover:translate-x-3 hover:glow-link">Categories</a></li>
                </ul>
            </div>
            <div class="relative group p-6 rounded-xl bg-gray-800/30 backdrop-blur-md hover:bg-gray-700/50 transition-all duration-500 shadow-lg">
                <h4 class="text-3xl font-bold mb-6 tracking-tight text-blue-300 font-poppins">Information for Parents</h4>
                <p class="text-gray-200 leading-relaxed text-base font-inter transition-all duration-300 group-hover:text-white group-hover:scale-105 transform">At ZinGames, we prioritize the online safety of children. We provide a secure, enjoyable, and educational gaming environment that respects user privacy.</p>
                <ul class="space-y-4 mt-6 font-inter">
                    <li><a href="/information-for-parents" class="text-blue-400 hover:text-blue-200 font-medium transition-all duration-300 transform hover:translate-x-3 hover:glow-link">Safety Guide</a></li>
                    <li><a href="/privacy-policy" class="text-blue-400 hover:text-blue-200 font-medium transition-all duration-300 transform hover:translate-x-3 hover:glow-link">Privacy Policy</a></li>
                    <li><a href="/terms-of-use" class="text-blue-400 hover:text-blue-200 font-medium transition-all duration-300 transform hover:translate-x-3 hover:glow-link">Terms of Use</a></li>
                </ul>
                <div class="absolute inset-0 bg-blue-500 opacity-0 group-hover:opacity-20 rounded-xl transition-opacity duration-700 glow-effect"></div>
            </div>
        </div>
        <div class="mt-12 text-center text-gray-300 border-t border-gray-700/30 pt-8 font-inter">
            <p>© {{ date('Y') }} <a href="/admin/login" class="text-gray-300 hover:text-blue-300 font-medium transition-all duration-300 hover:glow-link">ZinGames</a>. All rights reserved.</p>
        </div>
    </div>
</footer>

<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&family=Poppins:wght@600;700&display=swap');

    .bg-grid-pattern {
        background-image: linear-gradient(to right, rgba(255, 255, 255, 0.15) 1px, transparent 1px),
                          linear-gradient(to bottom, rgba(255, 255, 255, 0.15) 1px, transparent 1px);
        background-size: 60px 60px;
    }

    .animate-grid {
        animation: gridMove 30s linear infinite;
    }

    @keyframes gridMove {
        0% { background-position: 0 0; }
        100% { background-position: 60px 60px; }
    }

    .glow-effect {
        box-shadow: 0 0 25px rgba(59, 130, 246, 0.4);
    }

    .glow-link:hover {
        text-shadow: 0 0 12px rgba(59, 130, 246, 0.8);
        transform: translateX(3px) scale(1.05);
    }

    footer {
        position: relative;
        overflow: hidden;
    }

    .container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 0 2rem;
    }

    .grid {
        display: grid;
        grid-template-columns: repeat(1, 1fr);
        gap: 3rem;
    }

    @media (min-width: 768px) {
        .grid {
            grid-template-columns: repeat(3, 1fr);
        }
    }

    .font-poppins {
        font-family: 'Poppins', sans-serif;
    }

    .font-inter {
        font-family: 'Inter', sans-serif;
    }

    .shadow-lg {
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
    }
</style>
