<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $category->name }} Games - ZinGames</title>
    <meta name="description" content="Browse all {{ $category->name }} games on ZinGames. Play free online {{ $category->name }} games instantly!">
    <meta name="keywords" content="{{ $category->name }} games, free {{ $category->name }} games, online {{ $category->name }} games">
    <meta name="author" content="ZinGames">
    <meta name="robots" content="index, follow">
    <meta property="og:title" content="{{ $category->name }} Games - ZinGames">
    <meta property="og:description" content="Browse all {{ $category->name }} games on ZinGames. Play free online {{ $category->name }} games instantly!">
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url('/category/' . $category->id) }}">
    <meta property="og:image" content="{{ asset('images/zingames-logo.png') }}">
    <link rel="canonical" href="{{ url('/category/' . $category->id) }}">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome CDN for Social Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
        integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        /* Custom Static CSS - Advanced and Detailed */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #0f172a, #1e293b);
            color: #e0e0e0;
            line-height: 1.6;
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }

        /* Header Styling */
        .header {
            position: sticky;
            top: 0;
            z-index: 2000;
            background: linear-gradient(90deg, #1e293b, #2d3748);
            border-bottom: 2px solid rgba(255, 255, 255, 0.1);
            padding: 1rem 2rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
            transition: all 0.4s ease;
        }

        .header.scrolled {
            padding: 0.5rem 1rem;
            background: linear-gradient(90deg, #1e293b, #2d3748);
        }

        .logo-container {
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
        }

        .logo-img {
            width: 60px;
            height: 60px;
            margin-right: 15px;
            transition: transform 0.3s ease;
        }

        .logo-container:hover .logo-img {
            transform: rotate(5deg) scale(1.1);
        }

        .logo-text {
            font-size: 2.2rem;
            font-weight: 700;
            color: #ffffff;
            text-shadow: 0 0 10px rgba(66, 153, 225, 0.7);
            transition: color 0.3s ease;
        }

        .logo-container:hover .logo-text {
            color: #4299e1;
        }

        .search-container {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 50px;
            padding: 0.75rem 1.5rem;
            display: flex;
            align-items: center;
            width: 50%;
            max-width: 600px;
            transition: all 0.3s ease;
        }

        .search-container:hover {
            background: rgba(255, 255, 255, 0.1);
            box-shadow: 0 0 15px rgba(66, 153, 225, 0.3);
        }

        .search-input {
            background: transparent;
            border: none;
            color: #e0e0e0;
            width: 100%;
            font-size: 1.1rem;
            outline: none;
            transition: color 0.3s ease;
        }

        .search-input::placeholder {
            color: #a0a0a0;
            opacity: 0.8;
        }

        .search-input:focus {
            color: #ffffff;
        }

        .search-btn {
            background: linear-gradient(90deg, #4299e1, #4c51bf);
            color: #ffffff;
            border: none;
            border-radius: 50px;
            padding: 0.75rem 2rem;
            cursor: pointer;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.4s ease;
        }

        .search-btn:hover {
            transform: translateY(-2px) scale(1.05);
            box-shadow: 0 5px 20px rgba(66, 153, 225, 0.5);
            background: linear-gradient(90deg, #4c51bf, #4299e1);
        }

        /* Main Layout */
        .main-container {
            display: flex;
            min-height: calc(100vh - 80px);
            position: relative;
            overflow: hidden;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 250px;
            background: linear-gradient(145deg, #1e293b, #2d3748);
            padding: 1.5rem 0;
            height: calc(100vh - 80px);
            position: fixed;
            top: 80px;
            left: -250px;
            z-index: 1500;
            transition: all 0.4s ease;
            box-shadow: 5px 0 20px rgba(0, 0, 0, 0.4);
            overflow-y: auto;
        }

        .sidebar.open {
            left: 0;
        }

        .sidebar::-webkit-scrollbar {
            width: 8px;
        }

        .sidebar::-webkit-scrollbar-track {
            background: #1e293b;
        }

        .sidebar::-webkit-scrollbar-thumb {
            background: #4299e1;
            border-radius: 4px;
        }

        .sidebar-category {
            display: flex;
            align-items: center;
            padding: 1rem 2rem;
            color: #e0e0e0;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 1.1rem;
            text-transform: capitalize;
        }

        .sidebar-category:hover {
            background: rgba(255, 255, 255, 0.1);
            color: #4299e1;
            transform: translateX(5px);
        }

        .category-icon {
            margin-right: 15px;
            font-size: 1.3rem;
            width: 24px;
            text-align: center;
            color: #a0a0a0;
            transition: color 0.3s ease;
        }

        .sidebar-category:hover .category-icon {
            color: #4299e1;
        }

        /* Toggle Button */
        .sidebar-toggle {
            position: fixed;
            top: 90px;
            left: 10px;
            background: #4299e1;
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            cursor: pointer;
            z-index: 1600;
            transition: all 0.4s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 0 10px rgba(66, 153, 225, 0.5);
        }

        .sidebar-toggle:hover {
            transform: scale(1.1);
            box-shadow: 0 0 15px rgba(66, 153, 225, 0.7);
        }

        .sidebar-toggle i {
            color: #ffffff;
            font-size: 1.2rem;
        }

        /* Games Container */
        .games-container {
            flex: 1;
            padding: 2rem 3rem;
            transition: margin-left 0.4s ease;
            margin-left: 0;
        }

        .games-container.shifted {
            margin-left: 250px;
        }

        /* Category Header */
        .category-header {
            margin-bottom: 2rem;
            text-align: center;
        }

        .category-title {
            font-size: 2.5rem;
            font-weight: 700;
            color: #ffffff;
            margin-bottom: 1rem;
            text-shadow: 0 0 15px rgba(66, 153, 225, 0.8);
        }

        .category-description {
            color: #a0a0a0;
            font-size: 1.2rem;
            max-width: 800px;
            margin: 0 auto;
        }

        /* Games Grid */
        .games-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }

        .game-card {
            background: linear-gradient(145deg, #1e293b, #2d3748);
            border-radius: 15px;
            overflow: hidden;
            position: relative;
            cursor: pointer;
            transition: transform 0.4s ease, box-shadow 0.4s ease;
            height: 250px;
        }

        .game-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.6);
        }

        .game-card img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .game-card:hover img {
            transform: scale(1.1);
        }

        .game-info {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.7);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            opacity: 0;
            transition: opacity 0.3s ease;
            padding: 1rem;
            text-align: center;
        }

        .game-card:hover .game-info {
            opacity: 1;
        }

        .game-title {
            font-size: 1.4rem;
            font-weight: 600;
            color: #ffffff;
            margin-bottom: 0.5rem;
            text-shadow: 0 0 10px rgba(66, 153, 225, 0.7);
        }

        .game-description {
            color: #a0a0a0;
            font-size: 0.95rem;
            margin-bottom: 1rem;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .play-btn {
            background: linear-gradient(90deg, #4299e1, #4c51bf);
            color: #ffffff;
            border: none;
            border-radius: 50px;
            padding: 0.5rem 1rem;
            width: 100%;
            text-align: center;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.4s ease;
        }

        .play-btn:hover {
            transform: translateY(-2px) scale(1.05);
            box-shadow: 0 5px 15px rgba(66, 153, 225, 0.5);
            background: linear-gradient(90deg, #4c51bf, #4299e1);
        }

        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 3rem;
            gap: 0.5rem;
        }

        .page-item {
            margin: 0 0.25rem;
        }

        .page-link {
            background: #1e293b;
            color: #e0e0e0;
            border-radius: 8px;
            padding: 0.75rem 1.5rem;
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .page-link:hover {
            background: #4299e1;
            color: #ffffff;
            transform: translateY(-2px);
            box-shadow: 0 0 10px rgba(66, 153, 225, 0.4);
        }

        .active .page-link {
            background: #4299e1;
            color: #ffffff;
            box-shadow: 0 0 10px rgba(66, 153, 225, 0.6);
        }

        /* Particles Animation */
        .particles {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: -1;
        }

        .particle {
            position: absolute;
            width: 10px;
            height: 10px;
            background: rgba(66, 153, 225, 0.5);
            border-radius: 50%;
            animation: float 15s infinite ease-in-out;
            box-shadow: 0 0 8px rgba(66, 153, 225, 0.3);
        }

        @keyframes float {
            0% { transform: translateY(0); opacity: 0.8; }
            50% { opacity: 0.4; }
            100% { transform: translateY(-300vh); opacity: 0; }
        }

        .particle:nth-child(1) { left: 10%; animation-delay: 0s; }
        .particle:nth-child(2) { left: 20%; animation-delay: 2s; }
        .particle:nth-child(3) { left: 30%; animation-delay: 4s; }
        .particle:nth-child(4) { left: 40%; animation-delay: 6s; }
        .particle:nth-child(5) { left: 50%; animation-delay: 8s; }
        .particle:nth-child(6) { left: 60%; animation-delay: 10s; }
        .particle:nth-child(7) { left: 70%; animation-delay: 12s; }
        .particle:nth-child(8) { left: 80%; animation-delay: 14s; }
        .particle:nth-child(9) { left: 90%; animation-delay: 16s; }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .sidebar {
                width: 220px;
                left: -220px;
            }

            .sidebar.open {
                left: 0;
            }

            .games-container.shifted {
                margin-left: 220px;
            }

            .games-grid {
                grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            }

            .game-card {
                height: 220px;
            }
        }

        @media (max-width: 768px) {
            .header {
                padding: 0.5rem 1rem;
            }

            .logo-img {
                width: 40px;
                height: 40px;
            }

            .logo-text {
                font-size: 1.5rem;
            }

            .search-container {
                width: 70%;
                padding: 0.5rem 1rem;
            }

            .search-input {
                font-size: 1rem;
            }

            .search-btn {
                padding: 0.5rem 1.5rem;
                font-size: 0.9rem;
            }

            .sidebar-toggle {
                top: 70px;
                width: 35px;
                height: 35px;
            }

            .sidebar-toggle i {
                font-size: 1rem;
            }

            .main-container {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                top: 0;
                left: 0;
            }

            .games-container {
                margin-left: 0;
                padding: 1rem;
            }

            .category-title {
                font-size: 2rem;
            }

            .category-description {
                font-size: 1rem;
            }

            .games-grid {
                grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            }

            .game-card {
                height: 180px;
            }

            .game-title {
                font-size: 1.2rem;
            }
        }
    </style>

    <!-- JSON-LD for structured data -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "CollectionPage",
        "name": "{{ $category->name }} Games - ZinGames",
        "description": "Browse all {{ $category->name }} games on ZinGames",
        "url": "{{ url('/category/' . $category->id) }}",
        "mainEntity": {
            "@type": "ItemList",
            "itemListElement": [
                @foreach($games as $index => $game)
                {
                    "@type": "ListItem",
                    "position": {{ $loop->iteration }},
                    "url": "{{ url('/games/' . $game->id) }}",
                    "name": "{{ $game->name }}"
                }@if(!$loop->last),@endif
                @endforeach
            ]
        }
    }
    </script>
</head>

<body>
    <!-- Particles Background -->
    <div class="particles">
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
    </div>

    <!-- Include Header -->
    @include('partials.header')

    <!-- Main Content -->
    <main class="main-container">
        <!-- Include Sidebar -->
        @include('partials.sidebar')

        <!-- Category Games Container -->
        <section class="games-container" id="gamesContainer">
            <!-- Category Header -->
            <div class="category-header">
                <h2 class="category-title">{{ $category->name }} Games</h2>
                <p class="category-description">Explore our collection of {{ $category->name }} games. Find your favorite {{ $category->name }} games and play instantly!</p>
            </div>

            <!-- Games Grid -->
            <div class="games-grid">
                @forelse($games as $game)
                <div class="game-card" onclick="window.location.href='{{ url('/games/' . $game->slug) }}'">
                    @if($game->image)
                        <img src="{{ asset('storage/' . $game->image) }}" alt="{{ $game->name }}">
                    @else
                        <img src="https://source.unsplash.com/random/300x200/?game" alt="{{ $game->name }}">
                    @endif
                    <div class="game-info">
                        <h3 class="game-title">{{ $game->name }}</h3>
                        <p class="game-description">{{ Str::limit($game->description, 80) }}</p>
                    </div>
                </div>
                @empty
                <div class="col-span-full text-center py-12">
                    <p class="text-2xl text-gray-400">No {{ $category->name }} games available at the moment. Check back soon!</p>
                </div>
                @endforelse
            </div>
            
            <!-- Pagination Links -->
            <div class="pagination mt-12">
                {{ $games->links() }}
            </div>
        </section>
    </main>

    <!-- Include Footer -->
    @include('partials.footer')

    <!-- JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Sidebar Toggle
            const sidebar = document.getElementById('sidebar');
            const sidebarToggle = document.getElementById('sidebarToggle');
            const gamesContainer = document.getElementById('gamesContainer');

            sidebarToggle.addEventListener('click', () => {
                sidebar.classList.toggle('open');
                gamesContainer.classList.toggle('shifted');
                sidebarToggle.querySelector('i').classList.toggle('fa-bars');
                sidebarToggle.querySelector('i').classList.toggle('fa-times');
            });

            // Close sidebar on outside click
            document.addEventListener('click', (e) => {
                if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
                    sidebar.classList.remove('open');
                    gamesContainer.classList.remove('shifted');
                    sidebarToggle.querySelector('i').classList.remove('fa-times');
                    sidebarToggle.querySelector('i').classList.add('fa-bars');
                }
            });

            // Header scroll effect
            window.addEventListener('scroll', () => {
                const header = document.querySelector('.header');
                if (window.scrollY > 50) {
                    header.classList.add('scrolled');
                } else {
                    header.classList.remove('scrolled');
                }
            });
        });
    </script>
</body>
</html> 
