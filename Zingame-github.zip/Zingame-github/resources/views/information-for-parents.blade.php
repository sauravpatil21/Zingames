<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Information for Parents - ZinGames</title>
    <meta name="description" content="At ZinGames, we prioritize children's online safety. Learn about our commitment to providing a secure gaming environment, privacy protection, and guidelines for parents.">
    <meta name="keywords" content="kids games, online safety, parental guide, child-friendly games, ZinGames, child privacy">
    <meta name="author" content="ZinGames">
    <meta name="robots" content="index, follow">
    <meta property="og:title" content="Information for Parents - ZinGames">
    <meta property="og:description" content="Comprehensive guide for parents on kids' safety, privacy, and online gaming at ZinGames.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url('/information-for-parents') }}">
    <meta property="og:image" content="{{ asset('img/favicon.ico') }}">
    <link rel="canonical" href="{{ url('/information-for-parents') }}">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome CDN for Social Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
        integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        /* Custom Static CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #0f172a, #1e293b);
            color: #e0e0e0;
            line-height: 1.6;
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }

        /* Main Layout */
        .main-container {
            display: flex;
            min-height: calc(100vh - 80px);
            position: relative;
            overflow: hidden;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 250px;
            background: linear-gradient(145deg, #1e293b, #2d3748);
            padding: 1.5rem 0;
            height: calc(100vh - 80px);
            position: fixed;
            top: 80px;
            left: -250px;
            z-index: 1500;
            transition: all 0.4s ease;
            box-shadow: 5px 0 20px rgba(0, 0, 0, 0.4);
            overflow-y: auto;
        }

        .sidebar.open {
            left: 0;
        }

        /* About Us Container */
        .about-container {
            flex: 1;
            padding: 2rem 3rem;
            transition: margin-left 0.4s ease;
            margin-left: 0;
        }

        .about-container.shifted {
            margin-left: 250px;
        }

        .about-section {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            padding: 2.5rem;
            margin-bottom: 3rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .about-section:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: 700;
            color: #ffffff;
            margin-bottom: 1.5rem;
            text-shadow: 0 0 15px rgba(66, 153, 225, 0.8);
            position: relative;
            display: inline-block;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 0;
            width: 60px;
            height: 4px;
            background: linear-gradient(90deg, #4299e1, #4c51bf);
            border-radius: 2px;
        }

        .about-text {
            font-size: 1.1rem;
            line-height: 1.8;
            color: #d0d0d0;
            margin-bottom: 1.5rem;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .sidebar {
                width: 220px;
                left: -220px;
            }

            .sidebar.open {
                left: 0;
            }

            .about-container.shifted {
                margin-left: 220px;
            }
            
            .about-section {
                padding: 2rem;
            }
            
            .section-title {
                font-size: 2.2rem;
            }
        }

        @media (max-width: 768px) {
            .main-container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                top: 0;
                left: -100%;
            }
            
            .sidebar.open {
                left: 0;
            }
            
            .about-container {
                padding: 1.5rem;
                margin-left: 0;
            }
            
            .about-container.shifted {
                margin-left: 0;
            }
            
            .about-section {
                padding: 1.5rem;
            }
            
            .flex-1 {
                padding: 1rem;
                padding-top: 70px;
            }
            
            h1 {
                font-size: 1.8rem;
                margin-bottom: 1rem;
            }
            
            h3 {
                font-size: 1.4rem;
                margin-bottom: 0.75rem;
            }
            
            .section-title {
                font-size: 1.8rem;
            }
            
            .about-text {
                font-size: 1rem;
            }
            
            ul.list-disc {
                padding-left: 1.5rem;
            }
        }
        
        @media (max-width: 480px) {
            .about-container {
                padding: 1rem;
            }
            
            .about-section {
                padding: 1.25rem;
                margin-bottom: 2rem;
            }
            
            .flex-1 {
                padding: 0.75rem;
                padding-top: 60px;
            }
            
            h1 {
                font-size: 1.5rem;
            }
            
            h3 {
                font-size: 1.2rem;
            }
            
            .section-title {
                font-size: 1.5rem;
            }
            
            .about-text, p {
                font-size: 0.95rem;
            }
            
            ul.list-disc {
                padding-left: 1rem;
            }
            
            li {
                margin-bottom: 0.5rem;
            }
        }
    </style>
</head>

<body>
    <!-- Particles Background -->
    <div class="particles">
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
    </div>

    <!-- Include Header -->
    @include('partials.header')

    <!-- Main Content -->
    <main class="main-container">
        <!-- Include Sidebar -->
        @include('partials.sidebar')

        <!-- Information for Parents Container -->
        <section class="about-container" id="aboutContainer">
            <div class="about-section">
                <div class="flex flex-1">
                    <main class="flex-1 p-8 pt-[90px]">
                        <h1 class="text-4xl font-bold mb-6 text-gray-100">Information for Parents and Guardians</h1>
                        
                        <p class="mb-6 text-gray-300">Dear Parents and Guardians, At ZinGames, we prioritize the online safety of children. We recognize the importance of safeguarding their online experience, and this guide is designed to provide a comprehensive overview of our efforts. For further questions, please don't hesitate to reach out at <b>support@zingames.com.</b></p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">What is ZinGames?</h3>
                        <p class="mb-6 text-gray-300">ZinGames is a free browser-based gaming platform. We host a diverse array of games, from exciting action and racing games to creative dress-up and strategy games. Our platform supports itself through safe, unobtrusive advertising, allowing users to enjoy our games without any cost.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">Ensuring Your Child's Online Safety</h3>
                        <p class="mb-4 text-gray-300">To protect your child while they use our platform, we recommend the following precautions:</p>
                        <ul class="list-disc list-inside mb-6 text-gray-300 pl-5">
                            <li>Direct younger children to use ZinGames under adult supervision, especially if under the age of 13.</li>
                            <li>Educate your child never to share personal details like home addresses, email addresses, or phone numbers online.</li>
                            <li>Advise your child to choose a nondescript username and secure password, and to keep this password confidential.</li>
                            <li>Teach your child to come to you if they encounter any uncomfortable situations or content online.</li>
                            <li>Make sure your child understands the importance of being truthful about their age when using online platforms.</li>
                        </ul>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">Our Commitment to Child Safety</h3>
                        <p class="mb-6 text-gray-300">ZinGames rigorously monitors the content on our platform, ensuring it respects the rights and dignity of all players. We employ filters and moderators to prevent inappropriate language or content from being displayed. Our developers are instructed to adhere strictly to these standards to maintain a safe gaming environment.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">In-Game Purchases and Financial Safety</h3>
                        <p class="mb-6 text-gray-300">While every game on ZinGames can be played for free, some may offer optional in-game purchases. These are governed by specific terms and conditions that must be accepted before the purchase is made. ZinGames does not directly facilitate these transactions but provides links to games offering them.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">Reporting Inappropriate Advertisements</h3>
                        <p class="mb-6 text-gray-300">We curate our advertisements partners carefully to align with our audience's appropriateness. If you or your child encounter any disturbing ads, please contact us at <b>privacy@zingames.com</b> with details and screenshots of the ad. We will address the issue promptly.</p>
                        
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">Personal Data and Privacy</h3>
                        <p class="mb-6 text-gray-300">ZinGames collects minimal personal data, prioritizing user privacy and security. Our Privacy Policy provides detailed information about how we handle data collection. If you have concerns about your child's data or believe they may have submitted personal information to us, please contact us at <b>privacy@zingames.com.</b> We take serious steps to verify your identity to protect your child's privacy before accessing any personal data.</p>
                        
                        <p class="text-gray-300">Our goal at ZinGames is to provide a secure, enjoyable, and educational gaming environment that respects user privacy and promotes responsible gaming practices. We appreciate your cooperation and commitment to keeping our gaming community safe and fun for everyone.</p>
                    </main>
                </div>
            </div>
        </section>
    </main>

    <!-- Include Footer -->
    @include('partials.footer')

    <!-- JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Sidebar Toggle
            const sidebar = document.getElementById('sidebar');
            const sidebarToggle = document.getElementById('sidebarToggle');
            const aboutContainer = document.getElementById('aboutContainer');

            sidebarToggle.addEventListener('click', () => {
                sidebar.classList.toggle('open');
                aboutContainer.classList.toggle('shifted');
                sidebarToggle.querySelector('i').classList.toggle('fa-bars');
                sidebarToggle.querySelector('i').classList.toggle('fa-times');
            });

            // Close sidebar on outside click
            document.addEventListener('click', (e) => {
                if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
                    sidebar.classList.remove('open');
                    aboutContainer.classList.remove('shifted');
                    sidebarToggle.querySelector('i').classList.remove('fa-times');
                    sidebarToggle.querySelector('i').classList.add('fa-bars');
                }
            });

            // Header scroll effect
            window.addEventListener('scroll', () => {
                const header = document.querySelector('.header');
                if (window.scrollY > 50) {
                    header.classList.add('scrolled');
                } else {
                    header.classList.remove('scrolled');
                }
            });
        });
    </script>
</body>

</html> 