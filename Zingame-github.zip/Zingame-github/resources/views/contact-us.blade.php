<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - ZinGames</title>
    <meta name="description" content="Get in touch with the ZinGames team for support, partnerships, or general inquiries.">
    <meta name="keywords" content="ZinGames contact, gaming support, game developer contact">
    <meta name="author" content="ZinGames">
    <meta name="robots" content="index, follow">
    <meta property="og:title" content="Contact Us - ZinGames">
    <meta property="og:description" content="Get in touch with the ZinGames team for support, partnerships, or general inquiries.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url('/contact-us') }}">
    <meta property="og:image" content="{{ asset('img/favicon.ico-logo.png') }}">
    <link rel="canonical" href="{{ url('/contact-us') }}">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome CDN for Social Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
        integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        /* Custom Static CSS - Advanced and Detailed */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #0f172a, #1e293b);
            color: #e0e0e0;
            line-height: 1.6;
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }

        /* Header Styling */
        .header {
            position: sticky;
            top: 0;
            z-index: 2000;
            background: linear-gradient(90deg, #1e293b, #2d3748);
            border-bottom: 2px solid rgba(255, 255, 255, 0.1);
            padding: 1rem 2rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
            transition: all 0.4s ease;
        }

        .header.scrolled {
            padding: 0.5rem 1rem;
            background: linear-gradient(90deg, #1e293b, #2d3748);
        }

        .logo-container {
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
        }

        .logo-img {
            width: 60px;
            height: 60px;
            margin-right: 15px;
            transition: transform 0.3s ease;
        }

        .logo-container:hover .logo-img {
            transform: rotate(5deg) scale(1.1);
        }

        .logo-text {
            font-size: 2.2rem;
            font-weight: 700;
            color: #ffffff;
            text-shadow: 0 0 10px rgba(66, 153, 225, 0.7);
            transition: color 0.3s ease;
        }

        .logo-container:hover .logo-text {
            color: #4299e1;
        }

        .search-container {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 50px;
            padding: 0.75rem 1.5rem;
            display: flex;
            align-items: center;
            width: 50%;
            max-width: 600px;
            transition: all 0.3s ease;
        }

        .search-container:hover {
            background: rgba(255, 255, 255, 0.1);
            box-shadow: 0 0 15px rgba(66, 153, 225, 0.3);
        }

        .search-input {
            background: transparent;
            border: none;
            color: #e0e0e0;
            width: 100%;
            font-size: 1.1rem;
            outline: none;
            transition: color 0.3s ease;
        }

        .search-input::placeholder {
            color: #a0a0a0;
            opacity: 0.8;
        }

        .search-input:focus {
            color: #ffffff;
        }

        .search-btn {
            background: linear-gradient(90deg, #4299e1, #4c51bf);
            color: #ffffff;
            border: none;
            border-radius: 50px;
            padding: 0.75rem 2rem;
            cursor: pointer;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.4s ease;
        }

        .search-btn:hover {
            transform: translateY(-2px) scale(1.05);
            box-shadow: 0 5px 20px rgba(66, 153, 225, 0.5);
            background: linear-gradient(90deg, #4c51bf, #4299e1);
        }

        /* Main Layout */
        .main-container {
            display: flex;
            min-height: calc(100vh - 80px);
            position: relative;
            overflow: hidden;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 250px;
            background: linear-gradient(145deg, #1e293b, #2d3748);
            padding: 1.5rem 0;
            height: calc(100vh - 80px);
            position: fixed;
            top: 80px;
            z-index: 1500;
            transition: transform 0.4s ease;
            box-shadow: 5px 0 20px rgba(0, 0, 0, 0.4);
            overflow-y: auto;
        }

        .sidebar.translate-x-0 {
            transform: translateX(0);
        }

        .sidebar.-translate-x-full {
            transform: translateX(-100%);
        }

        .sidebar::-webkit-scrollbar {
            width: 8px;
        }

        .sidebar::-webkit-scrollbar-track {
            background: #1e293b;
        }

        .sidebar::-webkit-scrollbar-thumb {
            background: #4299e1;
            border-radius: 4px;
        }

        .sidebar-category {
            display: flex;
            align-items: center;
            padding: 1rem 2rem;
            color: #e0e0e0;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 1.1rem;
            text-transform: capitalize;
        }

        .sidebar-category:hover {
            background: rgba(255, 255, 255, 0.1);
            color: #4299e1;
            transform: translateX(5px);
        }

        .category-icon {
            margin-right: 15px;
            font-size: 1.3rem;
            width: 24px;
            text-align: center;
            color: #a0a0a0;
            transition: color 0.3s ease;
        }

        .sidebar-category:hover .category-icon {
            color: #4299e1;
        }

        /* Content Container */
        .content-container {
            flex: 1;
            padding: 2rem 3rem;
            transition: margin-left 0.4s ease;
            margin-left: 0;
            background: #0f172a;
        }

        .content-container.shifted {
            margin-left: 250px;
        }

        /* Contact Info Styling */
        .contact-card {
            background: linear-gradient(145deg, #1e293b, #2d3748);
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .contact-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.4);
        }

        .contact-list {
            list-style-type: disc;
            padding-left: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .contact-list li {
            margin-bottom: 0.5rem;
        }

        .contact-list strong {
            color: #4299e1;
        }

        .social-icons {
            display: flex;
            gap: 1rem;
            margin-top: 1.5rem;
        }

        .social-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            transition: all 0.3s ease;
            color: #a0a0a0;
        }

        .social-icon:hover {
            background: #4299e1;
            color: #ffffff;
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(66, 153, 225, 0.4);
        }

        /* Particles Animation */
        .particles {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: -1;
        }

        .particle {
            position: absolute;
            width: 10px;
            height: 10px;
            background: rgba(66, 153, 225, 0.5);
            border-radius: 50%;
            animation: float 15s infinite ease-in-out;
            box-shadow: 0 0 8px rgba(66, 153, 225, 0.3);
        }

        @keyframes float {
            0% { transform: translateY(0); opacity: 0.8; }
            50% { opacity: 0.4; }
            100% { transform: translateY(-300vh); opacity: 0; }
        }

        .particle:nth-child(1) { left: 10%; animation-delay: 0s; }
        .particle:nth-child(2) { left: 20%; animation-delay: 2s; }
        .particle:nth-child(3) { left: 30%; animation-delay: 4s; }
        .particle:nth-child(4) { left: 40%; animation-delay: 6s; }
        .particle:nth-child(5) { left: 50%; animation-delay: 8s; }
        .particle:nth-child(6) { left: 60%; animation-delay: 10s; }
        .particle:nth-child(7) { left: 70%; animation-delay: 12s; }
        .particle:nth-child(8) { left: 80%; animation-delay: 14s; }
        .particle:nth-child(9) { left: 90%; animation-delay: 16s; }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .sidebar {
                width: 220px;
            }

            .content-container.shifted {
                margin-left: 220px;
            }
        }

        @media (max-width: 768px) {
            .header {
                padding: 0.5rem 1rem;
            }

            .logo-img {
                width: 40px;
                height: 40px;
            }

            .logo-text {
                font-size: 1.5rem;
            }

            .search-container {
                width: 70%;
                padding: 0.5rem 1rem;
            }

            .search-input {
                font-size: 1rem;
            }

            .search-btn {
                padding: 0.5rem 1.5rem;
                font-size: 0.9rem;
            }

            .main-container {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                top: 0;
            }

            .content-container {
                margin-left: 0;
                padding: 1rem;
            }
        }
    </style>
</head>

<body>
    <!-- Particles Background -->
    <div class="particles">
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
    </div>

    <!-- Include Header -->
    @include('partials.header')

    <!-- Main Content -->
    <main class="main-container">
        <!-- Include Sidebar -->
        @include('partials.sidebar')

        <!-- Content Container -->
        <section class="content-container" id="contentContainer">
            <div class="flex flex-1">
                <main class="flex-1 p-8 pt-[90px]">
                    <h1 class="text-4xl font-bold mb-6 text-gray-100">Contact Us</h1>
                    <p class="mb-6 text-gray-300">At ZinGames, we value your feedback and inquiries. We encourage you to
                        reach out to us using the information below:</p>
                    
                    <div class="contact-card">
                        <div class="text-gray-300">
                            <p class="font-semibold mb-2 text-white">Email:</p>
                            <ul class="contact-list mb-6">
                                <li><strong>General Inquiries:</strong> hello@zingames.com</li>
                                <li><strong>Privacy Concerns:</strong> privacy@zingames.com</li>
                                <li><strong>Support:</strong> support@zingames.com</li>
                                <li><strong>Developer Inquiries:</strong> developers@zingames.com</li>
                            </ul>
                            
                            <p class="font-semibold mb-2 text-white">Mailing Address:</p>
                            <p class="mb-6">Applyset Media, 88 Gokul Park, Utran, Chorasi Surat-394105, Gujarat, India</p>
                            
                            <p class="font-semibold text-white">Social Media:</p>
                            <p class="mb-4">We are currently building our social media presence. Stay tuned for updates!</p>
                            
                            <div class="social-icons">
                                <a href="#" class="social-icon" title="Coming Soon - Facebook">
                                    <i class="fab fa-facebook-f"></i>
                                </a>
                                <a href="#" class="social-icon" title="Coming Soon - Twitter">
                                    <i class="fab fa-twitter"></i>
                                </a>
                                <a href="#" class="social-icon" title="Coming Soon - Instagram">
                                    <i class="fab fa-instagram"></i>
                                </a>
                                <a href="#" class="social-icon" title="Coming Soon - LinkedIn">
                                    <i class="fab fa-linkedin-in"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="contact-card">
                        <h2 class="text-2xl font-bold mb-4 text-white">Send Us a Message</h2>
                        <p class="mb-4 text-gray-300">Fill out the form below, and we'll get back to you as soon as possible:</p>
                        
                        @if(session('success'))
                        <div class="bg-green-500 text-white rounded-lg p-4 mb-6">
                            {{ session('success') }}
                        </div>
                        @endif
                        
                        <form action="{{ route('contact.store') }}" method="POST" class="space-y-4">
                            @csrf
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-gray-300 mb-2" for="name">Your Name</label>
                                    <input type="text" id="name" name="name" value="{{ old('name') }}" class="w-full p-3 rounded-lg bg-gray-700 text-white border border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                                    @error('name')
                                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                                    @enderror
                                </div>
                                <div>
                                    <label class="block text-gray-300 mb-2" for="email">Your Email</label>
                                    <input type="email" id="email" name="email" value="{{ old('email') }}" class="w-full p-3 rounded-lg bg-gray-700 text-white border border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                                    @error('email')
                                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                                    @enderror
                                </div>
                            </div>
                            <div>
                                <label class="block text-gray-300 mb-2" for="subject">Subject</label>
                                <input type="text" id="subject" name="subject" value="{{ old('subject') }}" class="w-full p-3 rounded-lg bg-gray-700 text-white border border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                                @error('subject')
                                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                                @enderror
                            </div>
                            <div>
                                <label class="block text-gray-300 mb-2" for="message">Your Message</label>
                                <textarea id="message" name="message" rows="5" class="w-full p-3 rounded-lg bg-gray-700 text-white border border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500" required>{{ old('message') }}</textarea>
                                @error('message')
                                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                                @enderror
                            </div>
                            <button type="submit" class="bg-gradient-to-r from-cyan-500 to-blue-600 text-white py-3 px-6 rounded-lg hover:from-cyan-600 hover:to-blue-700 transition-all duration-300 shadow-lg hover:shadow-xl">
                                Send Message
                            </button>
                        </form>
                    </div>
                </main>
            </div>
        </section>
    </main>

    <!-- Include Footer -->
    @include('partials.footer')

    <!-- JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Header scroll effect
            window.addEventListener('scroll', () => {
                const header = document.querySelector('.header');
                if (window.scrollY > 50) {
                    header.classList.add('scrolled');
                } else {
                    header.classList.remove('scrolled');
                }
            });
        });
    </script>
</body>

</html>
