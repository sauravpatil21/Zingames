@extends('layouts.app')

@section('title', 'Contact Us')

@section('content')
<!-- Header Section -->
@include('header')

<!-- Main Content -->
<div class="container my-5">
    <!-- Contact Heading -->
    <div class="row mb-5 text-center">
        <div class="col-12">
            <h1 class="text-white display-4 mb-3">Contact Us</h1>
            <p class="text-light lead">Have a question, suggestion, or feedback? We'd love to hear from you!</p>
        </div>
    </div>

    <!-- Form and Information -->
    <div class="row">
        <!-- Contact Form -->
        <div class="col-lg-7 mb-4">
            <div class="card bg-dark border-cyan">
                <div class="card-body p-4">
                    <h3 class="text-white mb-4">Send us a message</h3>
                    
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    <form action="{{ route('contact.store') }}" method="POST">
                        @csrf
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <div class="form-group">
                                    <label for="name" class="text-white">Your Name</label>
                                    <input type="text" name="name" id="name" class="form-control bg-dark text-white @error('name') is-invalid @enderror" placeholder="Enter your name" value="{{ old('name') }}">
                                    @error('name')
                                        <span class="invalid-feedback">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="form-group">
                                    <label for="email" class="text-white">Email Address</label>
                                    <input type="email" name="email" id="email" class="form-control bg-dark text-white @error('email') is-invalid @enderror" placeholder="Enter your email" value="{{ old('email') }}">
                                    @error('email')
                                        <span class="invalid-feedback">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group mb-3">
                            <label for="subject" class="text-white">Subject</label>
                            <input type="text" name="subject" id="subject" class="form-control bg-dark text-white @error('subject') is-invalid @enderror" placeholder="Enter subject" value="{{ old('subject') }}">
                            @error('subject')
                                <span class="invalid-feedback">{{ $message }}</span>
                            @enderror
                        </div>
                        
                        <div class="form-group mb-4">
                            <label for="message" class="text-white">Message</label>
                            <textarea name="message" id="message" rows="5" class="form-control bg-dark text-white @error('message') is-invalid @enderror" placeholder="Your message here...">{{ old('message') }}</textarea>
                            @error('message')
                                <span class="invalid-feedback">{{ $message }}</span>
                            @enderror
                        </div>
                        
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary px-5 py-2" style="background-color: #0088a9; border: none;">Send Message</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Contact Information -->
        <div class="col-lg-5">
            <div class="card bg-dark border-cyan h-100">
                <div class="card-body p-4">
                    <h3 class="text-white mb-4">Contact Information</h3>
                    
                    <div class="contact-info">
                        <div class="mb-4">
                            <h5 class="text-white">Get in Touch</h5>
                            <p class="text-light">Feel free to reach out to us through any of the following channels. We're here to help!</p>
                        </div>
                        
                        <div class="mb-3 d-flex align-items-center">
                            <i class="fas fa-envelope text-primary mr-3" style="color: #0088a9 !important; font-size: 24px; width: 35px;"></i>
                            <div>
                                <h6 class="text-white mb-1">Email</h6>
                                <p class="text-light">support@zingames.com</p>
                            </div>
                        </div>
                        
                        <div class="mb-3 d-flex align-items-center">
                            <i class="fas fa-globe text-primary mr-3" style="color: #0088a9 !important; font-size: 24px; width: 35px;"></i>
                            <div>
                                <h6 class="text-white mb-1">Website</h6>
                                <p class="text-light">www.zingames.com</p>
                            </div>
                        </div>
                        
                        <div class="mb-4 d-flex align-items-center">
                            <i class="fas fa-map-marker-alt text-primary mr-3" style="color: #0088a9 !important; font-size: 24px; width: 35px;"></i>
                            <div>
                                <h6 class="text-white mb-1">Location</h6>
                                <p class="text-light">Digital Game World, Gaming Street, Web City</p>
                            </div>
                        </div>
                        
                        <div class="mt-5">
                            <h5 class="text-white mb-3">Follow Us</h5>
                            <div class="social-icons">
                                <a href="#" class="text-decoration-none me-3">
                                    <i class="fab fa-facebook-f" style="color: #0088a9; font-size: 24px;"></i>
                                </a>
                                <a href="#" class="text-decoration-none me-3">
                                    <i class="fab fa-twitter" style="color: #0088a9; font-size: 24px;"></i>
                                </a>
                                <a href="#" class="text-decoration-none me-3">
                                    <i class="fab fa-instagram" style="color: #0088a9; font-size: 24px;"></i>
                                </a>
                                <a href="#" class="text-decoration-none">
                                    <i class="fab fa-youtube" style="color: #0088a9; font-size: 24px;"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- FAQ Section (Optional) -->
<div class="container my-5">
    <div class="row">
        <div class="col-12 text-center mb-4">
            <h2 class="text-white">Frequently Asked Questions</h2>
        </div>
        
        <div class="col-12">
            <div class="accordion" id="faqAccordion">
                <!-- FAQ Item 1 -->
                <div class="accordion-item bg-dark text-white mb-3 border-cyan">
                    <h2 class="accordion-header" id="headingOne">
                        <button class="accordion-button collapsed bg-dark text-white" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                            How do I report a game issue?
                        </button>
                    </h2>
                    <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            If you encounter any issues with a game, you can use the contact form above to report it. Please include the name of the game, the specific problem you're experiencing, and any relevant details that might help us understand the issue better.
                        </div>
                    </div>
                </div>
                
                <!-- FAQ Item 2 -->
                <div class="accordion-item bg-dark text-white mb-3 border-cyan">
                    <h2 class="accordion-header" id="headingTwo">
                        <button class="accordion-button collapsed bg-dark text-white" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            How can I suggest a new game to be added?
                        </button>
                    </h2>
                    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            We love hearing game suggestions from our community! Simply use the contact form above and select "Game Suggestion" as the subject. Include the name of the game you'd like to see added, and any links or information about it that might be helpful.
                        </div>
                    </div>
                </div>
                
                <!-- FAQ Item 3 -->
                <div class="accordion-item bg-dark text-white mb-3 border-cyan">
                    <h2 class="accordion-header" id="headingThree">
                        <button class="accordion-button collapsed bg-dark text-white" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            What information do you collect from users?
                        </button>
                    </h2>
                    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            We collect minimal information needed to provide our services. When you submit a contact form, we collect your name and email address solely for the purpose of responding to your inquiry. Please refer to our Privacy Policy for more details on our data practices.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
@include('footer')

<style>
    .border-cyan {
        border: 1px solid #0088a9;
    }
    
    .form-control:focus {
        border-color: #0088a9;
        box-shadow: 0 0 0 0.25rem rgba(0, 136, 169, 0.25);
    }
    
    .accordion-button:not(.collapsed) {
        background-color: #0088a9;
        color: white;
    }
    
    .accordion-button:focus {
        box-shadow: 0 0 0 0.25rem rgba(0, 136, 169, 0.25);
        border-color: #0088a9;
    }
    
    .social-icons a:hover i {
        transform: translateY(-5px);
        transition: all 0.3s ease;
    }
</style>
@endsection 