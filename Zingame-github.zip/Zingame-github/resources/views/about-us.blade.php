<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - ZinGames</title>
    <meta name="description" content="Learn more about ZinGames - Your ultimate destination for free online games. Our mission, vision, and the team behind the platform.">
    <meta name="keywords" content="about zingames, zingames team, online games platform, free games website">
    <meta name="author" content="ZinGames">
    <meta name="robots" content="index, follow">
    <meta property="og:title" content="About Us - ZinGames">
    <meta property="og:description" content="Learn more about ZinGames - Your ultimate destination for free online games.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url('/about-us') }}">
    <meta property="og:image" content="{{ asset('img/favicon.ico') }}">
    <link rel="canonical" href="{{ url('/about-us') }}">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome CDN for Social Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
        integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        /* Custom Static CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #0f172a, #1e293b);
            color: #e0e0e0;
            line-height: 1.6;
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }

        /* Main Layout */
        .main-container {
            display: flex;
            min-height: calc(100vh - 80px);
            position: relative;
            overflow: hidden;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 250px;
            background: linear-gradient(145deg, #1e293b, #2d3748);
            padding: 1.5rem 0;
            height: calc(100vh - 80px);
            position: fixed;
            top: 80px;
            left: -250px;
            z-index: 1500;
            transition: all 0.4s ease;
            box-shadow: 5px 0 20px rgba(0, 0, 0, 0.4);
            overflow-y: auto;
        }

        .sidebar.open {
            left: 0;
        }

        /* About Us Container */
        .about-container {
            flex: 1;
            padding: 2rem 3rem;
            transition: margin-left 0.4s ease;
            margin-left: 0;
        }

        .about-container.shifted {
            margin-left: 250px;
        }

        .about-section {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            padding: 2.5rem;
            margin-bottom: 3rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .about-section:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: 700;
            color: #ffffff;
            margin-bottom: 1.5rem;
            text-shadow: 0 0 15px rgba(66, 153, 225, 0.8);
            position: relative;
            display: inline-block;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 0;
            width: 60px;
            height: 4px;
            background: linear-gradient(90deg, #4299e1, #4c51bf);
            border-radius: 2px;
        }

        .about-text {
            font-size: 1.1rem;
            line-height: 1.8;
            color: #d0d0d0;
            margin-bottom: 1.5rem;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .sidebar {
                width: 220px;
                left: -220px;
            }

            .sidebar.open {
                left: 0;
            }

            .about-container.shifted {
                margin-left: 220px;
            }
            
            .about-section {
                padding: 2rem;
            }
            
            .section-title {
                font-size: 2.2rem;
            }
        }

        @media (max-width: 768px) {
            .main-container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                top: 0;
                left: -100%;
            }
            
            .sidebar.open {
                left: 0;
            }
            
            .about-container {
                padding: 1.5rem;
                margin-left: 0;
            }
            
            .about-container.shifted {
                margin-left: 0;
            }
            
            .about-section {
                padding: 1.5rem;
            }
            
            .section-title {
                font-size: 1.8rem;
            }
            
            .about-text {
                font-size: 1rem;
            }
        }
        
        @media (max-width: 480px) {
            .about-container {
                padding: 1rem;
            }
            
            .about-section {
                padding: 1.25rem;
                margin-bottom: 2rem;
            }
            
            .section-title {
                font-size: 1.5rem;
            }
            
            .about-text {
                font-size: 0.95rem;
            }
        }
    </style>
</head>

<body>
    <!-- Particles Background -->
    <div class="particles">
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
    </div>

    <!-- Include Header -->
    @include('partials.header')

    <!-- Main Content -->
    <main class="main-container">
        <!-- Include Sidebar -->
        @include('partials.sidebar')

        <!-- About Us Container -->
        <section class="about-container" id="aboutContainer">
            <div class="about-section">
                <div class="flex flex-1">
                    <main class="flex-1 p-8 pt-[90px]">
                        <h1 class="text-4xl font-bold mb-6 text-gray-100">About Us</h1>
                        <p class="mb-6 text-gray-300">ZinGames is a one-stop destination for a fun and engaging online
                            gaming experience, brought to you by Applyset Media. We are a registered company based in Surat,
                            Gujarat, India, and abide by all Indian laws and regulations.</p>
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">Our Mission</h3>
                        <p class="mb-6 text-gray-300">At ZinGames, our mission is to provide a curated selection of
                            high-quality, browser-based games that are accessible to everyone, regardless of age, skill
                            level, or device. We believe that games can be a powerful source of entertainment, education,
                            and relaxation, and we strive to create a platform where everyone can find something they enjoy.
                        </p>
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">Our Commitment</h3>
                        <ul class="list-disc list-inside mb-6 text-gray-300 pl-5">
                            <li><strong>Quality:</strong> We carefully select and curate our games to ensure they are of the
                                highest quality, both in terms of gameplay and design.</li>
                            <li><strong>Variety:</strong> We offer a wide variety of games across different genres, from
                                puzzle and strategy games to action and adventure games. There's something for
                                everyone!</li>
                            <li><strong>Accessibility:</strong> Our games are all playable directly in your web browser,
                                with no downloads or installations required. This makes it easy for anyone to jump in and
                                start playing right away.</li>
                            <li><strong>Safety:</strong> We are committed to providing a safe and secure gaming environment
                                for all our users. We have robust security measures in place to protect your information.
                            </li>
                            <li><strong>Guidance and Information:</strong> We believe informed users are happy users. We
                                strive to provide comprehensive information about each game, including gameplay
                                instructions, age recommendations, and any other relevant details. Additionally, we will
                                continue to develop resources to help users navigate the complexities of online gaming.</li>
                        </ul>
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">The Applyset Media Team</h3>
                        <p class="mb-6 text-gray-300">ZinGames is a product of Applyset Media, a company passionate about
                            creating engaging and entertaining online experiences. Our team is made up of talented
                            individuals with a deep love for games and a commitment to providing exceptional service to our
                            users.</p>
                        <h3 class="text-2xl font-semibold mb-4 text-gray-100">Join the ZinGames Community!</h3>
                        <p class="text-gray-300">We invite you to explore ZinGames, discover your new favorite game, and
                            join our ever-growing community of gamers. If you have any questions or feedback, please
                            don't hesitate to contact us. We're always happy to hear from you!</p>
                    </main>
                </div>
            </div>
        </section>
    </main>

    <!-- Include Footer -->
    @include('partials.footer')

    <!-- JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Sidebar Toggle
            const sidebar = document.getElementById('sidebar');
            const sidebarToggle = document.getElementById('sidebarToggle');
            const aboutContainer = document.getElementById('aboutContainer');

            sidebarToggle.addEventListener('click', () => {
                sidebar.classList.toggle('open');
                aboutContainer.classList.toggle('shifted');
                sidebarToggle.querySelector('i').classList.toggle('fa-bars');
                sidebarToggle.querySelector('i').classList.toggle('fa-times');
            });

            // Close sidebar on outside click
            document.addEventListener('click', (e) => {
                if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
                    sidebar.classList.remove('open');
                    aboutContainer.classList.remove('shifted');
                    sidebarToggle.querySelector('i').classList.remove('fa-times');
                    sidebarToggle.querySelector('i').classList.add('fa-bars');
                }
            });

            // Header scroll effect
            window.addEventListener('scroll', () => {
                const header = document.querySelector('.header');
                if (window.scrollY > 50) {
                    header.classList.add('scrolled');
                } else {
                    header.classList.remove('scrolled');
                }
            });
        });
    </script>
</body>

</html> 